//
//  ViewController.h
//  JYPTSDK
//
//  Created by huangchuanfeng on 2016/10/31.
//  Copyright © 2016年 LeiMingTech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

