//
//  ViewController.m
//  JYPTSDK
//
//  Created by huangchuanfeng on 2016/10/31.
//  Copyright © 2016年 LeiMingTech. All rights reserved.
//

#import "ViewController.h"
#import "TKExaminationDetailViewController.h"
#import "TKExamHadFinishedVC.h"
#import "TKJYManager.h"

#define AppKey @"f1e0520df09419cb1a77c859a668bd51"  //教学平台APPkey

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 64, SCREEN_WIDTH, 100);
    [btn setTitle:@"点击进入答题" forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor greenColor];
    [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn1.frame = CGRectMake(0, 164, SCREEN_WIDTH, 100);
    [btn1 setTitle:@"点击进入详情" forState:UIControlStateNormal];
    btn1.backgroundColor = [UIColor orangeColor];
    [btn1 addTarget:self action:@selector(btn1Action:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn1];
    
}

//点击进入答题跳转方法，所传参数
-(void)btnAction:(id)sender
{
    NSString *userId = @"3494165";
    NSString *examId = @"ad463085b37f4c31ba53c5f8f6d22fa5";
    NSString *pathOfZip = [[NSBundle mainBundle] pathForResource:@"ad463085b37f4c31ba53c5f8f6d22fa5" ofType:@"zip"];
    
    [[TKJYManager sharedClient] pushFromControllerToDoExam:self
                                                withUserId:userId
                                                withExamId:examId
                                           withZipFullPath:pathOfZip
                                                withAppKey:AppKey
                                            responseAction:^(BOOL upLoadStatus)
     {
         if (upLoadStatus == YES)
         {
             NSLog(@"交卷成功，可以在这里加入成功后的处理");
         }
         else
         {
             NSLog(@"交卷失败");
         }
     }];
}

//点击进入详情跳转方法，所传参数
-(void)btn1Action:(id)sender
{
    NSString *userId = @"3494165";
    NSString *examId = @"ad463085b37f4c31ba53c5f8f6d22fa5";
    [[TKJYManager sharedClient] pushFromControllerToReadExamDetail:self withUserId:userId withExamId:examId];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
