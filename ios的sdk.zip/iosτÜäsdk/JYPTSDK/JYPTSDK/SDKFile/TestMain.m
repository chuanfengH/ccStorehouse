//
//  TestMain.m
//  TikuApp
//
//  Created by HuangChuanfeng on 16/9/19.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TestMain.h"

@implementation TestMain

// Insert code here to add functionality to your managed object subclass

@end
