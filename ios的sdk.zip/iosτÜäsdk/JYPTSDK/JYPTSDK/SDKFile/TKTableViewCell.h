//
//  TKTableViewCell.h
//  TikuApp
//
//  Created by huangkeyuan on 16/8/1.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKTableViewCell : UITableViewCell
@property (nonatomic,copy)NSString *detailCellType;
@property (nonatomic,strong)UIImageView *checkImageView;
@property (nonatomic,strong)UILabel *checkLabel;


@end
