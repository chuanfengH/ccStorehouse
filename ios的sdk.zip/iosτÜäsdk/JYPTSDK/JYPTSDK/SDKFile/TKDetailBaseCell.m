//
//  TKDetailBaseCell.m
//  TikuApp
//
//  Created by huangkeyuan on 16/8/23.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKDetailBaseCell.h"

@implementation TKDetailBaseCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)touchSelectButton:(id)sender
{
    //    self.checkButton.selected = YES;
}

@end
