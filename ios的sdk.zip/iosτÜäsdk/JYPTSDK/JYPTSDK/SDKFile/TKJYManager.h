//
//  TKJYManager.h
//  TiKuJYSDK
//
//  Created by huangchuanfeng on 2016/11/7.
//  Copyright © 2016年 LeiMingTech. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TKJYManager : NSObject

@property (readonly, strong, nonatomic) NSManagedObjectContext  * _Nonnull managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel * _Nonnull managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator * _Nonnull persistentStoreCoordinator;

+ (instancetype _Nonnull)sharedClient;
- (void)saveContext;
- (NSURL * _Nonnull)applicationDocumentsDirectory;

/**
 进入做试卷
 */
-(void)pushFromControllerToDoExam:(UIViewController * _Nonnull)myViewController
                       withUserId:(NSString * _Nonnull)userId
                       withExamId:(NSString * _Nonnull)examId
                  withZipFullPath:(NSString * _Nonnull)zipPath
                       withAppKey:(NSString * _Nonnull)appKey
                   responseAction:(nullable void (^)(BOOL upLoadStatus))upLoadSatus;

/**
 查看试卷详情
 */
-(void)pushFromControllerToReadExamDetail:(nullable UIViewController *)myViewController
                               withUserId:(nullable NSString *)userId
                               withExamId:(nullable NSString *)examId;


@end
