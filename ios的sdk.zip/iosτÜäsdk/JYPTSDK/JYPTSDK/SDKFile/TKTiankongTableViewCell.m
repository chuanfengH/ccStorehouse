//
//  TKTiankongTableViewCell.m
//  TikuApp
//
//  Created by huangkeyuan on 16/8/16.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKTiankongTableViewCell.h"

@implementation TKTiankongTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state

}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
#pragma mark 填空题
                _numberLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 20, 30)];
                _numberLabel.text = @"1.";
                _numberLabel.font = [UIFont systemFontOfSize:14];
                _numberLabel.textColor = [UIColor lightGrayColor];
                [self addSubview:_numberLabel];
        
                _tiankongTF = [[UITextField alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_numberLabel.frame), 5, SCREEN_WIDTH - 60, 30)];
                _tiankongTF.placeholder = @"输入对应顺序答案";
                _tiankongTF.borderStyle = UITextBorderStyleRoundedRect;
                _tiankongTF.font = [UIFont systemFontOfSize:14.0];
//                _tiankongTF.delegate = self;
                [self addSubview:_tiankongTF];
    }
    return self;
    
}

//-(void)textFieldDidEndEditing:(UITextField *)textField
//{
//    NSLog(@"%@",textField.text);
//    
//    
//    
//    
//    
//}

@end
