//
//  TestMain+CoreDataProperties.h
//  TikuApp
//
//  Created by HuangChuanfeng on 16/9/19.
//  Copyright © 2016年 leimingtech. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "TestMain.h"

NS_ASSUME_NONNULL_BEGIN

@interface TestMain (CoreDataProperties)

@property (nullable, nonatomic, retain) NSData *answer;
@property (nullable, nonatomic, retain) NSData *child_options;
@property (nullable, nonatomic, retain) NSString *choiceOrder;
@property (nullable, nonatomic, retain) NSString *fileName;
@property (nullable, nonatomic, retain) NSData *options;
@property (nullable, nonatomic, retain) NSNumber *order;
@property (nullable, nonatomic, retain) NSData *questionListOrder;
@property (nullable, nonatomic, retain) NSString *questionModelName;
@property (nullable, nonatomic, retain) NSString *test_id;
@property (nullable, nonatomic, retain) NSString *test_name;
@property (nullable, nonatomic, retain) NSString *title;
@property (nullable, nonatomic, retain) NSString *title_id;
@property (nullable, nonatomic, retain) NSString *type;
@property (nullable, nonatomic, retain) NSString *userid;
@property (nullable, nonatomic, retain) NSString *iscompleted;
@property (nullable, nonatomic, retain) NSString *questionNum;
@property (nullable, nonatomic, retain) NSString *location;

@end

NS_ASSUME_NONNULL_END
