//
//  TKExamHadFinishedVC.m
//  TikuApp
//
//  Created by HuangChuanfeng on 16/9/23.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKExamHadFinishedVC.h"
#import "TKExamHadFinishedCell.h"
#import "TKExamHadFinishedCell_Group1.h"
#import "TKExamHadFinishedCell_Group2.h"
#import "TKScanPictureVCViewController.h"

//统一图片宽高
#define unifyImageWidth 80
#define unifyImageHeight 80
//统一字体大小
#define unifyTextFont 15
//组头图片左间距
#define headerImageLeftMargin 30
//cell图片左间距
#define cellImageLeftMargin 60
//组头文字内容行间距
#define headerLineSpacing 10
//尾部各label间隔距离
#define footerViewBaseSpace 10

@interface TKExamHadFinishedVC ()<UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource>


@property (strong,nonatomic) UITableView         *examDetailTableView;
/** tableView数据源 */
@property (strong,nonatomic) NSMutableDictionary *dataDic;
/** 数据列表(按大题) */
@property (strong,nonatomic) NSArray             *questionsArray;
/** 数据列表(按小题) */
@property (strong,nonatomic) NSMutableArray      *questionsMutArray;
/** 题号标记 */
@property (assign,nonatomic) NSInteger           cellIndexPathRow;
/** 表头高*/
@property (assign,nonatomic) CGFloat             headerHeight;
/** 表尾高*/
@property (assign,nonatomic) CGFloat             footerHeight;
/** 表头title*/
@property (copy,nonatomic)   NSString            *headerTitle;
/** 文本格式*/
@property (strong,nonatomic) NSDictionary        *paraStyleDic;
/** choice我的答案选中状态*/
@property (strong,nonatomic) NSMutableArray      *mutArrMyChoice;
/** 题目选择*/
@property (nonatomic,strong) UIView              *collectBackgroundView;
@property (nonatomic,strong) UICollectionView    *subjectLists;

@property (strong,nonatomic) NSArray             *judgeDataArray;

@end

@implementation TKExamHadFinishedVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.hidden = YES;
    
    UIView *topView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 20)];
    topView.backgroundColor = [UIColor colorWithRed:0.24 green:0.62 blue:0.89 alpha:1];
    [self.view addSubview:topView];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, SCREEN_WIDTH, 44)];
    title.backgroundColor = [UIColor colorWithRed:0.24 green:0.62 blue:0.89 alpha:1];
    title.text = @"查看试卷";
    title.textColor = [UIColor whiteColor];
    title.textAlignment = NSTextAlignmentCenter;
    title.font = [UIFont systemFontOfSize:20.0];
    [self.view addSubview:title];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(15, 20+7, 30, 30);
    [btn setImage:[UIImage imageNamed:@"TKbackButton"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(backBtnClickedAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    UIButton *btnLists = [UIButton buttonWithType:UIButtonTypeCustom];
    btnLists.frame = CGRectMake(SCREEN_WIDTH - 30 - 10, 20+7, 30, 30);
    [btnLists setImage:[UIImage imageNamed:@"TKdetail_right"] forState:UIControlStateNormal];
    [btnLists addTarget:self action:@selector(btnListsTouch:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnLists];
    
    self.examDetailTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_HEIGHT-64-50) style:UITableViewStylePlain];
    self.examDetailTableView.backgroundColor = [UIColor whiteColor];
    self.examDetailTableView.showsVerticalScrollIndicator = NO;
    self.examDetailTableView.showsHorizontalScrollIndicator = NO;
    self.examDetailTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.examDetailTableView.delegate = self;
    self.examDetailTableView.dataSource = self;
    _examDetailTableView.hidden = YES;
    [self.view addSubview:self.examDetailTableView];
    
    _cellIndexPathRow = 0;
    _mutArrMyChoice = [[NSMutableArray alloc] init];
    _questionsMutArray = [[NSMutableArray alloc] init];
    _dataDic = [NSMutableDictionary dictionary];
    _judgeDataArray = [[NSArray alloc] initWithObjects:@"正确",@"错误", nil];
    [self requestExamDetailData];
    
    UIView *bottomLine = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-50, SCREEN_WIDTH, 1)];
    bottomLine.backgroundColor = [UIColor colorWithRed:0.95f green:0.95f blue:0.95f alpha:1.00f];
    [self.view addSubview:bottomLine];
    
    UIButton *btnUp = [UIButton buttonWithType:UIButtonTypeCustom];
    btnUp.frame = CGRectMake(0, SCREEN_HEIGHT-49, SCREEN_WIDTH/2, 49);
    btnUp.backgroundColor = [UIColor whiteColor];
    [btnUp setTitle:@"上一题" forState:UIControlStateNormal];
    [btnUp setImage:[UIImage imageNamed:@"TKdetail_1"] forState:UIControlStateNormal];
    btnUp.titleLabel.font = [UIFont systemFontOfSize:unifyTextFont];
    btnUp.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [btnUp setTitleEdgeInsets:UIEdgeInsetsMake(btnUp.imageView.frame.size.height ,-btnUp.imageView.frame.size.width/2-5, 0.0,0.0)];//文字距离上边框的距离增加imageView的高度，距离左边框减少imageView的宽度，距离下边框和右边框距离不变
    [btnUp setImageEdgeInsets:UIEdgeInsetsMake(-20.0, 0.0,0.0, -btnUp.titleLabel.bounds.size.width)];//图片距离右边框距离减少图片的宽度，其它不边
    [btnUp setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnUp addTarget:self action:@selector(btnUpClickAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnUp];
    
    UISwipeGestureRecognizer *gestureLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeAction:)];
    [gestureLeft setDirection:UISwipeGestureRecognizerDirectionRight];
    [self.view addGestureRecognizer:gestureLeft];
    
    UIButton *btnDown = [UIButton buttonWithType:UIButtonTypeCustom];
    btnDown.frame = CGRectMake(SCREEN_WIDTH/2, SCREEN_HEIGHT-49, SCREEN_WIDTH/2, 49);
    btnDown.backgroundColor = [UIColor whiteColor];
    btnDown.titleLabel.font = [UIFont systemFontOfSize:unifyTextFont];
    [btnDown setImage:[UIImage imageNamed:@"TKdetail_5"] forState:UIControlStateNormal];
    btnDown.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [btnDown setTitleEdgeInsets:UIEdgeInsetsMake(btnDown.imageView.frame.size.height,-btnDown.imageView.frame.size.width, 0.0,0.0)];//文字距离上边框的距离增加imageView的高度，距离左边框减少imageView的宽度，距离下边框和右边框距离不变
    [btnDown setImageEdgeInsets:UIEdgeInsetsMake(-20.0, 0.0,0.0, -45)];//图片距离右边框距离减少图片的宽度，其它不边
    [btnDown setTitle:@"下一题" forState:UIControlStateNormal];
    [btnDown setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnDown addTarget:self action:@selector(btnDownClickAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnDown];
    
    UISwipeGestureRecognizer *gestureRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeAction:)];
    [gestureRight setDirection:UISwipeGestureRecognizerDirectionLeft];
    [self.view addGestureRecognizer:gestureRight];
    
#pragma mark 设置文本格式
    NSMutableParagraphStyle *paraStyle = [[NSMutableParagraphStyle alloc] init];
    paraStyle.lineBreakMode = NSLineBreakByCharWrapping;
    paraStyle.alignment = NSTextAlignmentLeft;
    paraStyle.lineSpacing = headerLineSpacing; //设置行间距
    paraStyle.hyphenationFactor = 0.0;//连字属性 在iOS，唯一支持的值分别为0和1
    paraStyle.firstLineHeadIndent = 0.0;//首行缩进
    paraStyle.paragraphSpacingBefore = 0.0;//段首行空白空间
    paraStyle.headIndent = 0;//整体缩进(首行除外)
    paraStyle.tailIndent = 0;
    //可以增加设置字间距 NSKernAttributeName:@1.5f
    _paraStyleDic = @{NSFontAttributeName:[UIFont systemFontOfSize:unifyTextFont], NSParagraphStyleAttributeName:paraStyle
                      };
    //题目选择页面
    _collectBackgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_HEIGHT - 64)];
    _collectBackgroundView.backgroundColor = [UIColor whiteColor];
    [self.view  addSubview:_collectBackgroundView];
    _collectBackgroundView.hidden = YES;
    UILabel *timuliebiao = [[UILabel alloc] init];
    timuliebiao.text = @"题目列表";
    if (SCREEN_WIDTH==320) {
        timuliebiao.font = [UIFont systemFontOfSize:unifyTextFont];
        timuliebiao.frame = CGRectMake(10, 20, 80, 20);
    }else{
        timuliebiao.font = [UIFont systemFontOfSize:unifyTextFont];
        timuliebiao.frame = CGRectMake(10, 20, 80, 20);
    }
    [_collectBackgroundView addSubview:timuliebiao];
    
    NSArray *labelTextArr = [[NSArray alloc] initWithObjects:@"已答",@"未答",@"答对",@"答错", nil];
    NSArray *labelColorArr = [[NSArray alloc] initWithObjects:[UIColor colorWithRed:0.33f green:0.65f blue:0.88f alpha:1.00f],[UIColor colorWithRed:0.91f green:0.91f blue:0.91f alpha:1.00f],[UIColor colorWithRed:0.40f green:0.81f blue:0.00f alpha:1.00f],[UIColor colorWithRed:0.96f green:0.27f blue:0.25f alpha:1.00f], nil];
    for (int i=0; i<4; i++) {
        if (SCREEN_WIDTH == 320) {
            UILabel *labeColor = [[UILabel alloc] initWithFrame:CGRectMake(80+60*i, 22.5, 15, 15)];
            labeColor.backgroundColor = labelColorArr[i];
            labeColor.clipsToBounds = YES;
            labeColor.layer.cornerRadius = 2.0;
            [_collectBackgroundView addSubview:labeColor];
            
            UILabel *labelSign = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(labeColor.frame)+5, 20, 30, 20)];
            labelSign.text = labelTextArr[i];
            labelSign.font = [UIFont systemFontOfSize:unifyTextFont];
            [_collectBackgroundView addSubview:labelSign];
        }
        else
        {
            UILabel *labeColor = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-70*4+70*i, 20, 20, 20)];
            labeColor.backgroundColor = labelColorArr[i];
            labeColor.clipsToBounds = YES;
            labeColor.layer.cornerRadius = 3.0;
            [_collectBackgroundView addSubview:labeColor];
            
            UILabel *labelSign = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(labeColor.frame)+5, 20, 40, 20)];
            labelSign.text = labelTextArr[i];
            [_collectBackgroundView addSubview:labelSign];
        }
    }
    
#pragma mark 答题列表
    //创建一个layout布局类
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc]init];
    //设置布局方向为垂直流布局
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    //设置每个item的大小为100*100
    layout.minimumLineSpacing = 0;         //上下cell间距
    layout.minimumInteritemSpacing = 0;    //左右cell间距
    //创建collectionView 通过一个布局策略layout来创建
    _subjectLists = [[UICollectionView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(timuliebiao.frame) + 20, SCREEN_WIDTH, SCREEN_HEIGHT - 70 - 64) collectionViewLayout:layout];
    //代理设置
    _subjectLists.backgroundColor = [UIColor whiteColor];
    _subjectLists.delegate=self;
    _subjectLists.dataSource=self;
    //注册item类型 这里使用系统的类型
    [_subjectLists registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellid"];
    
    [_collectBackgroundView addSubview:_subjectLists];
    
}

- (void)requestExamDetailData
{
    NSDictionary *_dic;
    NSString *requestAddress;
    if ([_fromWho isEqualToString:@"exam"]) {
        _dic = @{@"userId":_userId,
                 @"examId":_examId
                 };
        requestAddress = ExaminationDetailedApi;
    }else if ([_fromWho isEqualToString:@"homework"]){
        _dic = @{@"userId":_userId,
                 @"examId":_examId
                 };
        requestAddress = HomeworkDetailApi;
    }else{
        _dic = @{@"userId":_userId,
                 @"paperId":_examId
                 };
        requestAddress = queWrongPaperDetail;
    }
    [[TKAFNetWorkingClient sharedClient] Post:requestAddress
                                   Parameters:_dic
                                      Success:^(id responseObject)
     {
         //请求成功：
         if ([[responseObject objectForKey:@"result"] integerValue] == 1)
         {
             [_dataDic removeAllObjects];
             [_mutArrMyChoice removeAllObjects];
             [_questionsMutArray removeAllObjects];
             _questionsArray = [[responseObject objectForKey:@"data"] valueForKey:@"modelQuestionList"];
             for (NSDictionary* dic in _questionsArray) {
                 if ([[dic valueForKey:@"type"] isEqualToString:@"Group1"] ||
                     [[dic valueForKey:@"type"] isEqualToString:@"Group2"])
                 {
                     NSArray *arr = [dic valueForKey:@"children"];
                     [_questionsMutArray addObjectsFromArray:arr];
                 }
                 else
                 {
                     [_questionsMutArray addObject:dic];
                 }
             }
             _dataDic = [NSMutableDictionary dictionaryWithDictionary:_questionsArray[_cellIndexPathRow]];
             NSArray *arr = [_dataDic valueForKey:@"choiceList"];
             NSString *myAns =[_dataDic valueForKey:@"myAnswer"][0];
             if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
                 if ([myAns isEqualToString:@"true"]) {
                     [_mutArrMyChoice addObject:@"1"];
                     [_mutArrMyChoice addObject:@"0"];
                 }
                 else if ([myAns isEqualToString:@"false"])
                 {
                     [_mutArrMyChoice addObject:@"0"];
                     [_mutArrMyChoice addObject:@"1"];
                 }
                 else
                 {
                     [_mutArrMyChoice addObject:@"0"];
                     [_mutArrMyChoice addObject:@"0"];
                 }
             }
             else
             {
                 for (int i=0; i<arr.count; i++)
                 {
                     NSString *str = [NSString stringWithFormat:@"%c",(char)65+i];
                     if ([myAns rangeOfString:str].location != NSNotFound) {
                         [_mutArrMyChoice addObject:@"1"];
                     }else{
                         [_mutArrMyChoice addObject:@"0"];
                     }
                 }
             }
             [_examDetailTableView setTableHeaderView:[self createTableHeaderView]];
             [_examDetailTableView setTableFooterView:[self createTableFooterView]];
             [_examDetailTableView reloadData];
             [_subjectLists reloadData];
             _examDetailTableView.hidden = NO;
         }
         else
         {
             [MBProgressHUD showAutoMessage:[responseObject objectForKey:@"msg"]];
         }
     } Failure:^(NSError *error) {
         //请求失败
         [MBProgressHUD showError:@"网络错误" ToView:self.view];
     }];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Group1"]) {
        NSArray *array = [_dataDic valueForKey:@"children"];
        return array.count;
    }else if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Group2"]){
        NSArray *array = [_dataDic valueForKey:@"children"];
        return array.count;
    }else{
        NSArray *array = [_dataDic valueForKey:@"choiceList"];
        return array.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Group1"])
    {
        NSArray *choiceArr = [[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"choiceList"];
        CGFloat contentCellTotalHeight = 0;
        for (int j=0; j<choiceArr.count; j++) {
            NSString *cellText = [NSString stringWithFormat:@"A. %@",choiceArr[j]];
            NSArray  *cellTextArr;
            if ([cellText rangeOfString:@"##"].location != NSNotFound)
            {
                cellTextArr = [cellText componentsSeparatedByString:@"##"];
                contentCellTotalHeight = contentCellTotalHeight+[self calculateTextHeight:cellTextArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)]+unifyImageHeight+10+20;
            }
            else
            {
                contentCellTotalHeight = contentCellTotalHeight+[self calculateTextHeight:cellText withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)]+20;
            }
        }
        NSString *nameNumber = [[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"questionNum"];
        NSString *name = [NSString stringWithFormat:@"%@. %@",nameNumber,[[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"name"]];
        NSArray *nameArr;
        CGFloat childNameHeight;
        if ([name rangeOfString:@"##"].location != NSNotFound)
        {
            nameArr = [name componentsSeparatedByString:@"##"];
            childNameHeight = [self calculateTextHeight:nameArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+unifyImageHeight+10+20;
        }
        else
        {
            childNameHeight = [self calculateTextHeight:name withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+20;
        }
        _footerHeight = 0;
        //正确答案的高度
        NSArray *tureAnswer = [[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"answer"];
        NSString *rightAnswerText;
        for (int i = 0; i < tureAnswer.count; i++) {
            if (i == 0) {
                rightAnswerText = [NSString stringWithFormat:@"正确答案: %@",tureAnswer[0]];
            }else{
                rightAnswerText = [NSString stringWithFormat:@"%@,%@",rightAnswerText,tureAnswer[i]];
            }
        }
        CGFloat rightAnsHei = [self calculateTextHeight:rightAnswerText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        //我的答案的高度
        NSArray *myAnswer = [_dataDic valueForKey:@"myAnswer"];
        NSString *myAnswerText;
        
        for (int i = 0; i < myAnswer.count; i++) {
            if (i == 0) {
                myAnswerText = [NSString stringWithFormat:@"我的答案: %@",myAnswer[0]];
            }else{
                myAnswerText = [NSString stringWithFormat:@"%@,%@",myAnswerText,myAnswer[i]];
            }
        }
        CGFloat myAnsHei = [self calculateTextHeight:myAnswerText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        //答案分析的高度
        NSString *answerAnalyText = [NSString stringWithFormat:@"答案解析: %@",[[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"answerResolve"]];
        NSArray  *answerAnalyArr;
        CGFloat ansAnalyHei;
        if ([answerAnalyText rangeOfString:@"##"].location != NSNotFound)
        {
            answerAnalyArr = [answerAnalyText componentsSeparatedByString:@"##"];
            ansAnalyHei = [self calculateTextHeight:answerAnalyArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+90;
        }
        else
        {
            ansAnalyHei = [self calculateTextHeight:answerAnalyText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        }
        //得分高度
        CGFloat ansGetGradeHei = [self calculateTextHeight:@"得分:" withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        
        _footerHeight = 10+rightAnsHei+10+ansAnalyHei+10+ansGetGradeHei+10+myAnsHei+10+40+20;
        
        CGFloat cellHeight = childNameHeight+contentCellTotalHeight+_footerHeight+10;
        return cellHeight;
    }
    else if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Group2"])
    {
        NSString *nameNumber = [[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"questionNum"];
        NSString *name = [NSString stringWithFormat:@"%@. %@",nameNumber,[[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"name"]];
        NSArray *nameArr;
        CGFloat childNameHeight;
        if ([name rangeOfString:@"##"].location != NSNotFound)
        {
            nameArr = [name componentsSeparatedByString:@"##"];
            childNameHeight = [self calculateTextHeight:nameArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+unifyImageHeight+10+20;
        }
        else
        {
            childNameHeight = [self calculateTextHeight:name withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+20;
        }
        _footerHeight = 0;
        //正确答案的高度
        NSArray *tureAnswer = [[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"answer"];
        NSString *rightAnswerText;
        for (int i = 0; i < tureAnswer.count; i++) {
            if (i == 0) {
                rightAnswerText = [NSString stringWithFormat:@"正确答案: %@",tureAnswer[0]];
            }else{
                rightAnswerText = [NSString stringWithFormat:@"%@,%@",rightAnswerText,tureAnswer[i]];
            }
        }
        CGFloat rightAnsHei = [self calculateTextHeight:rightAnswerText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        //我的答案的高度
        NSArray *myAnswer = [_dataDic valueForKey:@"myAnswer"];
        NSString *myAnswerText;
        
        for (int i = 0; i < myAnswer.count; i++) {
            if (i == 0) {
                myAnswerText = [NSString stringWithFormat:@"我的答案: %@",myAnswer[0]];
            }else{
                myAnswerText = [NSString stringWithFormat:@"%@,%@",myAnswerText,myAnswer[i]];
            }
        }
        CGFloat myAnsHei = [self calculateTextHeight:myAnswerText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        //答案分析的高度
        NSString *answerAnalyText = [NSString stringWithFormat:@"答案解析: %@",[[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"answerResolve"]];
        NSArray  *answerAnalyArr;
        CGFloat ansAnalyHei;
        if ([answerAnalyText rangeOfString:@"##"].location != NSNotFound)
        {
            answerAnalyArr = [answerAnalyText componentsSeparatedByString:@"##"];
            ansAnalyHei = [self calculateTextHeight:answerAnalyArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+unifyImageHeight+10;
        }
        else
        {
            ansAnalyHei = [self calculateTextHeight:answerAnalyText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        }
        //得分高度
        CGFloat ansGetGradeHei = [self calculateTextHeight:@"得分:" withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        
        _footerHeight = 10+rightAnsHei+10+ansAnalyHei+10+ansGetGradeHei+10+myAnsHei+10+40+20;
        
        CGFloat cellHeight = childNameHeight+_footerHeight+10;
        return cellHeight;
    }
    else
    {
        NSArray *choiceArr = [_dataDic valueForKey:@"choiceList"];
        if (choiceArr.count > 0) {
            NSString *cellText = [NSString stringWithFormat:@"A. %@",choiceArr[indexPath.row]];
            CGFloat cellHeight = 0;
            NSArray *cellTextArr;
            if ([cellText rangeOfString:@"##"].location != NSNotFound)
            {
                cellTextArr = [cellText componentsSeparatedByString:@"##"];
                cellHeight = [self calculateTextHeight:cellTextArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)]+unifyImageHeight+10;
            }
            else
            {
                cellHeight = [self calculateTextHeight:cellText withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)];
            }
            return cellHeight+20;
        }else{
            return 0;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Group1"])
    {
        TKExamHadFinishedCell_Group1 *cell = [tableView dequeueReusableCellWithIdentifier:@"examFinishDetailCellGroup1"];
        if (!cell) {
            cell = [[TKExamHadFinishedCell_Group1 alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"examFinishDetailCellGroup1"];
        }
        cell.dataDic = [_dataDic valueForKey:@"children"][indexPath.row];
        cell.paraStyleDic = _paraStyleDic;
        NSString *childName = [[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"name"];
        NSString *childNumber = [[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"questionNum"];
        cell.childName = [NSString stringWithFormat:@"%@. %@",childNumber,childName];
        __weak __typeof(&*self)weakSelf = self;
        cell.requestDataAgain = ^(NSString *message){
            [MBProgressHUD showMessage:message ToView:self.view RemainTime:1.0];
            [weakSelf requestExamDetailData];
        };
        cell.openImageViewer = ^(NSArray *images,NSInteger index){
            TKScanPictureVCViewController *vc = [[TKScanPictureVCViewController alloc] init];
            vc.arrPicData = images;
            vc.index = index;
            [self.navigationController pushViewController:vc animated:NO];
        };
        [cell.contentGroup1TableView reloadData];
        return cell;
    }
    else if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Group2"])
    {
        TKExamHadFinishedCell_Group2 *cell = [tableView dequeueReusableCellWithIdentifier:@"examFinishDetailCellGroup2"];
        if (!cell) {
            cell = [[TKExamHadFinishedCell_Group2 alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"examFinishDetailCellGroup2"];
        }
        cell.dataDic = [_dataDic valueForKey:@"children"][indexPath.row];
        cell.paraStyleDic = _paraStyleDic;
        NSString *childName = [[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"name"];
        NSString *childNumber = [[_dataDic valueForKey:@"children"][indexPath.row] valueForKey:@"questionNum"];
        cell.childName = [NSString stringWithFormat:@"%@. %@",childNumber,childName];
        __weak __typeof(&*self)weakSelf = self;
        cell.requestDataAgain = ^(NSString *message){
            [MBProgressHUD showMessage:message ToView:self.view RemainTime:1.0];
            [weakSelf requestExamDetailData];
        };
        cell.openImageViewer = ^(NSArray *images,NSInteger index){
            TKScanPictureVCViewController *vc = [[TKScanPictureVCViewController alloc] init];
            vc.arrPicData = images;
            vc.index = index;
            [self.navigationController pushViewController:vc animated:NO];
        };
        [cell.contentGroup2TableView reloadData];
        return cell;
    }
    else
    {
        TKExamHadFinishedCell *cell = [[TKExamHadFinishedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        char c = (char)65+indexPath.row;
        NSString *cellText = [NSString stringWithFormat:@"%c. %@",c,[_dataDic valueForKey:@"choiceList"][indexPath.row]];
        NSArray  *cellTextArr;
        CGFloat  labelHeight = 0;
        if ([cellText rangeOfString:@"##"].location != NSNotFound)
        {
            cellTextArr = [cellText componentsSeparatedByString:@"##"];
            labelHeight = [self calculateTextHeight:cellTextArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)];
            cell.btnChoice.frame = CGRectMake(15, 8, 25, 25);
            cell.labelChoice.frame = CGRectMake(CGRectGetMaxX(cell.btnChoice.frame)+6, 10, SCREEN_WIDTH-(CGRectGetMaxX(cell.btnChoice.frame)+10+15+10+10), labelHeight);
            cell.imgViewRight.frame = CGRectMake(CGRectGetMaxX(cell.labelChoice.frame)+10, 10, 20, 20);
            if (labelHeight < 18) {
                cell.labelChoice.text = cellTextArr[0];
            }else{
                NSAttributedString *attributeStr = [[NSAttributedString alloc] initWithString:cellTextArr[0] attributes:_paraStyleDic];
                cell.labelChoice.attributedText = attributeStr;
            }
            for (int i =1; i<cellTextArr.count; i++) {
                UIImageView *imageView = [cell viewWithTag:300+i];
                imageView.frame = CGRectMake(cellImageLeftMargin+(unifyImageWidth+10)*(i-1), CGRectGetMaxY(cell.labelChoice.frame)+10, unifyImageWidth, unifyImageHeight);
                NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,cellTextArr[i]];
                NSURL *url = [NSURL URLWithString:urlStr];
                [imageView sd_setImageWithURL:url placeholderImage:nil];
                imageView.userInteractionEnabled = YES;
                UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapFooterAction:)];
                [imageView addGestureRecognizer:tap];
                imageView.tag = 20+100*(indexPath.row)+i;
            }
        }
        else
        {
            labelHeight = [self calculateTextHeight:cellText withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)];
            cell.btnChoice.frame = CGRectMake(15, 8, 25, 25);
            cell.labelChoice.frame = CGRectMake(CGRectGetMaxX(cell.btnChoice.frame)+6, 10, SCREEN_WIDTH-(CGRectGetMaxX(cell.btnChoice.frame)+10+15+10+10), labelHeight);
            if (labelHeight < 18) {
                cell.labelChoice.text = cellText;
            }else{
                NSAttributedString *attributeStr = [[NSAttributedString alloc] initWithString:cellText attributes:_paraStyleDic];
                cell.labelChoice.attributedText = attributeStr;
            }
            cell.imgViewRight.frame = CGRectMake(CGRectGetMaxX(cell.labelChoice.frame)+10, 10, 20, 20);
            for (int i =1; i<4; i++) {
                UIImageView *imageView = [cell viewWithTag:300+i];
                imageView.frame = CGRectZero;
            }
        }
        if ([[_dataDic valueForKey:@"type"] isEqualToString:@"MultiChoice"])
        {
            if (_mutArrMyChoice.count > 0) {
                if ([_mutArrMyChoice[indexPath.row] isEqualToString:@"0"]) {
                    [cell.btnChoice setBackgroundImage:[UIImage imageNamed:@"TKtiankong_unselect"] forState:UIControlStateNormal];
                    [cell.imgViewRight setImage:nil];
                }else{
                    if ([[_dataDic valueForKey:@"isRight"] integerValue] == 0) {
                        [cell.imgViewRight setImage:[UIImage imageNamed:@"TKicon_error"]];
                        [cell.btnChoice setBackgroundImage:[UIImage imageNamed:@"TKtiankong_selectDetail"] forState:UIControlStateNormal];
                    }else{
                        [cell.imgViewRight setImage:[UIImage imageNamed:@"TKicon_right"]];
                        [cell.btnChoice setBackgroundImage:[UIImage imageNamed:@"TKtiankong_select"] forState:UIControlStateNormal];
                    }
                }
            }
        }
        else
        {
            if (_mutArrMyChoice.count > 0) {
                if ([_mutArrMyChoice[indexPath.row] isEqualToString:@"0"]) {
                    [cell.btnChoice setBackgroundImage:[UIImage imageNamed:@"TKdetail_unselect"] forState:UIControlStateNormal];
                    [cell.imgViewRight setImage:nil];
                }else{
                    if ([[_dataDic valueForKey:@"isRight"] integerValue] == 0) {
                        [cell.imgViewRight setImage:[UIImage imageNamed:@"TKicon_error"]];
                        [cell.btnChoice setBackgroundImage:[UIImage imageNamed:@"TKdetail_selectError"] forState:UIControlStateNormal];
                    }else{
                        [cell.imgViewRight setImage:[UIImage imageNamed:@"TKicon_right"]];
                        [cell.btnChoice setBackgroundImage:[UIImage imageNamed:@"TKdetail_select"] forState:UIControlStateNormal];
                    }
                }
            }
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (CGFloat)getHeaderViewHeight
{
    if (_dataDic != nil)
    {
        NSString *type = [_dataDic valueForKey:@"type"];
        _headerHeight = 0;
        if([type isEqualToString:@"Group2"])
        {
            _headerTitle = [_dataDic valueForKey:@"name"];
            _headerHeight = [self calculateTextHeight:_headerTitle withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+10+20;
            
            NSArray *choiceArr = [_dataDic valueForKey:@"choiceList"];
            CGFloat contentCellTotalHeight = 0;
            for (int j=0; j<choiceArr.count; j++) {
                char c = (char)65+j;
                NSString *cellText = [NSString stringWithFormat:@"%c、%@",c,choiceArr[j]];
                NSArray  *cellTextArr;
                if ([cellText rangeOfString:@"##"].location != NSNotFound)
                {
                    cellTextArr = [cellText componentsSeparatedByString:@"##"];
                    contentCellTotalHeight = contentCellTotalHeight+[self calculateTextHeight:cellTextArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+10+unifyImageHeight+20;
                }
                else
                {
                    contentCellTotalHeight = contentCellTotalHeight+[self calculateTextHeight:cellText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+20;
                }
            }
            return _headerHeight+contentCellTotalHeight+30;
        }
        else
        {
            NSString *nameNumber = [_dataDic valueForKey:@"questionNum"];
            NSString *name = [NSString stringWithFormat:@"%@. %@",nameNumber,[_dataDic valueForKey:@"name"]];
            name = [name stringByReplacingOccurrencesOfString:@"[]" withString:@"____"];
            if ([type isEqualToString:@"Group1"]) {
                name = [_dataDic valueForKey:@"name"];
            }
            NSArray *nameArr;
            if ([name rangeOfString:@"##"].location != NSNotFound)
            {
                nameArr = [name componentsSeparatedByString:@"##"];
                _headerHeight = [self calculateTextHeight:nameArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+90;
                _headerTitle = nameArr[0];
            }
            else
            {
                _headerHeight = [self calculateTextHeight:name withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
                _headerTitle = name;
            }
            return _headerHeight+20;
        }
    }
    else{
        return 0;
    }
}

- (UIView*)createTableHeaderView
{
    if (![[_dataDic valueForKey:@"type"] isEqualToString:@"Group2"])
    {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, [self getHeaderViewHeight]+40)];
        
        UILabel *labelModel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, SCREEN_WIDTH-30, 40-0.5)];
        labelModel.font = [UIFont systemFontOfSize:unifyTextFont+2];
        labelModel.text = [_dataDic valueForKey:@"modelName"];
        [headerView addSubview:labelModel];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(labelModel.frame), SCREEN_WIDTH-30, 0.5)];
        line.backgroundColor = [UIColor colorWithRed:0.94f green:0.94f blue:0.94f alpha:1.00f];
        [headerView addSubview:line];
        
        CGFloat titleHeight = [self calculateTextHeight:_headerTitle withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        UILabel *labelTitle = [[UILabel alloc] initWithFrame:CGRectMake(15, 50, SCREEN_WIDTH-30, titleHeight)];
        labelTitle.font = [UIFont systemFontOfSize:unifyTextFont];
        labelTitle.numberOfLines = 0;
        if (_headerTitle.length > 0) {
            if (titleHeight < 18) {
                labelTitle.text = _headerTitle;
            }else{
                NSAttributedString *attributeStr = [[NSAttributedString alloc] initWithString:_headerTitle attributes:_paraStyleDic];
                labelTitle.attributedText = attributeStr;
            }
        }
        [headerView addSubview:labelTitle];
        NSString *nameNumber = [_dataDic valueForKey:@"questionNum"];
        NSString *name = [NSString stringWithFormat:@"%@. %@",nameNumber,[_dataDic valueForKey:@"name"]];
        if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Group1"]) {
            name = [_dataDic valueForKey:@"name"];
        }
        if ([name rangeOfString:@"##"].location != NSNotFound)
        {
            NSArray *nameArr = [name componentsSeparatedByString:@"##"];
            for (int i = 1; i<nameArr.count; i++)
            {
                NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
                NSURL *url = [NSURL URLWithString:urlStr];
                UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(cellImageLeftMargin+90*(i-1), CGRectGetMaxY(labelTitle.frame)+10, unifyImageWidth, unifyImageHeight)];
                [imgView sd_setImageWithURL:url placeholderImage:nil];
                imgView.tag = i+10;
                imgView.userInteractionEnabled = YES;
                UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapHeaderAction:)];
                [imgView addGestureRecognizer:tap];
                [headerView addSubview:imgView];
            }
        }
        return headerView;
    }
    else
    {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, [self getHeaderViewHeight]+40)];
        
        UILabel *labelModel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, SCREEN_WIDTH-30, 40-0.5)];
        labelModel.font = [UIFont systemFontOfSize:unifyTextFont+2];
        labelModel.text = [_dataDic valueForKey:@"modelName"];
        [headerView addSubview:labelModel];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(labelModel.frame), SCREEN_WIDTH-30, 0.5)];
        line.backgroundColor = [UIColor colorWithRed:0.94f green:0.94f blue:0.94f alpha:1.00f];
        [headerView addSubview:line];
        
        CGFloat titleHeight = [self calculateTextHeight:_headerTitle withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        UILabel *labelName = [[UILabel alloc] initWithFrame:CGRectMake(15, 50, SCREEN_WIDTH-30, titleHeight)];
        labelName.font = [UIFont systemFontOfSize:unifyTextFont];
        labelName.numberOfLines = 0;
        if (_headerTitle.length > 0) {
            if (titleHeight < 18) {
                labelName.text = _headerTitle;
            }else{
                NSAttributedString *attributeStr = [[NSAttributedString alloc] initWithString:_headerTitle attributes:_paraStyleDic];
                labelName.attributedText = attributeStr;
            }
        }
        [headerView addSubview:labelName];
        
        NSArray *choiceArr = [_dataDic valueForKey:@"choiceList"];
        for (int j=0; j<choiceArr.count; j++)
        {
            char c = (char)65+j;
            NSString *name = [NSString stringWithFormat:@"%c. %@",c,choiceArr[j]];
            if (j==0)
            {
                NSArray  *nameArr;
                CGFloat labelTitleHei = 0;
                if ([name rangeOfString:@"##"].location != NSNotFound)
                {
                    nameArr = [name componentsSeparatedByString:@"##"];
                    labelTitleHei = [self calculateTextHeight:nameArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
                    
                    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(labelName.frame)+20, SCREEN_WIDTH-30, labelTitleHei)];
                    if (labelTitleHei<18) {
                        label.text = nameArr[0];
                    }else{
                        NSAttributedString *analyStr = [[NSAttributedString alloc] initWithString:nameArr[0] attributes:_paraStyleDic];
                        label.attributedText = analyStr;
                    }
                    label.font = [UIFont systemFontOfSize:unifyTextFont];
                    label.text = [NSString stringWithFormat:@"%@",nameArr[0]];
                    label.numberOfLines = 0;
                    label.tag = 8000;
                    [headerView addSubview:label];
                    for (int i = 1; i<nameArr.count; i++)
                    {
                        NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
                        NSURL *url = [NSURL URLWithString:urlStr];
                        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(cellImageLeftMargin+(unifyImageWidth+10)*(i-1), CGRectGetMaxY(label.frame)+10, unifyImageWidth, unifyImageHeight)];
                        [imgView sd_setImageWithURL:url placeholderImage:nil];
                        imgView.userInteractionEnabled = YES;
                        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapHeaderAction:)];
                        [imgView addGestureRecognizer:tap];
                        imgView.tag = 20+10*j+i;
                        [headerView addSubview:imgView];
                    }
                }
                else
                {
                    labelTitleHei = [self calculateTextHeight:name withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
                    UILabel *labelTitle = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(labelName.frame)+20, SCREEN_WIDTH-30, labelTitleHei)];
                    if (labelTitleHei<18) {
                        labelTitle.text = name;
                    }else{
                        NSAttributedString *analyStr = [[NSAttributedString alloc] initWithString:nameArr[0] attributes:_paraStyleDic];
                        labelTitle.attributedText = analyStr;
                    }
                    labelTitle.font = [UIFont systemFontOfSize:unifyTextFont];
                    labelTitle.numberOfLines = 0;
                    labelTitle.tag = 8000;
                    labelTitle.text = [NSString stringWithFormat:@"%@",name];
                    [headerView addSubview:labelTitle];
                }
            }
            else
            {
                NSArray  *nameArr;
                CGFloat labelTitleHei = 0;
                if ([name rangeOfString:@"##"].location != NSNotFound)
                {
                    nameArr = [name componentsSeparatedByString:@"##"];
                    labelTitleHei = [self calculateTextHeight:nameArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
                    
                    UILabel *ll = [headerView viewWithTag:8000+j-1];
                    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(ll.frame)+20, SCREEN_WIDTH-30, labelTitleHei)];
                    label.font = [UIFont systemFontOfSize:unifyTextFont];
                    label.text = [NSString stringWithFormat:@"%@",nameArr[0]];
                    label.numberOfLines = 0;
                    label.tag = 8000+j;
                    [headerView addSubview:label];
                    
                    for (int i = 1; i<nameArr.count; i++)
                    {
                        NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
                        NSURL *url = [NSURL URLWithString:urlStr];
                        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(cellImageLeftMargin+(unifyImageWidth+10)*(i-1), CGRectGetMaxY(label.frame)+10, unifyImageWidth, unifyImageHeight)];
                        [imgView sd_setImageWithURL:url placeholderImage:nil];
                        imgView.userInteractionEnabled = YES;
                        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapHeaderAction:)];
                        [imgView addGestureRecognizer:tap];
                        imgView.tag = 20+10*j+i;
                        [headerView addSubview:imgView];
                    }
                }
                else
                {
                    UILabel *ll = [headerView viewWithTag:8000+j-1];
                    labelTitleHei = [self calculateTextHeight:name withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
                    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(ll.frame)+20, SCREEN_WIDTH-30, labelTitleHei)];
                    label.font = [UIFont systemFontOfSize:unifyTextFont];
                    label.text = [NSString stringWithFormat:@"%@",name];
                    label.numberOfLines = 0;
                    label.tag = 8000+j;
                    [headerView addSubview:label];
                }
            }
        }
        return headerView;
    }
}

- (UIView*)createTableFooterView
{
    if (![[_dataDic valueForKey:@"type"] isEqualToString:@"Group1"] &&
        ![[_dataDic valueForKey:@"type"] isEqualToString:@"Group2"])
    {
        _footerHeight = 0;
        
        //正确答案的高度
        NSArray *tureAnswer = [_dataDic valueForKey:@"answer"];
        NSString *rightAnswerText;
        
        for (int i = 0; i < tureAnswer.count; i++) {
            if (i == 0)
            {
                if ([tureAnswer[i] isEqualToString:@"false"]) {
                    rightAnswerText = @"正确答案: B";
                }else if ([tureAnswer[i] isEqualToString:@"true"]){
                    rightAnswerText = @"正确答案: A";
                }
                else{
                    if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Fill"]) {
                        rightAnswerText = [NSString stringWithFormat:@"正确答案: [%@]",tureAnswer[i]];
                    }else{
                        rightAnswerText = [NSString stringWithFormat:@"正确答案: %@",tureAnswer[i]];
                    }
                }
            }else{
                if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Fill"]) {
                    rightAnswerText = [NSString stringWithFormat:@"%@,[%@]",rightAnswerText,tureAnswer[i]];
                }else{
                    rightAnswerText = [NSString stringWithFormat:@"%@,%@",rightAnswerText,tureAnswer[i]];
                }
            }
        }
        CGFloat rightAnsHei = [self calculateTextHeight:rightAnswerText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        //我的答案的高度
        NSArray *myAnswer = [_dataDic valueForKey:@"myAnswer"];
        NSString *myAnswerText;
        
        for (int i = 0; i < myAnswer.count; i++) {
            if (i == 0) {
                if ([myAnswer[i] isEqualToString:@"false"]) {
                    myAnswerText = @"我的答案: B";
                }else if ([myAnswer[i] isEqualToString:@"true"]){
                    myAnswerText = @"我的答案: A";
                }else{
                    if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Fill"]) {
                        myAnswerText = [NSString stringWithFormat:@"我的答案: [%@]",myAnswer[i]];
                    }else{
                        myAnswerText = [NSString stringWithFormat:@"我的答案: %@",myAnswer[i]];
                    }
                }
            }else{
                if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Fill"]) {
                    myAnswerText = [NSString stringWithFormat:@"%@,[%@]",myAnswerText,myAnswer[i]];
                }else{
                    myAnswerText = [NSString stringWithFormat:@"%@,%@",myAnswerText,myAnswer[i]];
                }
            }
        }
        CGFloat myAnsHei = [self calculateTextHeight:myAnswerText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        
        //答案分析的高度
        NSString *answerAnalyText = [NSString stringWithFormat:@"答案解析: %@",[_dataDic valueForKey:@"answerResolve"]];
        NSArray  *answerAnalyArr;
        CGFloat ansAnalyHei;
        if ([answerAnalyText rangeOfString:@"##"].location != NSNotFound)
        {
            answerAnalyArr = [answerAnalyText componentsSeparatedByString:@"##"];
            ansAnalyHei = [self calculateTextHeight:answerAnalyArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+90;
        }
        else
        {
            ansAnalyHei = [self calculateTextHeight:answerAnalyText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        }
        //得分高度
        CGFloat ansGetGradeHei = [self calculateTextHeight:@"得分:" withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        //尾部视图高度
        _footerHeight = 10+rightAnsHei+10+myAnsHei+10+ansAnalyHei+10+ansGetGradeHei+10+40+10+20;
        
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, _footerHeight)];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(15, 10, SCREEN_WIDTH-30, 0.5)];
        line.backgroundColor = [UIColor colorWithRed:0.94f green:0.94f blue:0.94f alpha:1.00f];
        [footerView addSubview:line];
        //正确答案label
        UILabel *labelRightAnswer = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(line.frame)+footerViewBaseSpace, SCREEN_WIDTH-30, rightAnsHei)];
        labelRightAnswer.numberOfLines = 0;
        labelRightAnswer.textColor = [UIColor colorWithRed:0.15f green:0.56f blue:0.10f alpha:1.00f];
        labelRightAnswer.font = [UIFont systemFontOfSize:unifyTextFont];
        if (rightAnswerText.length > 0) {
            if (rightAnsHei < 18) {
                labelRightAnswer.text = rightAnswerText;
            }else{
                NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:rightAnswerText attributes:_paraStyleDic];
                labelRightAnswer.attributedText = rightStr;
            }
        }
        [footerView addSubview:labelRightAnswer];
        
        //我的答案label
        UILabel *labelMyAnswer = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(labelRightAnswer.frame)+footerViewBaseSpace, SCREEN_WIDTH-30, myAnsHei)];
        labelMyAnswer.numberOfLines = 0;
        labelMyAnswer.textColor = [UIColor colorWithRed:1.00f green:0.00f blue:0.00f alpha:1.00f];
        labelMyAnswer.font = [UIFont systemFontOfSize:unifyTextFont];
        if (myAnswerText.length > 0) {
            if (myAnsHei < 18) {
                labelMyAnswer.text = myAnswerText;
            }else{
                NSAttributedString *myStr = [[NSAttributedString alloc] initWithString:myAnswerText attributes:_paraStyleDic];
                labelMyAnswer.attributedText = myStr;
            }
        }
        [footerView addSubview:labelMyAnswer];
        
        //得分label
        UILabel *labelAnswerGetGrade = [[UILabel alloc] init];
        
        //答案解析label
        if ([answerAnalyText rangeOfString:@"##"].location != NSNotFound)
        {
            UILabel *labelAnswerAnalysis = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(labelMyAnswer.frame)+footerViewBaseSpace, SCREEN_WIDTH-30, ansAnalyHei)];
            
            labelAnswerAnalysis.numberOfLines = 0;
            labelAnswerAnalysis.textColor = [UIColor blackColor];
            labelAnswerAnalysis.font = [UIFont systemFontOfSize:unifyTextFont];
            if (ansAnalyHei < 18) {
                labelAnswerAnalysis.text = answerAnalyArr[0];
            }else{
                NSAttributedString *analyStr = [[NSAttributedString alloc] initWithString:answerAnalyArr[0] attributes:_paraStyleDic];
                labelAnswerAnalysis.attributedText = analyStr;
            }
            
            [footerView addSubview:labelAnswerAnalysis];
            
            for (int i = 1; i<answerAnalyArr.count; i++)
            {
                NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,answerAnalyArr[i]];
                NSURL *url = [NSURL URLWithString:urlStr];
                UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(15+(unifyImageWidth+10)*(i-1), CGRectGetMaxY(labelAnswerAnalysis.frame)+footerViewBaseSpace, unifyImageWidth, unifyImageHeight)];
                [imgView sd_setImageWithURL:url placeholderImage:nil];
                imgView.userInteractionEnabled = YES;
                UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapFooterAction:)];
                imgView.tag = 10+i;
                [imgView addGestureRecognizer:tap];
                [footerView addSubview:imgView];
            }
            labelAnswerGetGrade.frame = CGRectMake(15, CGRectGetMaxY(labelAnswerAnalysis.frame)+unifyImageHeight+footerViewBaseSpace, (SCREEN_WIDTH-30)/2, ansGetGradeHei);
        }
        else
        {
            //答案解析
            UILabel *labelAnswerAnalysis = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(labelMyAnswer.frame)+footerViewBaseSpace, SCREEN_WIDTH-30, ansAnalyHei)];
            
            labelAnswerAnalysis.numberOfLines = 0;
            labelAnswerAnalysis.textColor = [UIColor blackColor];
            labelAnswerAnalysis.font = [UIFont systemFontOfSize:unifyTextFont];
            if (ansAnalyHei < 18) {
                labelAnswerAnalysis.text = answerAnalyText;
            }else{
                NSAttributedString *analyStr = [[NSAttributedString alloc] initWithString:answerAnalyText attributes:_paraStyleDic];
                labelAnswerAnalysis.attributedText = analyStr;
            }
            [footerView addSubview:labelAnswerAnalysis];
            labelAnswerGetGrade.frame = CGRectMake(15, CGRectGetMaxY(labelAnswerAnalysis.frame)+footerViewBaseSpace, (SCREEN_WIDTH-30)/2, ansGetGradeHei);
        }
        //得分
        labelAnswerGetGrade.numberOfLines = 0;
        labelAnswerGetGrade.textColor = [UIColor blackColor];
        labelAnswerGetGrade.font = [UIFont systemFontOfSize:unifyTextFont];
        labelAnswerGetGrade.text = [NSString stringWithFormat:@"得分: %@",[_dataDic valueForKey:@"actualScore"]];
        [footerView addSubview:labelAnswerGetGrade];
        
        //收藏按钮
        UIButton *btnCollect = [UIButton buttonWithType:UIButtonTypeCustom];
        btnCollect.titleLabel.font = [UIFont systemFontOfSize:unifyTextFont];
        btnCollect.backgroundColor = [UIColor colorWithRed:0.19f green:0.60f blue:0.92f alpha:1.00f];
        [btnCollect setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btnCollect.clipsToBounds = YES;
        btnCollect.layer.cornerRadius = 3.0;
        [btnCollect addTarget:self action:@selector(btnCollectAction:) forControlEvents:UIControlEventTouchUpInside];
        btnCollect.titleLabel.textAlignment = NSTextAlignmentLeft;
        if ([[_dataDic valueForKey:@"isCollect"] integerValue] == 0) {
            [btnCollect setImage:[UIImage imageNamed:@"TKcollect_star"] forState:UIControlStateNormal];
            [btnCollect setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 40)];
            [btnCollect setTitleEdgeInsets:UIEdgeInsetsMake(0, -25, 0, 0)];
            btnCollect.frame = CGRectMake(15, CGRectGetMaxY(labelAnswerGetGrade.frame)+footerViewBaseSpace, 70, 30);
            [btnCollect setTitle:@"收藏" forState:UIControlStateNormal];
        }else
        {
            [btnCollect setImage:[UIImage imageNamed:@"TKcollected_star"] forState:UIControlStateNormal];
            [btnCollect setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 70)];
            [btnCollect setTitleEdgeInsets:UIEdgeInsetsMake(0, -25, 0, 0)];
            btnCollect.frame = CGRectMake(15, CGRectGetMaxY(labelAnswerGetGrade.frame)+footerViewBaseSpace, 100, 30);
            [btnCollect setTitle:@"取消收藏" forState:UIControlStateNormal];
        }
        [footerView addSubview:btnCollect];
        
        return footerView;
    }
    else
    {
        return nil;
    }
}

/** 计算label内容有多行的高度(正常字体) */
- (CGFloat)calculateTextHeight:(NSString*)text withLimitSize:(CGSize)limitSize
{
    //    NSAttributedString *attributeStr = [[NSAttributedString alloc] initWithString:text attributes:dic];
    //limitSize == CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)
    CGSize size = [text boundingRectWithSize:limitSize options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;
    CGFloat oneRowHeight = [text sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:unifyTextFont]}].height;
    NSInteger rows = size.height / oneRowHeight;//rows 是label有几行
    if (rows == 1) {
        size = CGSizeMake(size.width, oneRowHeight);
    }
    return size.height;
}

- (void)btnUpClickAction:(id)sender
{
    if (_dataDic != nil) {
        if (_cellIndexPathRow == 0) {
            [MBProgressHUD showMessage:@"已经是第一题了" ToView:self.view RemainTime:1.0];
        }else{
            [_mutArrMyChoice removeAllObjects];
            _cellIndexPathRow -= 1;
            _dataDic = [NSMutableDictionary dictionaryWithDictionary:_questionsArray[_cellIndexPathRow]];
            if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
                [_dataDic setObject:_judgeDataArray forKey:@"choiceList"];
            }
            NSArray *arr = [_dataDic valueForKey:@"choiceList"];
            NSString *myAns;
            if ([[_dataDic valueForKey:@"myAnswer"] count]>0) {
                myAns =[_dataDic valueForKey:@"myAnswer"][0];
            }
            if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
                if ([myAns isEqualToString:@"true"]) {
                    [_mutArrMyChoice addObject:@"1"];
                    [_mutArrMyChoice addObject:@"0"];
                }
                else if ([myAns isEqualToString:@"false"])
                {
                    [_mutArrMyChoice addObject:@"0"];
                    [_mutArrMyChoice addObject:@"1"];
                }
                else
                {
                    [_mutArrMyChoice addObject:@"0"];
                    [_mutArrMyChoice addObject:@"0"];
                }
            }
            else
            {
                for (int i=0; i<arr.count; i++)
                {
                    NSString *str = [NSString stringWithFormat:@"%c",(char)65+i];
                    if ([myAns rangeOfString:str].location != NSNotFound) {
                        [_mutArrMyChoice addObject:@"1"];
                    }else{
                        [_mutArrMyChoice addObject:@"0"];
                    }
                }
            }
            [self.examDetailTableView setContentOffset:CGPointMake(0,0) animated:NO];
            [_examDetailTableView setTableHeaderView:[self createTableHeaderView]];
            [_examDetailTableView setTableFooterView:[self createTableFooterView]];
            [_examDetailTableView reloadData];
        }
    }
}

- (void)btnDownClickAction:(id)sender
{
    if (_dataDic != nil) {
        if (_cellIndexPathRow == _questionsArray.count-1) {
            [MBProgressHUD showMessage:@"已经是最后一题了" ToView:self.view RemainTime:1.0];
        }else{
            [_mutArrMyChoice removeAllObjects];
            _cellIndexPathRow += 1;
            _dataDic = [NSMutableDictionary dictionaryWithDictionary:_questionsArray[_cellIndexPathRow]];
            if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
                [_dataDic setObject:_judgeDataArray forKey:@"choiceList"];
            }
            NSArray *arr = [_dataDic valueForKey:@"choiceList"];
            NSString *myAns;
            if ([[_dataDic valueForKey:@"myAnswer"] count]>0) {
                myAns = [_dataDic valueForKey:@"myAnswer"][0];
            }
            if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
                if ([myAns isEqualToString:@"true"]) {
                    [_mutArrMyChoice addObject:@"1"];
                    [_mutArrMyChoice addObject:@"0"];
                }
                else if ([myAns isEqualToString:@"false"])
                {
                    [_mutArrMyChoice addObject:@"0"];
                    [_mutArrMyChoice addObject:@"1"];
                }
                else
                {
                    [_mutArrMyChoice addObject:@"0"];
                    [_mutArrMyChoice addObject:@"0"];
                }
            }
            else
            {
                for (int i=0; i<arr.count; i++)
                {
                    NSString *str = [NSString stringWithFormat:@"%c",(char)65+i];
                    if ([myAns rangeOfString:str].location != NSNotFound) {
                        [_mutArrMyChoice addObject:@"1"];
                    }else{
                        [_mutArrMyChoice addObject:@"0"];
                    }
                }
            }
            [self.examDetailTableView setContentOffset:CGPointMake(0,0) animated:NO];
            [_examDetailTableView setTableHeaderView:[self createTableHeaderView]];
            [_examDetailTableView setTableFooterView:[self createTableFooterView]];
            [_examDetailTableView reloadData];
        }
    }
}

- (void)swipeAction:(UISwipeGestureRecognizer *)gesture
{
    if (gesture.direction == UISwipeGestureRecognizerDirectionLeft)
    {
        if (_dataDic != nil)
        {
            if (_cellIndexPathRow == _questionsArray.count-1) {
                [MBProgressHUD showMessage:@"已经是最后一题了" ToView:self.view RemainTime:1.0];
            }else{
                [_mutArrMyChoice removeAllObjects];
                _cellIndexPathRow += 1;
                _dataDic = [NSMutableDictionary dictionaryWithDictionary:_questionsArray[_cellIndexPathRow]];
                if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
                    [_dataDic setObject:_judgeDataArray forKey:@"choiceList"];
                }
                NSArray *arr = [_dataDic valueForKey:@"choiceList"];
                NSString *myAns;
                if ([[_dataDic valueForKey:@"myAnswer"] count]>0) {
                    myAns =[_dataDic valueForKey:@"myAnswer"][0];
                }
                if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
                    if ([myAns isEqualToString:@"true"]) {
                        [_mutArrMyChoice addObject:@"1"];
                        [_mutArrMyChoice addObject:@"0"];
                    }
                    else if ([myAns isEqualToString:@"false"])
                    {
                        [_mutArrMyChoice addObject:@"0"];
                        [_mutArrMyChoice addObject:@"1"];
                    }
                    else
                    {
                        [_mutArrMyChoice addObject:@"0"];
                        [_mutArrMyChoice addObject:@"0"];
                    }
                }
                else
                {
                    for (int i=0; i<arr.count; i++)
                    {
                        NSString *str = [NSString stringWithFormat:@"%c",(char)65+i];
                        if ([myAns rangeOfString:str].location != NSNotFound) {
                            [_mutArrMyChoice addObject:@"1"];
                        }else{
                            [_mutArrMyChoice addObject:@"0"];
                        }
                    }
                }
                [self.examDetailTableView setContentOffset:CGPointMake(0,0) animated:NO];
                [_examDetailTableView setTableHeaderView:[self createTableHeaderView]];
                [_examDetailTableView setTableFooterView:[self createTableFooterView]];
                [_examDetailTableView reloadData];
            }
        }
    }
    else if (gesture.direction == UISwipeGestureRecognizerDirectionRight)
    {
        if (_dataDic != nil)
        {
            if (_cellIndexPathRow == 0) {
                [MBProgressHUD showMessage:@"已经是第一题了" ToView:self.view RemainTime:1.0];
            }else{
                [_mutArrMyChoice removeAllObjects];
                _cellIndexPathRow -= 1;
                _dataDic = [NSMutableDictionary dictionaryWithDictionary:_questionsArray[_cellIndexPathRow]];
                if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
                    [_dataDic setObject:_judgeDataArray forKey:@"choiceList"];
                }
                NSArray *arr = [_dataDic valueForKey:@"choiceList"];
                NSString *myAns;
                if ([[_dataDic valueForKey:@"myAnswer"] count]>0) {
                    myAns =[_dataDic valueForKey:@"myAnswer"][0];
                }
                if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
                    if ([myAns isEqualToString:@"true"]) {
                        [_mutArrMyChoice addObject:@"1"];
                        [_mutArrMyChoice addObject:@"0"];
                    }
                    else if ([myAns isEqualToString:@"false"])
                    {
                        [_mutArrMyChoice addObject:@"0"];
                        [_mutArrMyChoice addObject:@"1"];
                    }
                    else
                    {
                        [_mutArrMyChoice addObject:@"0"];
                        [_mutArrMyChoice addObject:@"0"];
                    }
                }
                else
                {
                    for (int i=0; i<arr.count; i++)
                    {
                        NSString *str = [NSString stringWithFormat:@"%c",(char)65+i];
                        if ([myAns rangeOfString:str].location != NSNotFound) {
                            [_mutArrMyChoice addObject:@"1"];
                        }else{
                            [_mutArrMyChoice addObject:@"0"];
                        }
                    }
                }
                [self.examDetailTableView setContentOffset:CGPointMake(0,0) animated:NO];
                [_examDetailTableView setTableHeaderView:[self createTableHeaderView]];
                [_examDetailTableView setTableFooterView:[self createTableFooterView]];
                [_examDetailTableView reloadData];
            }
        }
    }else{
        //不做处理
    }
}

- (void)btnCollectAction:(UIButton*)btn
{
    NSString *questionId = [_dataDic valueForKey:@"qid"];
    NSString *isCollect = [_dataDic valueForKey:@"isCollect"];
    
    NSDictionary *_dic = @{@"userId":_userId,
                           @"questionId":questionId,
                           @"isCollect":isCollect
                           };
    [[TKAFNetWorkingClient sharedClient] Post:DoCollect
                                   Parameters:_dic
                                      Success:^(id responseObject)
     {
         //请求成功：
         if ([[responseObject objectForKey:@"result"] integerValue] == 1)
         {
             [MBProgressHUD showMessage:[responseObject objectForKey:@"msg"] ToView:self.view RemainTime:1.0];
             [self requestExamDetailData];
         }
         else
         {
             [MBProgressHUD showAutoMessage:[responseObject objectForKey:@"msg"]];
         }
     } Failure:^(NSError *error) {
         //请求失败
         [MBProgressHUD showError:@"网络错误" ToView:self.view];
     }];
}

- (void)backBtnClickedAction:(id)sender
{
    if (_collectBackgroundView.hidden == NO) {
        _collectBackgroundView.hidden = YES;
        _examDetailTableView.hidden = NO;
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

-(void)btnListsTouch:(id)sender
{
    //    rightButton.selected =! rightButton.selected;
    
    //    if (rightButton.selected) {
    _collectBackgroundView.hidden = NO;
    _examDetailTableView.hidden = YES;
    
    //    }else
    //    {
    //        _collectBackgroundView.hidden = YES;
    //    }
}


#pragma mark collectionView
//返回分区个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

//#pragma mark collectionView

//返回每个分区的item个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return  _questionsMutArray.count;
}
//返回每个item
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewCell * cell  = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellid" forIndexPath:indexPath];
    UILabel *flagLabel = [[UILabel alloc] initWithFrame:CGRectMake(7, 7, SCREEN_WIDTH/6 -14 , SCREEN_WIDTH/6 -14)];
    
    flagLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row + 1];
    flagLabel.textAlignment = NSTextAlignmentCenter;
    flagLabel.textColor = [UIColor whiteColor];
    flagLabel.layer.cornerRadius = 5.0;
    flagLabel.layer.masksToBounds = YES;
    [cell addSubview:flagLabel];
    
    if ([[_questionsMutArray[indexPath.item] valueForKey:@"myAnswer"] count] > 0) {
        if ([[_questionsMutArray[indexPath.item] valueForKey:@"myAnswer"][0] isEqualToString:@"未作答"])
        {
            flagLabel.backgroundColor = [UIColor colorWithRed:0.91f green:0.91f blue:0.91f alpha:1.00f];
        }
        else
        {
            if ([[_questionsMutArray[indexPath.item] valueForKey:@"type"] isEqualToString:@"Essay"] ||
                [[_questionsMutArray[indexPath.item] valueForKey:@"type"] isEqualToString:@"Fill"]
                )
            {
                flagLabel.backgroundColor = [UIColor colorWithRed:0.33f green:0.65f blue:0.88f alpha:1.00f];
            }
            else
            {
                if ([[_questionsMutArray[indexPath.item] valueForKey:@"isRight"] integerValue] == 0)
                {
                    flagLabel.backgroundColor = [UIColor colorWithRed:0.96f green:0.27f blue:0.25f alpha:1.00f];
                }
                else
                {
                    flagLabel.backgroundColor = [UIColor colorWithRed:0.40f green:0.81f blue:0.00f alpha:1.00f];
                }
            }
        }
    }
    cell.backgroundColor = [UIColor whiteColor];
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    _cellIndexPathRow = [[_questionsMutArray[indexPath.item] valueForKey:@"location"] integerValue]-1;
    [_mutArrMyChoice removeAllObjects];
    _dataDic = [NSMutableDictionary dictionaryWithDictionary:_questionsArray[_cellIndexPathRow]];
    if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
        [_dataDic setObject:_judgeDataArray forKey:@"choiceList"];
    }
    NSArray *arr = [_dataDic valueForKey:@"choiceList"];
    NSString *myAns;
    if ([[_dataDic valueForKey:@"myAnswer"] count]>0) {
        myAns = [_dataDic valueForKey:@"myAnswer"][0];
    }
    if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Judge"]) {
        if ([myAns isEqualToString:@"true"]) {
            [_mutArrMyChoice addObject:@"1"];
            [_mutArrMyChoice addObject:@"0"];
        }
        else if ([myAns isEqualToString:@"false"])
        {
            [_mutArrMyChoice addObject:@"0"];
            [_mutArrMyChoice addObject:@"1"];
        }
        else
        {
            [_mutArrMyChoice addObject:@"0"];
            [_mutArrMyChoice addObject:@"0"];
        }
    }
    else
    {
        for (int i=0; i<arr.count; i++)
        {
            NSString *str = [NSString stringWithFormat:@"%c",(char)65+i];
            if ([myAns rangeOfString:str].location != NSNotFound) {
                [_mutArrMyChoice addObject:@"1"];
            }else{
                [_mutArrMyChoice addObject:@"0"];
            }
        }
    }
    _examDetailTableView.hidden = NO;
    self.collectBackgroundView.hidden = YES;
    [_examDetailTableView setTableHeaderView:[self createTableHeaderView]];
    [_examDetailTableView setTableFooterView:[self createTableFooterView]];
    [_examDetailTableView reloadData];
    if ([[_dataDic valueForKey:@"type"] isEqualToString:@"Group1"] || [[_dataDic valueForKey:@"type"] isEqualToString:@"Group2"]) {
        NSInteger scrollRow = indexPath.item+1-[[_dataDic valueForKey:@"questionNum"] integerValue];
        NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:scrollRow inSection:0];
        [_examDetailTableView scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }else{
        [_examDetailTableView setContentOffset:CGPointMake(0, 0) animated:NO];
    }
}

#pragma mark --UICollectionViewDelegateFlowLayout
//定义每个UICollectionView 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(SCREEN_WIDTH/6, SCREEN_WIDTH/6);
}

#pragma mark - 浏览大图点击事件
/** 点击普通题型header的图片*/
- (void)tapHeaderAction:(UITapGestureRecognizer *)tap{
    UIImageView *imageView = (UIImageView*)tap.view;
    NSMutableArray *mutArr = [[NSMutableArray alloc] init];
    if (imageView.tag < 15) {
        //group1
        NSString *name = [_dataDic valueForKey:@"name"];
        NSArray *nameArr = [name componentsSeparatedByString:@"##"];
        for (int i = 1; i<nameArr.count; i++)
        {
            NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
            [urlStr stringByReplacingOccurrencesOfString:@"_small" withString:@""];
            NSURL *url = [NSURL URLWithString:urlStr];
            [mutArr addObject:url];
        }
        TKScanPictureVCViewController *vc = [[TKScanPictureVCViewController alloc] init];
        vc.arrPicData = mutArr;
        vc.index = imageView.tag-10;
        [self.navigationController pushViewController:vc animated:NO];
    }else{
        //group2
        NSInteger index = (imageView.tag-20)/10;
        NSString *name = [_dataDic valueForKey:@"choiceList"][index];
        NSArray *nameArr = [name componentsSeparatedByString:@"##"];
        for (int i = 1; i<nameArr.count; i++)
        {
            NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
            [urlStr stringByReplacingOccurrencesOfString:@"_small" withString:@""];
            NSURL *url = [NSURL URLWithString:urlStr];
            [mutArr addObject:url];
        }
        TKScanPictureVCViewController *vc = [[TKScanPictureVCViewController alloc] init];
        vc.arrPicData = mutArr;
        vc.index = (imageView.tag-20)%10;
        [self.navigationController pushViewController:vc animated:NO];
    }
}

/** 点击普通题型footer的图片,和cell图片*/
- (void)tapFooterAction:(UITapGestureRecognizer *)tap{
    UIImageView *imageView = (UIImageView*)tap.view;
    NSMutableArray *mutArr = [[NSMutableArray alloc] init];
    if (imageView.tag < 15) {
        NSString *name = [_dataDic valueForKey:@"answerResolve"];
        NSArray *nameArr = [name componentsSeparatedByString:@"##"];
        for (int i = 1; i<nameArr.count; i++)
        {
            NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
            [urlStr stringByReplacingOccurrencesOfString:@"_small" withString:@""];
            NSURL *url = [NSURL URLWithString:urlStr];
            [mutArr addObject:url];
        }
        TKScanPictureVCViewController *vc = [[TKScanPictureVCViewController alloc] init];
        vc.arrPicData = mutArr;
        vc.index = imageView.tag-10;
        [self.navigationController pushViewController:vc animated:NO];
    }
    else
    {
        NSInteger index = imageView.tag/100;
        NSString *name = [_dataDic valueForKey:@"choiceList"][index];
        NSArray *nameArr = [name componentsSeparatedByString:@"##"];
        for (int i = 1; i<nameArr.count; i++)
        {
            NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
            [urlStr stringByReplacingOccurrencesOfString:@"_small" withString:@""];
            NSURL *url = [NSURL URLWithString:urlStr];
            [mutArr addObject:url];
        }
        TKScanPictureVCViewController *vc = [[TKScanPictureVCViewController alloc] init];
        vc.arrPicData = mutArr;
        vc.index = imageView.tag-100*index-20;
        [self.navigationController pushViewController:vc animated:NO];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
