//
//  TKGroup2TableViewCell.m
//  TikuApp
//
//  Created by huangkeyuan on 16/8/18.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKGroup2TableViewCell.h"
#import "XWScanImage.h"
#import "TKGroup2CollectionViewCell.h"


@implementation TKGroup2TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _iNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, SCREEN_WIDTH - 30, 100)];
        _iNameLabel.backgroundColor = [UIColor whiteColor];
        _iNameLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
        _iNameLabel.numberOfLines = 0;
        _iNameLabel.font = [UIFont systemFontOfSize:15.0];
        
#pragma mark 字符间距
        //设置文本格式
        NSMutableParagraphStyle *paraStyle = [[NSMutableParagraphStyle alloc] init];
        paraStyle.lineBreakMode = NSLineBreakByCharWrapping;
        paraStyle.alignment = NSTextAlignmentLeft;
        paraStyle.lineSpacing = 10; //设置行间距
        paraStyle.hyphenationFactor = 0.0;//连字属性 在iOS，唯一支持的值分别为0和1
        paraStyle.firstLineHeadIndent = 0.0;//首行缩进
        paraStyle.paragraphSpacingBefore = 0.0;//段首行空白空间
        paraStyle.headIndent = 0;//整体缩进(首行除外)
        paraStyle.tailIndent = 0;
        //可以增加设置字间距 NSKernAttributeName:@1.5f
        _paraStyleDic = @{NSFontAttributeName:[UIFont systemFontOfSize:15], NSParagraphStyleAttributeName:paraStyle
                          };
        
        _iNameLabel.text = @"22233334444";
        //        _iNameLabel.text = [NSString stringWithFormat:@"%d. %@",_nowNumber,[self.dataArray[0] valueForKey:@"title"]];
        
        //让内容置顶
        [_iNameLabel sizeToFit];
        [self addSubview:_iNameLabel];
        
//        _rowNUmberAnswer = @"请选择";
//        _qingxuanzeButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        _qingxuanzeButton.frame = CGRectMake(15, CGRectGetMaxY(_iNameLabel.frame)+5, SCREEN_WIDTH - 30, 30);
//        [_qingxuanzeButton setTitle:@"请选择" forState:UIControlStateNormal];
//        _qingxuanzeButton.titleLabel.textAlignment = NSTextAlignmentLeft;
//        _qingxuanzeButton.userInteractionEnabled = NO;
//        _qingxuanzeButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
//        _qingxuanzeButton.contentEdgeInsets = UIEdgeInsetsMake(0,10, 0, 0);
        
//        [_qingxuanzeButton setTitleColor:[UIColor colorWithRed:0.74 green:0.74 blue:0.74 alpha:1] forState:UIControlStateNormal];
//        _qingxuanzeButton.backgroundColor = [UIColor whiteColor];
//        
//        [_qingxuanzeButton.layer setBorderColor:[UIColor colorWithRed:0.96 green:0.95 blue:0.95 alpha:1].CGColor];
//        [_qingxuanzeButton.layer setBorderWidth:1];
//        [_qingxuanzeButton.layer setMasksToBounds:YES];
//        
//        [self addSubview:_qingxuanzeButton];
//        
//        
//        _downImageView = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 30 - 20, CGRectGetMaxY(_iNameLabel.frame)+10, 20, 20)];
//        _downImageView.image = [UIImage imageNamed:@"TKdetail_down"];
//        [self addSubview:_downImageView];
        
        UICollectionViewFlowLayout *flowLayou = [[UICollectionViewFlowLayout alloc] init];
        flowLayou.minimumInteritemSpacing = 0;
        flowLayou.minimumLineSpacing = 0;
        [flowLayou setScrollDirection:UICollectionViewScrollDirectionVertical];
        _selectCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(20, 64, SCREEN_WIDTH-40, 60)
                                                   collectionViewLayout:flowLayou];
        _selectCollectionView.delegate = self;
        _selectCollectionView.dataSource = self;
        _selectCollectionView.showsVerticalScrollIndicator = NO;
        _selectCollectionView.backgroundColor = [UIColor whiteColor];
        _selectCollectionView.tag = 432;
        [self addSubview:_selectCollectionView];
        
         [_selectCollectionView registerNib:[UINib nibWithNibName:@"TKGroup2CollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"TKGroup2CollectionViewCell"];
        _wordArray = [[NSArray alloc] init];
        _wordArray = [NSArray arrayWithObjects:@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K", nil];
        
    }
    return self;
    
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    
    
//    [_qingxuanzeButton setTitle:_rowNUmberAnswer forState:UIControlStateNormal];
    
    //    _iNameLabel.text = _iNameString;
    _iNameLabel.frame = CGRectMake(15, 5, SCREEN_WIDTH - 30, 100);
    
    
    //判断公用选项中是否含有图片
    NSArray *titleArray = [_iNameString componentsSeparatedByString:@"##"];
    
    NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:titleArray[0] attributes:_paraStyleDic];
    _iNameLabel.attributedText = rightStr;
    
//    _iNameLabel.backgroundColor = [UIColor whi];
    
    //    _iNameLabel.text = titleArray[0];
    [_iNameLabel sizeToFit];
    
    if (titleArray.count > 1) {
        for (int k = 0; k< titleArray.count-1; k++) {
            //创建屏幕大小的imageView
            UIImageView *kkkkView = [[UIImageView alloc] initWithFrame:CGRectMake(60+ k*90, CGRectGetMaxY(_iNameLabel.frame)+10, 80, 80)];
            //
            kkkkView.tag = 2000+k;
            
            //获取沙盒路径
            NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,titleArray[k+1]]];
            
            //打印沙盒路径
            //                NSLog(@"%@ %@", NSHomeDirectory(),titleArray[k+1]);
            
            //获取路径对应的图片文件
            UIImage *image = [UIImage imageWithContentsOfFile:path];
            
            //给imageView添加视图文件
            kkkkView.image = image;
            
            //将imageView添加到屏幕
            [self addSubview:kkkkView];
            
            kkkkView.userInteractionEnabled = YES;
            
            //为UIImageView1添加点击事件
            UITapGestureRecognizer *tapGestureRecognizer5 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scanBigImageClick1:)];
            [kkkkView addGestureRecognizer:tapGestureRecognizer5];
            
            
        }
        
//        _qingxuanzeButton.frame = CGRectMake(15, CGRectGetMaxY(_iNameLabel.frame)+10 + 110, SCREEN_WIDTH - 30, 30);
//        _downImageView.frame = CGRectMake(SCREEN_WIDTH - 30 - 15, CGRectGetMaxY(_iNameLabel.frame)+20 + 110, 20, 15);
        _selectCollectionView.frame = CGRectMake(10, CGRectGetMaxY(_iNameLabel.frame), SCREEN_WIDTH - 20, _tableNumber%2*40+40);
//        _selectCollectionView.backgroundColor = [UIColor redColor];
        
    }else
    {
//        _qingxuanzeButton.frame = CGRectMake(15, CGRectGetMaxY(_iNameLabel.frame)+10, SCREEN_WIDTH - 30, 30);
//        _downImageView.frame = CGRectMake(SCREEN_WIDTH - 30 - 15, CGRectGetMaxY(_iNameLabel.frame)+20, 20, 15);
        _selectCollectionView.frame = CGRectMake(10, CGRectGetMaxY(_iNameLabel.frame), SCREEN_WIDTH - 20, _tableNumber%2*40+40);
//        _selectCollectionView.backgroundColor = [UIColor redColor];
    }
    
    _selectCollectionView.scrollEnabled = NO;
    
    [_selectCollectionView reloadData];
}


#pragma mark tabelViewDelegate
//-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
//{
//    return _tableNumber;
//}

//-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    static NSString *iIdentifier = @"openTableView";
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:iIdentifier];
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:iIdentifier];
//    }
//    cell.textLabel.text = _wordArray[indexPath.row];
//    return cell;
//
//}

//-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return 30;
//}
//
//-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    int i = (int)indexPath.row + 65;
//
//    [_qingxuanzeButton setTitle:[NSString stringWithFormat:@"%c",i] forState:UIControlStateNormal];
//
//    _rowNUmberAnswer = [NSString stringWithFormat:@"%c",i];
//
//
//    if ([self.delegate respondsToSelector:@selector(getGroup2Answer:andchoice:andchildSubjectID:)]) {
//        [self.delegate getGroup2Answer:_nowCellRow andchoice:indexPath.row andchildSubjectID:_childSubjectID];
//    }
//}


#pragma mark -- uicollection datasource
//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _tableNumber;
}


//定义每个UICollectionView 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((SCREEN_WIDTH - 20)/4, 40);
}
//每个UICollectionView展示的内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = @"TKGroup2CollectionViewCell";
    TKGroup2CollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    cell.tSelectAnswer.text = _wordArray[indexPath.row];

    [cell.tSelectButton setBackgroundImage:[UIImage imageNamed:@"TKdetail_unselect"] forState:UIControlStateNormal];
    
    [cell.tSelectButton setBackgroundImage:[UIImage imageNamed:@"TKdetail_select"] forState:UIControlStateSelected ];
    
    cell.tSelectButton.tag = indexPath.row;
    
    [cell.tSelectButton addTarget:self action:@selector(touchSelectButton:) forControlEvents:UIControlEventTouchUpInside];
    
    if (indexPath.row != _rowNUmberAnswer) {
        cell.tSelectButton.selected = NO;
    }else
    {
        cell.tSelectButton.selected = YES;
    }
    
    return cell;
}


#pragma mark --UICollectionView Delegate
//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
//    int i = (int)indexPath.row + 65;
    
    _rowNUmberAnswer = indexPath.row;
    
    [_selectCollectionView reloadData];
    
//    [_qingxuanzeButton setTitle:[NSString stringWithFormat:@"%c",i] forState:UIControlStateNormal];
//    
//    _rowNUmberAnswer = [NSString stringWithFormat:@"%c",i];
    
    
    if ([self.delegate respondsToSelector:@selector(getGroup2Answer:andchoice:andchildSubjectID:)]) {
        [self.delegate getGroup2Answer:_nowCellRow andchoice:indexPath.row andchildSubjectID:_childSubjectID];
    }
}
//返回这个UICollectionView是否可以被选择
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}


#pragma mark 单选点击选项上的按钮
-(void)touchSelectButton:(UIButton *)button
{
    _rowNUmberAnswer = button.tag;
    
    [_selectCollectionView reloadData];
    
    if ([self.delegate respondsToSelector:@selector(getGroup2Answer:andchoice:andchildSubjectID:)]) {
        [self.delegate getGroup2Answer:_nowCellRow andchoice:button.tag andchildSubjectID:_childSubjectID];
    }
}

#pragma mark - 浏览大图点击事件
-(void)scanBigImageClick1:(UITapGestureRecognizer *)tap{
    NSLog(@"点击图片");
    UIImageView *clickedImageView = (UIImageView *)tap.view;
    [XWScanImage scanBigImageWithImageView:clickedImageView];
}




@end
