//
//  TKScanPictureVCViewController.h
//  TiKuAppSDK
//
//  Created by HuangChuanfeng on 16/10/9.
//  Copyright © 2016年 HuangChuanfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKScanPictureVCViewController : UIViewController<UIScrollViewDelegate>

@property (assign,nonatomic) NSInteger index;
@property (strong,nonatomic) NSArray   *arrPicData;

@end
