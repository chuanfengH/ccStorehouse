//
//  TKExamHadFinishedCell_Group1.h
//  TikuApp
//
//  Created by HuangChuanfeng on 16/9/29.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKExamHadFinishedCell_Group1 : UITableViewCell<UITableViewDelegate,UITableViewDataSource>


@property (strong,nonatomic) UITableView  *contentGroup1TableView;
@property (strong,nonatomic) NSDictionary *paraStyleDic;
@property (strong,nonatomic) NSDictionary *dataDic;
@property (copy,nonatomic)   NSString     *childName;

@property (nonatomic, copy) void (^requestDataAgain)(NSString *message);
@property (nonatomic,  copy) void (^openImageViewer)(NSArray *images,NSInteger index);

@end
