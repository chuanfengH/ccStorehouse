//
//  TKDetailPubilcViewController.m
//  TikuApp
//
//  Created by huangkeyuan on 16/7/20.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKDetailPubilcViewController.h"
#import "TKTableViewCell.h"

@interface TKDetailPubilcViewController ()

@end

@implementation TKDetailPubilcViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

-(void)createDeatilNavigationBarWithTitle:(NSString *)titleName andRightButtonImageName:(NSString *)rightBtnImageName
{
    UIView *navigationView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 64)];
    navigationView.backgroundColor = [UIColor colorWithRed:0.24 green:0.62 blue:0.89 alpha:1];
    [self.view addSubview:navigationView];
    
    UILabel *iTitleName = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH/2 - 100, 20, 200, 44)];
    iTitleName.text = titleName;
    iTitleName.font = [UIFont systemFontOfSize:19];
    iTitleName.textAlignment = NSTextAlignmentCenter;
    iTitleName.textColor = [UIColor whiteColor];
    [navigationView addSubview:iTitleName];
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame = CGRectMake(15, 30, 30, 30);
    [leftButton setBackgroundImage:[UIImage imageNamed:@"TKbackButton"] forState:UIControlStateNormal];
    [leftButton addTarget:self action:@selector(backToLastButton:) forControlEvents:UIControlEventTouchUpInside];
    [navigationView addSubview:leftButton];
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame = CGRectMake(SCREEN_WIDTH - 10 - 25, 30, 30, 30);
    rightButton.titleLabel.textColor = [UIColor whiteColor];
    [rightButton setBackgroundImage:[UIImage imageNamed:rightBtnImageName] forState:UIControlStateNormal];
    [rightButton addTarget:self action:@selector(touchRightButton:) forControlEvents:UIControlEventTouchUpInside];
    [navigationView addSubview:rightButton];
    [rightButton setSelected:NO];
    
    
#pragma mark 导航下面视图
    UIView *detailTopView = [[UIView alloc] initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, 44)];
    detailTopView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:detailTopView];
    
    UIView *bottomFenge = [[UIView alloc] initWithFrame:CGRectMake(5, 107, SCREEN_WIDTH - 10, 0.5)];
    bottomFenge.backgroundColor = [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1];
    [self.view addSubview:bottomFenge];
    _detailType = [[UILabel alloc] initWithFrame:CGRectMake(5, 10, 100, 30)];
    _detailType.font = [UIFont systemFontOfSize:16];
    _detailType.text = @"病例分析图";
    _detailType.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
    [detailTopView addSubview:_detailType];
    
//    _detailTimeImageview = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH/2 - 50, 10, 25, 25)];
//    _detailTimeImageview.image = [UIImage imageNamed:@"TKdetail_time"];
////    [detailTopView addSubview:_detailTimeImageview];
//    
//    _detailTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_detailTimeImageview.frame), 10, 30, 30)];
//    _detailTimeLabel.font = [UIFont systemFontOfSize:17];
//    _detailTimeLabel.text = @"00:";
//    _detailTimeLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
//    _detailTimeLabel.textAlignment = NSTextAlignmentCenter;
////    [detailTopView addSubview:_detailTimeLabel];
//    
//    _detailMinuteLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_detailTimeLabel.frame), 10, 30, 30)];
//    _detailMinuteLabel.font = [UIFont systemFontOfSize:17];
//    _detailMinuteLabel.text = @"01:";
//    _detailMinuteLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
//    _detailMinuteLabel.textAlignment = NSTextAlignmentCenter;
//    
////    [detailTopView addSubview:_detailMinuteLabel];
//    
//    _detailSecondLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_detailMinuteLabel.frame), 10, 30, 30)];
//    _detailSecondLabel.font = [UIFont systemFontOfSize:17];
//    _detailSecondLabel.text = @"02:";
//    _detailSecondLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
//    _detailSecondLabel.textAlignment = NSTextAlignmentCenter;
//    
////    [detailTopView addSubview:_detailSecondLabel];
    
    _detailNumberLabel = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 5 - 50, 10, 50, 30)];
    _detailNumberLabel.textAlignment = NSTextAlignmentCenter;
//    _detailNumberLabel.text = @"6/34";
    _detailNumberLabel.font = [UIFont systemFontOfSize:16];
    _detailNumberLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
    
    [detailTopView addSubview:_detailNumberLabel];
    
    
    
    UIView *bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 50, SCREEN_WIDTH, 50)];
    [self.view addSubview:bottomView];
    
    UIView *fengexianView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 0.5)];
    fengexianView.backgroundColor = [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1];
    [bottomView addSubview:fengexianView];
    
    UIButton *bottomBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    bottomBtn.frame = CGRectMake(0, 0, SCREEN_WIDTH/5, 50);
    [bottomBtn setImage:[UIImage imageNamed:@"TKdetail_1"] forState:UIControlStateNormal];
    [bottomBtn setTitle:@"上一题" forState:UIControlStateNormal];
    bottomBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [bottomBtn setTitleColor:[UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1] forState:UIControlStateNormal];
    bottomBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    // 设置按钮图片偏移
    if (ISIPAD)
    {
        [bottomBtn setImageEdgeInsets:UIEdgeInsetsMake(5, 47, 20, 20)];
        [bottomBtn setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn.imageView.frame.size.height+15,-20, 5,5)];
    }else
    {
        if (SCREEN_WIDTH == 320) {
            [bottomBtn setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 20, 20)];
            [bottomBtn setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn.imageView.frame.size.height+15,-20, 5,5)];
        }else
        {
            [bottomBtn setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 20, 25)];
            [bottomBtn setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn.imageView.frame.size.height+15,-20, 5,5)];
        }
    }
    // 设置按钮标题偏移
    
    [bottomView addSubview:bottomBtn];
    [bottomBtn addTarget:self action:@selector(touchShangyiti:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    UIButton *bottomBtn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    bottomBtn1.frame = CGRectMake(CGRectGetMaxX(bottomBtn.frame), 0, SCREEN_WIDTH/5, 50);
    [bottomBtn1 setTitle:@"保存" forState:UIControlStateNormal];
    [bottomBtn1 setImage:[UIImage imageNamed:@"TKdetail_2"] forState:UIControlStateNormal];
    bottomBtn1.titleLabel.font = [UIFont systemFontOfSize:14];
    [bottomBtn1 setTitleColor:[UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1] forState:UIControlStateNormal];
    bottomBtn1.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    // 设置按钮图片偏移
    if (ISIPAD)
    {
        [bottomBtn1 setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 20, 20)];
        [bottomBtn1 setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn1.imageView.frame.size.height+15,-40, 5,5)];
    }else
    {
        if (SCREEN_WIDTH == 320) {
            [bottomBtn1 setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 20, 20)];
            [bottomBtn1 setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn1.imageView.frame.size.height+15,-20, 5,5)];

        }else
        {
            [bottomBtn1 setImageEdgeInsets:UIEdgeInsetsMake(5, 25, 20, 25)];
            [bottomBtn1 setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn1.imageView.frame.size.height+15,-20, 5,5)];

        }
    }
    // 设置按钮标题偏移
    [bottomView addSubview:bottomBtn1];
    [bottomBtn1 addTarget:self action:@selector(touchBaocun:) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *bottomBtn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    bottomBtn2.frame = CGRectMake(CGRectGetMaxX(bottomBtn1.frame), 0, SCREEN_WIDTH/5, 50);
    [bottomBtn2 setTitle:@"未答题" forState:UIControlStateNormal];
    [bottomBtn2 setImage:[UIImage imageNamed:@"TKdetail_3"] forState:UIControlStateNormal];
    bottomBtn2.titleLabel.font = [UIFont systemFontOfSize:14];
    [bottomBtn2 setTitleColor:[UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1] forState:UIControlStateNormal];
    bottomBtn2.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    // 设置按钮图片偏移
    if (ISIPAD)
    {
        [bottomBtn2 setImageEdgeInsets:UIEdgeInsetsMake(5, 46, 20, 20)];
        [bottomBtn2 setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn2.imageView.frame.size.height+15,-40, 5,5)];
    }else
    {
        if (SCREEN_WIDTH == 320) {
            [bottomBtn2 setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 20, 20)];
            [bottomBtn2 setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn2.imageView.frame.size.height+15,-20, 5,5)];
        }else
        {
            [bottomBtn2 setImageEdgeInsets:UIEdgeInsetsMake(5, 25, 20, 25)];
            [bottomBtn2 setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn2.imageView.frame.size.height+15,-20, 5,5)];
        }
    }
    // 设置按钮标题偏移
    
    [bottomView addSubview:bottomBtn2];
    [bottomBtn2 addTarget:self action:@selector(touchWeidati:) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *bottomBtn3 = [UIButton buttonWithType:UIButtonTypeCustom];
    bottomBtn3.frame = CGRectMake(CGRectGetMaxX(bottomBtn2.frame), 0, SCREEN_WIDTH/5, 50);
    [bottomBtn3 setTitle:@"交卷" forState:UIControlStateNormal];
    [bottomBtn3 setImage:[UIImage imageNamed:@"TKdetail_4"] forState:UIControlStateNormal];
    bottomBtn3.titleLabel.font = [UIFont systemFontOfSize:14];
    [bottomBtn3 setTitleColor:[UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1] forState:UIControlStateNormal];
    bottomBtn3.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    // 设置按钮图片偏移
    if (ISIPAD)
    {
        [bottomBtn3 setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 20, 20)];
        [bottomBtn3 setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn3.imageView.frame.size.height+15,-40, 5,5)];

    }else
    {
        if (SCREEN_WIDTH == 320) {
            [bottomBtn3 setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 20, 20)];
            [bottomBtn3 setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn3.imageView.frame.size.height+15,-20, 5,5)];

        }else
        {
            [bottomBtn3 setImageEdgeInsets:UIEdgeInsetsMake(5, 25, 20, 25)];
            [bottomBtn3 setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn3.imageView.frame.size.height+15,-20, 5,5)];

        }
    }
    // 设置按钮标题偏移
    [bottomView addSubview:bottomBtn3];
    [bottomBtn3 addTarget:self action:@selector(touchTijiao:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *bottomBtn4 = [UIButton buttonWithType:UIButtonTypeCustom];
    bottomBtn4.frame = CGRectMake(CGRectGetMaxX(bottomBtn3.frame), 0, SCREEN_WIDTH/5, 50);
    [bottomBtn4 setTitle:@"下一题" forState:UIControlStateNormal];
    [bottomBtn4 setImage:[UIImage imageNamed:@"TKdetail_5"] forState:UIControlStateNormal];
    bottomBtn4.titleLabel.font = [UIFont systemFontOfSize:14];
    [bottomBtn4 setTitleColor:[UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1] forState:UIControlStateNormal];
    bottomBtn4.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    // 设置按钮图片偏移
    if (ISIPAD)
    {
        [bottomBtn4 setImageEdgeInsets:UIEdgeInsetsMake(5, 47, 20, 20)];
    }else
    {
        if (SCREEN_WIDTH == 320) {
            [bottomBtn4 setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 20, 20)];
        }else
        {
            [bottomBtn4 setImageEdgeInsets:UIEdgeInsetsMake(5, 20, 20, 25)];
        }
    }
    // 设置按钮标题偏移
    [bottomBtn4 setTitleEdgeInsets:UIEdgeInsetsMake(bottomBtn4.imageView.frame.size.height+15,-40, 5,5)];
    [bottomView addSubview:bottomBtn4];
    [bottomBtn4 addTarget:self action:@selector(touchXiayiti) forControlEvents:UIControlEventTouchUpInside];
    
#pragma mark collectView
    
    _collectBackgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_HEIGHT - 64)];
    _collectBackgroundView.backgroundColor = [UIColor whiteColor];
    [self.view  addSubview:_collectBackgroundView];
    _collectBackgroundView.hidden = YES;
    UILabel *timuliebiao = [[UILabel alloc] initWithFrame:CGRectMake(15, 20, 80, 30)];
    timuliebiao.text = @"题目列表";
    [_collectBackgroundView addSubview:timuliebiao];
    
    UILabel *weizuo = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 15 - 40, 20, 40, 30)];
    weizuo.text = @"未做";
    [_collectBackgroundView addSubview:weizuo];
    
    UILabel *weizuoLabel = [[UILabel alloc] initWithFrame:CGRectMake(weizuo.frame.origin.x - 10 - 25, 25, 20, 20)];
    weizuoLabel.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
    weizuoLabel.layer.cornerRadius = 3.0;
    weizuoLabel.layer.masksToBounds = YES;
    [_collectBackgroundView addSubview:weizuoLabel];
    
    UILabel *yizuo = [[UILabel alloc] initWithFrame:CGRectMake(weizuoLabel.frame.origin.x - 40 - 25, 20, 40, 30)];
    yizuo.text = @"已做";
    [_collectBackgroundView addSubview:yizuo];
    
    UILabel *yizuoLabel = [[UILabel alloc] initWithFrame:CGRectMake(yizuo.frame.origin.x - 10 - 25, 25, 20, 20)];
    yizuoLabel.backgroundColor = [UIColor colorWithRed:0.34 green:0.65 blue:0.87 alpha:1];
    yizuoLabel.layer.cornerRadius = 3.0;
    yizuoLabel.layer.masksToBounds = YES;
    [_collectBackgroundView addSubview:yizuoLabel];
    
#pragma mark 答题列表
    //创建一个layout布局类
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc]init];
    //设置布局方向为垂直流布局
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    //设置每个item的大小为100*100
    layout.minimumLineSpacing = 0;         //上下cell间距
    layout.minimumInteritemSpacing = 0;    //左右cell间距
    //创建collectionView 通过一个布局策略layout来创建
    _subjectLists = [[UICollectionView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(timuliebiao.frame) + 20, SCREEN_WIDTH, SCREEN_HEIGHT - 70 - 64) collectionViewLayout:layout];
    //代理设置
    _subjectLists.backgroundColor = [UIColor whiteColor];
    _subjectLists.delegate=self;
    _subjectLists.dataSource=self;
    //注册item类型 这里使用系统的类型
    [_subjectLists registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellid"];
    
    [_collectBackgroundView addSubview:_subjectLists];
    
#pragma mark 未答题页面布局
    _weidatiView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    _weidatiView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    [self.view addSubview:_weidatiView];
    
    
    UIView *BezierView = [[UIView alloc] initWithFrame:CGRectMake(10, SCREEN_HEIGHT/2 - 150, SCREEN_WIDTH - 20, 300)];
    [_weidatiView addSubview:BezierView];
    BezierView.layer.cornerRadius = 10.0;
    BezierView.layer.masksToBounds = YES;
    
    UICollectionViewFlowLayout *weidatilayout = [[UICollectionViewFlowLayout alloc]init];
    weidatilayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    weidatilayout.minimumLineSpacing = 0;         //上下cell间距
    weidatilayout.minimumInteritemSpacing = 0;    //左右cell间距
    _weidatiCollection = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - 20, 300 - 50) collectionViewLayout:weidatilayout];
    //代理设置
    _weidatiCollection.backgroundColor = [UIColor whiteColor];
    _weidatiCollection.delegate=self;
    _weidatiCollection.dataSource=self;
    //注册item类型 这里使用系统的类型
    [_weidatiCollection registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"weidaticellid"];
    [BezierView addSubview:_weidatiCollection];
    _weidatiView.hidden = YES;
    
    UIButton *saveButton = [UIButton buttonWithType:UIButtonTypeCustom];
    saveButton.frame = CGRectMake(0,BezierView.frame.size.height - 50 , BezierView.frame.size.width/2, 50);
    [saveButton setTitle:@"保存" forState:UIControlStateNormal];
    [saveButton setTitleColor:[UIColor colorWithRed:0.22 green:0.49 blue:0.71 alpha:1] forState:UIControlStateNormal];
    saveButton.backgroundColor = [UIColor whiteColor];
    [BezierView addSubview:saveButton];
    [saveButton.layer setBorderColor:[UIColor colorWithRed:0.96 green:0.95 blue:0.95 alpha:1].CGColor];
    [saveButton.layer setBorderWidth:1];
    [saveButton.layer setMasksToBounds:YES];
    [saveButton addTarget:self action:@selector(touchSaveButton) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    _submitSubject = [UIButton buttonWithType:UIButtonTypeCustom];
    _submitSubject.frame = CGRectMake(BezierView.frame.size.width/2,BezierView.frame.size.height - 50 , BezierView.frame.size.width/2, 50);
    [_submitSubject setTitle:@"提交作业" forState:UIControlStateNormal];
    [_submitSubject setTitleColor:[UIColor colorWithRed:0.22 green:0.49 blue:0.71 alpha:1] forState:UIControlStateNormal];
    _submitSubject.backgroundColor = [UIColor whiteColor];
    [BezierView addSubview:_submitSubject];
    
    [_submitSubject.layer setBorderColor:[UIColor colorWithRed:0.96 green:0.95 blue:0.95 alpha:1].CGColor];
    [_submitSubject.layer setBorderWidth:1];
    [_submitSubject.layer setMasksToBounds:YES];
    [_submitSubject addTarget:self action:@selector(touchSubmitSubjectButton) forControlEvents:UIControlEventTouchUpInside];
    
#pragma mark 滑动手势
    UISwipeGestureRecognizer *rightSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(rightSwipe:)];
    rightSwipe.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:rightSwipe];
    
    UISwipeGestureRecognizer *leftSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(leftSwipe:)];
    leftSwipe.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:leftSwipe];
    
}


-(void)createDetailUI
{
    
    
    
    
    
    
    
    
    
    
    
    
}



#pragma mark 点击返回上一题
-(void)backToLastButton:(UIButton *)leftBackButton
{
    
}

#pragma mark 点击右边导航按钮
-(void)touchRightButton:(UIButton *)rightButton
{
    rightButton.selected =! rightButton.selected;
    
    if (rightButton.selected) {
        _collectBackgroundView.hidden = NO;
    }else
    {
        _collectBackgroundView.hidden = YES;
    }
}

#pragma mark 点击上一题
-(void)touchShangyiti:(UIButton *)button
{
    
}

#pragma mark 点击保存
-(void)touchBaocun:(UIButton *)button
{
    
}

#pragma mark 点击未答题
-(void)touchWeidati:(UIButton *)button
{
    _weidatiView.hidden = NO;
}

#pragma mark 点击提交
-(void)touchTijiao:(UIButton *)button
{
    
}

#pragma mark 点击下一题
-(void)touchXiayiti
{
    
}


#pragma mark 点击未答题页面上的保存按钮
-(void)touchSaveButton
{
    _weidatiView.hidden = YES;
    
}

#pragma mark 点击未答题页面上的提交作业按钮
-(void)touchSubmitSubjectButton
{
    _weidatiView.hidden = YES;
    
}


#pragma mark 右滑手势触发事件
-(void)rightSwipe:(UISwipeGestureRecognizer *)sender
{
    
}

#pragma mark 左滑手势触发事件
-(void)leftSwipe:(UISwipeGestureRecognizer *)sender
{
    
}



#pragma mark collectionView
//返回分区个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
//返回每个分区的item个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return  100;
}
//返回每个item
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if (collectionView == _subjectLists) {
        UICollectionViewCell * cell  = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellid" forIndexPath:indexPath];
        UILabel *flagLabel = [[UILabel alloc] initWithFrame:CGRectMake(7, 7, SCREEN_WIDTH/6 -14 , SCREEN_WIDTH/6 -14)];
        flagLabel.backgroundColor = [UIColor colorWithRed:0.34 green:0.65 blue:0.87 alpha:1];
        flagLabel.text = @"23";
        flagLabel.textAlignment = NSTextAlignmentCenter;
        flagLabel.textColor = [UIColor whiteColor];
        flagLabel.layer.cornerRadius = 5.0;
        flagLabel.layer.masksToBounds = YES;
        [cell addSubview:flagLabel];
        cell.backgroundColor = [UIColor whiteColor];
        return cell;
        
    }else if (collectionView == _weidatiCollection){
        UICollectionViewCell * cell  = [collectionView dequeueReusableCellWithReuseIdentifier:@"weidaticellid" forIndexPath:indexPath];
        cell.backgroundColor = [UIColor whiteColor];
        UILabel *flagLabel = [[UILabel alloc] initWithFrame:CGRectMake(7, 7, SCREEN_WIDTH/6 -14 , SCREEN_WIDTH/6 -14)];
        flagLabel.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
        flagLabel.text = @"23";
        flagLabel.textAlignment = NSTextAlignmentCenter;
        flagLabel.textColor = [UIColor whiteColor];
        flagLabel.layer.cornerRadius = 5.0;
        flagLabel.layer.masksToBounds = YES;
        [cell addSubview:flagLabel];
        return cell;
    }else
    {
        return nil;
    }
}

#pragma mark --UICollectionViewDelegateFlowLayout
//定义每个UICollectionView 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView == _subjectLists) {
        return CGSizeMake(SCREEN_WIDTH/6, SCREEN_WIDTH/6);
    }else
    {
        return CGSizeMake((SCREEN_WIDTH-20)/6, (SCREEN_WIDTH-20)/6);
    }
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
