//
//  TestMain+CoreDataProperties.m
//  TikuApp
//
//  Created by HuangChuanfeng on 16/9/19.
//  Copyright © 2016年 leimingtech. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "TestMain+CoreDataProperties.h"

@implementation TestMain (CoreDataProperties)

@dynamic answer;
@dynamic child_options;
@dynamic choiceOrder;
@dynamic fileName;
@dynamic options;
@dynamic order;
@dynamic questionListOrder;
@dynamic questionModelName;
@dynamic test_id;
@dynamic test_name;
@dynamic title;
@dynamic title_id;
@dynamic type;
@dynamic userid;
@dynamic iscompleted;
@dynamic questionNum;
@dynamic location;
@end
