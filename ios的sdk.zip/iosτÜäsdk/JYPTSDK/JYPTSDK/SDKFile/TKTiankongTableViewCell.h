//
//  TKTiankongTableViewCell.h
//  TikuApp
//
//  Created by huangkeyuan on 16/8/16.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKTiankongTableViewCell : UITableViewCell<UITextFieldDelegate>
@property (nonatomic,strong)UILabel *numberLabel;
@property (nonatomic,strong)UITextField *tiankongTF;
@end
