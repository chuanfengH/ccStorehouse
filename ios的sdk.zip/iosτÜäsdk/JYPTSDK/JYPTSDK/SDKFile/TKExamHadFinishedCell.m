//
//  TKExamHadFinishedCell.m
//  TikuApp
//
//  Created by HuangChuanfeng on 16/9/23.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKExamHadFinishedCell.h"

@implementation TKExamHadFinishedCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        _btnChoice = [UIButton buttonWithType:UIButtonTypeCustom];
        _btnChoice.frame = CGRectMake(15, (self.contentView.frame.size.height-15)/2, 15, 15);
        _btnChoice.enabled = NO;
        [self.contentView addSubview:_btnChoice];
        
        _labelChoice = [[UILabel alloc] init];
        _labelChoice.frame = CGRectMake(CGRectGetMaxX(_btnChoice.frame)+10, 0, SCREEN_WIDTH-(CGRectGetMaxX(_btnChoice.frame)+10+15+10+10), self.contentView.frame.size.height);
        _labelChoice.numberOfLines = 0;
        _labelChoice.font = [UIFont systemFontOfSize:15.0];
        [self.contentView addSubview:_labelChoice];
        
        _imgViewRight = [[UIImageView alloc] init];
        _imgViewRight.frame = CGRectMake(CGRectGetMaxX(_labelChoice.frame)+10, (self.contentView.frame.size.height-15)/2, 15, 15);
        [self.contentView addSubview:_imgViewRight];
        
        for (int i = 1; i<4; i++) {
            UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(30+100*(i-1), CGRectGetMaxY(_labelChoice.frame), 80, 80)];
            imgView.tag = 300+i;
            [self.contentView addSubview:imgView];
        }
    }
    return self;
}
@end
