//
//  TKExamHadFinishedCell.h
//  TikuApp
//
//  Created by HuangChuanfeng on 16/9/23.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKExamHadFinishedCell : UITableViewCell

@property (strong,nonatomic) UIButton    *btnChoice;
@property (strong,nonatomic) UILabel     *labelChoice;
@property (strong,nonatomic) UIImageView *imgViewRight;


@end
