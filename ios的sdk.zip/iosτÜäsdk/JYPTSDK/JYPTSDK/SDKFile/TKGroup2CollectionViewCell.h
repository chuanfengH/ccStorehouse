//
//  TKGroup2CollectionViewCell.h
//  TiKuAppSDK
//
//  Created by huangkeyuan on 2016/11/29.
//  Copyright © 2016年 HuangChuanfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKGroup2CollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIButton *tSelectButton;
@property (weak, nonatomic) IBOutlet UILabel *tSelectAnswer;

@end
