//
//  TKScanPictureVCViewController.m
//  TiKuAppSDK
//
//  Created by HuangChuanfeng on 16/10/9.
//  Copyright © 2016年 HuangChuanfeng. All rights reserved.
//

#import "TKScanPictureVCViewController.h"

@interface TKScanPictureVCViewController ()

@property (strong,nonatomic) UILabel *label;

@end

@implementation TKScanPictureVCViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor blackColor];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    scrollView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    scrollView.contentSize = CGSizeMake(SCREEN_WIDTH*_arrPicData.count, 0);
    
    // 一页的大小应该是frame的大小
    scrollView.pagingEnabled = YES;
    scrollView.delegate = self;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    [scrollView setContentOffset:CGPointMake(SCREEN_WIDTH*(_index-1), 0)];
    [self.view addSubview:scrollView];
    
    scrollView.tag = 1001;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    [self.view addGestureRecognizer:tap];
    
    [self loadPage];
    
    _label = [[UILabel alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-50, SCREEN_WIDTH, 20)];
    _label.textColor = [UIColor whiteColor];
    _label.textAlignment = NSTextAlignmentCenter;
    _label.text = [NSString stringWithFormat:@"%ld/%ld",_index,_arrPicData.count];
    [self.view addSubview:_label];
}

- (void)loadPage
{
    for (int i = 0; i<_arrPicData.count; i++)
    {
        UIImageView *currentImageView = [[UIImageView alloc] init];
        [currentImageView sd_setImageWithURL:_arrPicData[i] placeholderImage:nil];
        if (currentImageView.image.size.width < SCREEN_WIDTH) {
            currentImageView.frame = CGRectMake(SCREEN_WIDTH*i, 0, currentImageView.image.size.width, currentImageView.image.size.height);
        }else{
            currentImageView.frame = CGRectMake(SCREEN_WIDTH*i, 0, SCREEN_WIDTH, SCREEN_HEIGHT/(currentImageView.image.size.width/SCREEN_WIDTH));
        }
        currentImageView.center = CGPointMake(SCREEN_WIDTH*i+SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
        [[self.view viewWithTag:1001] addSubview:currentImageView];
    }
}

// 当减速结束时调用
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    int index = scrollView.contentOffset.x/SCREEN_WIDTH;
    _label.text = [NSString stringWithFormat:@"%d/%ld",index+1,_arrPicData.count];
}

- (void)tapAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:NO];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
