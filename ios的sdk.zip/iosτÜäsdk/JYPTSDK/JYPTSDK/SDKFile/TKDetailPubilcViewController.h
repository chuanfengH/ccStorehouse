//
//  TKDetailPubilcViewController.h
//  TikuApp
//
//  Created by huangkeyuan on 16/7/20.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKDetailPubilcViewController : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong)UILabel *detailType;
@property (nonatomic,strong)UIImageView *detailTimeImageview;
@property (nonatomic,strong)UILabel *detailTimeLabel;
@property (nonatomic,strong)UILabel *detailMinuteLabel;
@property (nonatomic,strong)UILabel *detailSecondLabel;
@property (nonatomic,strong)UILabel *detailNumberLabel;
@property (nonatomic,strong)UIView *collectBackgroundView;
@property (nonatomic,strong)UICollectionView *subjectLists;
@property (nonatomic,strong)UIView *weidatiView;
@property (nonatomic,strong)UICollectionView *weidatiCollection;
@property (nonatomic,strong)UIButton *submitSubject;
- (void)createDeatilNavigationBarWithTitle:(NSString *)titleName andRightButtonImageName:(NSString *)rightBtnImageName;
@end
