//
//  TKExamHadFinishedVC.h
//  TikuApp
//
//  Created by HuangChuanfeng on 16/9/23.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKExamHadFinishedVC : UIViewController

@property (copy,nonatomic) NSString *examId;
@property (copy,nonatomic) NSString *userId;
@property (copy,nonatomic) NSString *fromWho;

@property (nonatomic,  copy) void (^openImageViewer)(NSArray *images,NSInteger index);

@end
