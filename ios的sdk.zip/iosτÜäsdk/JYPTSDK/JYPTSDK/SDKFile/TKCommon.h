//
//  Common.h
//  TikuApp
//
//  Created by huangkeyuan on 16/7/12.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#ifndef Common_h
#define Common_h

#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)
#define SCREEN_SCALE ([UIScreen mainScreen].bounds.size.width/320)
#define BOUNDS   [[UIScreen mainScreen] bounds]
#define ShowAllCellNOTIFICATION @"ShowAllCellNOTIFICATION"
#define MAXNUMBER 0
#define CLColor(r,g,b) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1.0f]
#define ISIPAD ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

#define TKUSERID [[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"TKUSERID"]] isEqualToString:@"(null)"] ? [NSString stringWithFormat:@"%@",@""] : [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"TKUSERID"]]

#define PrivateKeyO2O  @"MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBALp+nkNsb0dfqNq3TxQe53JNd/C3rRdoMG3l+n7CjTGA60y6O+ssZ/j5kzwFrVBaSwIkpBIX1j/NhOTf2s+ItwjU1dliKKD6Da4kBABaGJPwDSYZVo05PmaywRb11knijgXdIq4c/Yn4tIbagoE4pEkBWeKRe+EpUedsrn1mVh/lAgMBAAECgYB8zF58IAQXbxw/wItam5OmGdE5dLCQCVjfMhb+3JI/nlXXcojGR2EMa3bro6DnNIUdWgexU+I7r/xObL6wQny4d8UJNN6SWbLIxkb2YjoUk5SaBO7bqFlEiyWJN0cp21h9KQIwAlbHeGIpll5SIR5uMqx4gTXcIzOqtyz/xtSyAQJBANqHPN7R3Oe8ALmMBwIh7YmA9sL3osSu6zer6Wa0qBlntyuv+6eB1VvON8JlZOCFA3mJoRHvmKeq1JCiMEzhUjkCQQDaeTHL3NdbO1dYQgKhLwWV2JjpyskSF3xjlNNbS0e8nu0Vwn+f8GTba0tO/BeVkuaKLfX0NbhXt/2YYkdhQIsNAkBwdqkdA2Rs3pSA6U+yCUP2QCi+rjNWha8IN7Em6lKYwIfENA2PZ4ImfTq1EPmZktr28Z2zXVty7rf2t4GkD1IBAkB2P8LEJPQrXSMZkiD6PQk44dNiN3A9apjZDWSYtVZOsXaBoJSTbPoqCRjp12isfKZrhBTr6Wetktif8hHQga7BAkEAmhOwXzYFD1jqd+cvgh0ImdWBDfq2qrfqYFhne+o0iEzHxukOty+GLm/mmaAkb/VvLX75qf/zNMNrTk5ZwXgtBA=="


#define RequestInstance [TKAFNetWorkingClient sharedClient]

//#define RequestPictureUrl @"http://119.254.225.102/exam/upload/img/" //图片下载地址
#define RequestPictureUrl @"http://jytk.ipmph.com/exam/upload/img/" //图片下载地址


//#define HOSTURL @"http://119.254.225.102/exam"
#define HOSTURL  @"http://jytk.ipmph.com/exam/"

/* 登录接口 */
#define USERLOGIN @"a/api/appLogin"
#define FORGERPASSWORD @"a/api/appRepassword"
#define HomePageApi @"a/api/question/homePageData"
#define CANCELRequip @"a/api/cancelRequipment"

/* 作业模块接口 */
#define HomeworkListApi     @"a/api/examTask/list"     //作业列表
#define HomeworkDetailApi   @"a/api/examTask/detail"   //作业详情
#define HOMEWORKANALYSISAPI @"a/api/examTask/analysis" //作业分析
#define ZONGTIFENXI @"a/api/exam/totalityAnalysis"     //总体分析
#define HomeWorkDownload @"downloadPaper"        //作业下载


/* 试卷模块接口*/
#define ExaminationListApi      @"a/api/exam/list"       //在线考试列表
#define ExaminationAnalysisApi  @"a/api/exam/analysis"   //考试分析接口
#define ExaminationDetailedApi  @"a/api/exam/detail"     //考试详情接口
#define ExaminationSaveAllAnswre @"a/api/exam/saveAnswerAll" //全卷提交保存答题
#define ExaminationSaveSomeAnser @"a/api/exam/saveAnswerByNum"//提交部分答案
#define BeforeExamination @"a/api/exam/examInfo"             //开始考试之前获取考试须知
#define StartExamination @"a/api/question/examStart"         //点击开始考试获取时间和提交答题数

/* 统计模块接口*/
#define CountListsApi @"a/api/exam/typeAnalysisList"   //知识点列表
#define ZHISHIDIANFENXI @"a/api/exam/typeAnalysis"     //知识点分析

/* 错题模块接口 */
#define queWrongClassifyList        @"a/api/questionWrong/typeListAsNum"//错题分类列表
#define queWrongAllList             @"a/api/questionWrong/list"//全部错题列表
#define queWrongRecombinationList   @"a/api/questionWrong/wrongList"//错题重组列表
#define queWrongRecombinationSave   @"a/api/questionWrong/saveWrongPaper"//错题重组并生成试卷
#define queWrongDeleteObject  @"a/api/questionWrong/delete"  //删除错题
#define queWrongDetail        @"a/api/questionWrong/detail"  //错题详情
#define queWrongSaveAllAnswer       @"a/api/questionWrong/saveAnswerAll"  //错题列表保存所有答案
#define queWrongPaperDetail  @"a/api/questionWrong/wrongPaperDetail" //错题重组试卷详情
#define queWrongOtherData    @"a/api/questionWrong/getAdjoin" //错题详情上一题下..

/* 收藏列表 */
#define COLLECTLISTS @"a/api/questionCollect/list"
#define DoCollect @"a/api/questionCollect/doCollect"
#define CollectTitleDetail @"a/api/questionCollect/collectDetail"  //收藏详情

/* 消息列表 */
#define MESSAGELISTS @"a/api/message/list"
#define DELETEMESSAGE @"a/api/message/delete"
#define MESSAGEDETAIL @"a/api/message/detail"

#endif /* Common_h */
