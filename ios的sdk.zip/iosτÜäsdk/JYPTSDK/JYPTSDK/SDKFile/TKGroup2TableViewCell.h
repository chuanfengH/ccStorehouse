//
//  TKGroup2TableViewCell.h
//  TikuApp
//
//  Created by huangkeyuan on 16/8/18.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol TKGroup2Chice <NSObject>
- (void)getGroup2Answer:(int)kChoiceCell andchoice:(NSInteger)kChoiceRow andchildSubjectID:(NSString *)childSubjectID;
@end

@interface TKGroup2TableViewCell : UITableViewCell<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong)UILabel *iNameLabel;
@property (nonatomic,strong)UIButton *qingxuanzeButton;
@property (nonatomic,strong)NSString *iNameString;
@property (nonatomic,strong)NSString *childSubjectID;

@property (nonatomic) int labelHeight;
@property (nonatomic,strong)UICollectionView *selectCollectionView;
@property (nonatomic,strong)NSArray *wordArray;
@property (nonatomic) int tableNumber;
@property (nonatomic) int nowCellRow;//当前小题所在cell，也就是在外部tableview中是哪一个cell决定他是第几个小题
@property (nonatomic,strong)UIImageView *downImageView;
@property (weak, nonatomic) id<TKGroup2Chice> delegate;
@property (nonatomic)NSInteger rowNUmberAnswer;//当前选中行数
@property (nonatomic,copy) NSString *imagefileName;//图片所在文件名称
@property (nonatomic, strong) NSDictionary *paraStyleDic;//字体间距设置
@property (nonatomic)NSInteger rowNUmber;//选中答案

@end
