//
//  TKWendaTableViewCell.h
//  TikuApp
//
//  Created by huangkeyuan on 16/8/15.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol TKWENDAAnswer <NSObject>

- (void)getWendaAnswer:(NSString *)kAddressString ;

@end
@interface TKWendaTableViewCell : UITableViewCell<UITextViewDelegate>
@property (nonatomic,strong)  UITextView *contentTextView;
@property (nonatomic,strong)  UITextView *topTextView;
@property (weak, nonatomic) id<TKWENDAAnswer> delegate;
@end
