//
//  TKExaminationDetailViewController.m
//  TikuApp
//
//  Created by huangkeyuan on 16/7/27.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKExaminationDetailViewController.h"
#import "TestMain.h"
#import "TKWendaTableViewCell.h"
#import "TKTiankongTableViewCell.h"
#import "TKGroup1TableViewCell.h"
#import "TKGroup2TableViewCell.h"
#import "UITableView+FDTemplateLayoutCell.h"
#import "TKDetailBaseCell.h"
#import "XWScanImage.h"
#import "TKJYManager.h"

@interface TKExaminationDetailViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UITextViewDelegate,TKWENDAAnswer,TKGroup1Chice,TKGroup2Chice>
@property (nonatomic,strong)NSArray *dataArray;//从数据库中取出的数据（整套试卷的所有题目的数组）
@property (nonatomic,strong)UITableView *detailTabelView;//当前页面的tableview
@property (nonatomic,strong)UILabel *questionLabel;//页面中的题目的label
@property (nonatomic,copy)NSString *subjectType;//当前题目属于属于的题目类型
@property (nonatomic,strong)NSArray *subjectArray;//通常情况代表选项的数组
@property (nonatomic,strong)NSArray *aaArray;//答案标示的数组例A,B,C,D...
@property (nonatomic) NSInteger nowNumber;//当前页数
@property (nonatomic,strong)UIView *headMineView;//tableview的头部视图的view
@property (nonatomic) int tiankonggeshu;//填空题的填空个数
@property (nonatomic,strong) NSMutableArray *stateArray;//group2类型时的展开与否的状态数组
@property (nonatomic,strong) NSArray *group2xuanxiangArray;//group2类型时对应的公用选项的数组
@property (nonatomic,copy) NSString *imagefileName;//图片所在文件名称
@property (nonatomic,strong) NSArray *allTitleArray;
@property (nonatomic)NSInteger rowNUmber;
@property (nonatomic,copy) NSString *subjectTitleID;//题目ID
@property (nonatomic,strong) NSMutableArray *duoxuanArray;

@property (nonatomic,strong) NSMutableArray *tiankongMutArray;//填空题存答案
@property (nonatomic,strong) NSMutableArray *group1MutArray;//group1存答案数组
@property (nonatomic,strong) NSMutableArray *group2MutArray;//group2存答案数组
@property (nonatomic,copy) NSString *wendaString;//问答数据库中答案
@property (nonatomic,strong) NSMutableArray *baseGroup1Array;//数据库中group1的答案；
@property (nonatomic,strong) NSMutableArray *baseGroup2Array;//数据库中group2的答案
@property (nonatomic,strong) NSMutableArray *answerStateMutArr;//是否已答题数组
@property (nonatomic,strong) NSMutableArray *weidatiMutArr;//未答题数组
@property (strong, nonatomic) UIView *whiteView;
@property (nonatomic) int backNumber;//点击返回是隐藏还是返回导航
@property (nonatomic, strong) UIView *baocunView;

@property (nonatomic) long long countdownHour;
@property (nonatomic) long long countdownMintue;
@property (nonatomic) long long countdownSencond;

@property (nonatomic, strong) UILabel *otherLabel;//剩余多少题未答label

@property (nonatomic, strong) NSMutableArray *questionsMutArray;//用于存储题目对应的location值和题目是否答过的
//从全部题目列表collectionview和未答题collectionview点击之后的标示，1是0否，
@property (nonatomic) NSInteger isCollectionViewCome;
@property (nonatomic, strong) NSDictionary *paraStyleDic;//字体间距设置

@end

@implementation TKExaminationDetailViewController
{
    UIView *background;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.hidden = YES;
    self.managedObjectContext = [[TKJYManager sharedClient] managedObjectContext];

    BOOL isSuccess = [self unZipStatus];
    if (isSuccess == YES)
    {
        self.dataArray = [[NSArray alloc] init];
        _subjectArray = [[NSArray alloc] init];
        _group2xuanxiangArray = [[NSArray alloc] init];
        _allTitleArray = [[NSArray alloc] init];
        _duoxuanArray = [[NSMutableArray alloc] init];
        _tiankongMutArray = [[NSMutableArray alloc] init];
        _group1MutArray = [[NSMutableArray alloc] init];
        _group2MutArray = [[NSMutableArray alloc] init];
        _baseGroup1Array = [[NSMutableArray alloc] init];
        _baseGroup2Array = [[NSMutableArray alloc] init];
        _answerStateMutArr = [[NSMutableArray alloc] init];
        _weidatiMutArr = [[NSMutableArray alloc] init];
        _questionsMutArray = [[NSMutableArray alloc] init];
        [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:_detailID];
        
        _nowNumber = 1;
        _isCollectionViewCome = 0;
        //coreData查询语句，查询出当前试题id对应的所有数据
        NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
        NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
        request.predicate = [NSPredicate predicateWithFormat:searchId];
        
        //获取当前数据库所在目录文件路径
        //    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        //    NSString *savePath = [paths objectAtIndex:0];
        
        self.dataArray = [self.managedObjectContext executeFetchRequest:request error:nil];
        
        //执行父类绘制导航 赋值导航标题
        [self createDeatilNavigationBarWithTitle:[self.dataArray[_nowNumber - 1] valueForKey:@"test_name"] andRightButtonImageName:@"TKdetail_right"];
        
        _imagefileName = [self.dataArray[_nowNumber - 1] valueForKey:@"fileName"];
        
        self.aaArray = [NSArray arrayWithObjects:@"A.",@"B.",@"C.",@"D.",@"E.",@"F.",@"G.",@"H.",@"I.",@"J.",@"K.", nil];
        
#pragma mark tableView
        
        _detailTabelView = [[UITableView alloc] initWithFrame:CGRectMake(0, 108, SCREEN_WIDTH, SCREEN_HEIGHT - 50 - 64 - 44)];
        _detailTabelView.delegate = self;
        _detailTabelView.dataSource = self;
        [self.view addSubview:_detailTabelView];
        _detailTabelView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_detailTabelView registerClass:[TKGroup2TableViewCell class] forCellReuseIdentifier:@"grop2"];
        [_detailTabelView registerNib:[UINib nibWithNibName:@"TKDetailBaseCell" bundle:nil] forCellReuseIdentifier:@"newDetailCell"];
        
        _allTitleArray = [[NSString stringWithFormat:@"%ld. %@",_nowNumber,[self.dataArray[0] valueForKey:@"title"]] componentsSeparatedByString:@"##"];
        
        for (TestMain *test in self.dataArray) {
            if ([test.type isEqualToString:@"Group1"] ||
                [test.type isEqualToString:@"Group2"])
            {
                NSArray *arr =  [NSKeyedUnarchiver unarchiveObjectWithData:test.child_options];
                
                NSArray *completArr = [test.iscompleted componentsSeparatedByString:@","];
                
                for (int i = 0; i < arr.count; i ++) {
                    
                    NSString *locationString = [arr[i] objectForKey:@"location"];
                    
                    NSMutableDictionary *locationDic = [[NSMutableDictionary alloc] init];
                    
                    [locationDic setValue:locationString forKey:@"kylocation"];
                    
                    [locationDic setValue:completArr[i] forKey:@"isAnswer"];
                    
                    [_questionsMutArray addObject:locationDic];
                }
            }
            else
            {
                NSMutableDictionary *locationDic = [[NSMutableDictionary alloc] init];
                [locationDic setObject:test.location forKey:@"kylocation"];
                [locationDic setValue:test.iscompleted forKey:@"isAnswer"];
                
                [_questionsMutArray addObject:locationDic];
            }
        }
        
        _subjectTitleID = [self.dataArray[0] valueForKey:@"title_id"];
        _homeworkTotalNumber = [_questionsMutArray count];
        
        //计算试题题目的标题所占的高度
        CGSize size = [_allTitleArray[0] boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 30, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;

        _headMineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, size.height +30)];
        if (_allTitleArray.count > 1) {
            _headMineView.frame = CGRectMake(0, 0, SCREEN_WIDTH, size.height +30 +110);
        }
        _headMineView.backgroundColor = [UIColor whiteColor];
        _detailTabelView.tableHeaderView = _headMineView;
#pragma mark 字符间距
        //设置文本格式
        NSMutableParagraphStyle *paraStyle = [[NSMutableParagraphStyle alloc] init];
        paraStyle.lineBreakMode = NSLineBreakByCharWrapping;
        paraStyle.alignment = NSTextAlignmentLeft;
        paraStyle.lineSpacing = 10; //设置行间距
        paraStyle.hyphenationFactor = 0.0;//连字属性 在iOS，唯一支持的值分别为0和1
        paraStyle.firstLineHeadIndent = 0.0;//首行缩进
        paraStyle.paragraphSpacingBefore = 0.0;//段首行空白空间
        paraStyle.headIndent = 0;//整体缩进(首行除外)
        paraStyle.tailIndent = 0;
        //可以增加设置字间距 NSKernAttributeName:@1.5f
        _paraStyleDic = @{NSFontAttributeName:[UIFont systemFontOfSize:15], NSParagraphStyleAttributeName:paraStyle
                          };
        _questionLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 20, SCREEN_WIDTH - 30, 100)];
        _questionLabel.backgroundColor = [UIColor whiteColor];
        _questionLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
        _questionLabel.numberOfLines = 0;
        NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:_allTitleArray[0] attributes:_paraStyleDic];
        _questionLabel.attributedText = rightStr;
        //让内容置顶
        [_questionLabel sizeToFit];
        
        [_headMineView addSubview:_questionLabel];
        
        
        if (_allTitleArray.count > 1) {
            
            for (int k = 0; k< _allTitleArray.count-1; k++) {
                //创建屏幕大小的imageView
                UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(60+ k*90, CGRectGetMaxY(_questionLabel.frame) + 10, 80, 80)];
                
                imageView.tag = 2000+k;
                
                //获取沙盒路径
                NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,_allTitleArray[k+1]]];
                
                //打印沙盒路径
//                NSLog(@"%@", NSHomeDirectory());
                
                //获取路径对应的图片文件
                UIImage *image = [UIImage imageWithContentsOfFile:path];
                
                //给imageView添加视图文件
                imageView.image = image;
                
                //将imageView添加到屏幕
                [_headMineView addSubview:imageView];
                
                imageView.userInteractionEnabled = YES;
                //添加点击手势
                //为UIImageView1添加点击事件
                UITapGestureRecognizer *tapGestureRecognizer1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scanBigImageClick1:)];
                [imageView addGestureRecognizer:tapGestureRecognizer1];
            }
            
        }else
        {
            for (UIImageView *titleImage in [_headMineView subviews]) {
                if (titleImage.tag >= 2000) {
                    [titleImage removeFromSuperview];
                }
            }
        }
        
#pragma mark 进行题目切换之后 需要更改的界面数值
        
        _nowNumber = 1;
        
        _subjectType = [self.dataArray[_nowNumber - 1] valueForKey:@"type"];
        
        self.detailType.text = [self.dataArray[_nowNumber - 1] valueForKey:@"questionModelName"];
        
        self.detailNumberLabel.text = [NSString stringWithFormat:@"%ld/%ld",_nowNumber,_homeworkTotalNumber];
        
#pragma mark 选择题
        if ([_subjectType isEqualToString:@"Choice"])//单选题
        {
            TestMain *test = self.dataArray[_nowNumber - 1];
            
            _subjectArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.options];
            
            
            
            //判断数据库中是否有答案 有的话 取出来 展示在选项上
            if (test.answer != nil) {
                NSArray *answerArray = [[NSArray alloc] init];
                answerArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.answer];
                NSDictionary *answerDic = answerArray[0];
                NSString *sttting = [answerDic objectForKey:@"answerList"][0];
                _rowNUmber = sttting.integerValue - 1;
            }else
            {
                _rowNUmber = -1;
            }
            
        }else if ([_subjectType isEqualToString:@"MultiChoice"])//多选题
        {
            TestMain *test = self.dataArray[_nowNumber - 1];
            _subjectArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.options];
            
            
        }else if ([_subjectType isEqualToString:@"Group1"])//公共题型 公用题干
        {
            
        }else if ([_subjectType isEqualToString:@"Group2"])//公共题型 公用选项
        {
            
        }else if ([_subjectType isEqualToString:@"Fill"])//填空题
        {
            
        }else if ([_subjectType isEqualToString:@"Essay"])//简答题
        {
            
        }else if ([_subjectType isEqualToString:@"Judge"])//判断题
        {
            _subjectArray = [NSArray arrayWithObjects:@"正确",@"错误",nil];
        }else
        {
            
        }
        
        [self isAnwseredState];
        
        _whiteView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        _whiteView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];
        [self.view addSubview:_whiteView];
        
        UIView *whiteCenter = [[UIView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH/2 - 150, 200, 300, 160)];
        whiteCenter.backgroundColor = [UIColor whiteColor];
        [_whiteView addSubview:whiteCenter];
        whiteCenter.layer.cornerRadius = 5.0;
        whiteCenter.layer.masksToBounds = YES;
        
        _otherLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 10, 250, 30)];
        _otherLabel.text = [NSString stringWithFormat:@"您尚有%lu道未答题,是否继续交卷?",(unsigned long)_weidatiMutArr.count];
        _otherLabel.textColor = [UIColor colorWithRed:0.22 green:0.61 blue:0.9 alpha:1];
        _otherLabel.font = [UIFont systemFontOfSize:15];
        [whiteCenter addSubview:_otherLabel];
        
        UIView *fengeView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_otherLabel.frame), SCREEN_WIDTH, 1)];
        fengeView.backgroundColor = [UIColor lightGrayColor];
        [whiteCenter addSubview:fengeView];
        
        UIButton *confimButton = [UIButton buttonWithType:UIButtonTypeCustom];
        confimButton.frame = CGRectMake(0, CGRectGetMaxY(_otherLabel.frame), whiteCenter.frame.size.width, 40);
        [confimButton setTitle:@"确认" forState:UIControlStateNormal];
        [confimButton setTitleColor:[UIColor colorWithRed:0.34 green:0.65 blue:0.87 alpha:1] forState:UIControlStateNormal];
        [confimButton addTarget:self action:@selector(submitALLAnswers) forControlEvents:UIControlEventTouchUpInside];
        [whiteCenter addSubview:confimButton];
        
        UIView *fengeView1 = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(confimButton.frame), SCREEN_WIDTH, 1)];
        fengeView1.backgroundColor = [UIColor lightGrayColor];
        [whiteCenter addSubview:fengeView1];
        
        UIButton *lookButton = [UIButton buttonWithType:UIButtonTypeCustom];
        lookButton.frame = CGRectMake(0, CGRectGetMaxY(confimButton.frame), whiteCenter.frame.size.width, 40);
        [lookButton setTitle:@"查看未答题序号" forState:UIControlStateNormal];
        [lookButton setTitleColor:[UIColor colorWithRed:0.22 green:0.61 blue:0.9 alpha:1] forState:UIControlStateNormal];
        [lookButton addTarget:self action:@selector(touchWeidati:) forControlEvents:UIControlEventTouchUpInside];
        [whiteCenter addSubview:lookButton];
        
        UIView *fengeView2 = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(lookButton.frame), SCREEN_WIDTH, 1)];
        fengeView2.backgroundColor = [UIColor lightGrayColor];
        [whiteCenter addSubview:fengeView2];
        
        UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
        cancelButton.frame = CGRectMake(0, CGRectGetMaxY(lookButton.frame), whiteCenter.frame.size.width, 40);
        [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
        [cancelButton setTitleColor:[UIColor colorWithRed:0.22 green:0.61 blue:0.9 alpha:1] forState:UIControlStateNormal];
        [cancelButton addTarget:self action:@selector(touchViewCancel) forControlEvents:UIControlEventTouchUpInside];
        //    [cancelButton setBackgroundColor:[UIColor redColor]];
        [whiteCenter addSubview:cancelButton];
        
        _whiteView.hidden = YES;
        
        _backNumber = 1;
        
        _baocunView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        _baocunView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];
        [self.view addSubview:_baocunView];
        
        UIButton *baocunAndBack = [UIButton buttonWithType:UIButtonTypeCustom];
        baocunAndBack.frame = CGRectMake(15, SCREEN_HEIGHT - 130, SCREEN_WIDTH - 30, 50);
        [baocunAndBack setTitle:@"保存进度退出答题" forState:UIControlStateNormal];
        [baocunAndBack setTitleColor:[UIColor colorWithRed:0.3 green:0.55 blue:0.74 alpha:1] forState:UIControlStateNormal];
        baocunAndBack.layer.cornerRadius = 3.0;
        baocunAndBack.layer.masksToBounds = YES;
        baocunAndBack.backgroundColor = [UIColor whiteColor];
        [_baocunView addSubview:baocunAndBack];
        [baocunAndBack addTarget:self action:@selector(backToLastButton:) forControlEvents:UIControlEventTouchUpInside];
        
        UIButton *baocunAndGoOn = [UIButton buttonWithType:UIButtonTypeCustom];
        baocunAndGoOn.frame = CGRectMake(15, SCREEN_HEIGHT - 70, SCREEN_WIDTH - 30, 50);
        [baocunAndGoOn setTitle:@"保存进度继续答题" forState:UIControlStateNormal];
        [baocunAndGoOn setTitleColor:[UIColor colorWithRed:0.3 green:0.55 blue:0.74 alpha:1] forState:UIControlStateNormal];
        baocunAndGoOn.layer.cornerRadius = 3.0;
        baocunAndGoOn.layer.masksToBounds = YES;
        baocunAndGoOn.backgroundColor = [UIColor whiteColor];
        [_baocunView addSubview:baocunAndGoOn];
        [baocunAndGoOn addTarget:self action:@selector(hidenBaocunView) forControlEvents:UIControlEventTouchUpInside];
        _baocunView.hidden = YES;

    }
    else
    {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:NO];
        });
    }
}

-(void)hidenBaocunView
{
    _baocunView.hidden = YES;
}

-(void)touchViewCancel
{
    _whiteView.hidden = YES;
}

//加载是否答题状态标示
-(void)isAnwseredState
{
    NSArray *answerStatueArr = [[NSArray alloc] init];
    
    //coreData查询语句，查询出当前试题id对应的所有数据
    self.managedObjectContext = [[TKJYManager sharedClient] managedObjectContext];
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
    NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",self.userId,self.detailID];
    request.predicate = [NSPredicate predicateWithFormat:searchId];
    
    answerStatueArr = [self.managedObjectContext executeFetchRequest:request error:nil];
    
    if (_questionsMutArray.count > 0) {
        [_questionsMutArray removeAllObjects];
    }
    
    for (int k = 0; k < answerStatueArr.count; k ++) {
        TestMain *test = answerStatueArr[k];
        
        if ([test.type isEqualToString:@"Group1"] ||
            [test.type isEqualToString:@"Group2"])
        {
            NSArray *arr =  [NSKeyedUnarchiver unarchiveObjectWithData:test.child_options];
            
            NSArray *completArr = [test.iscompleted componentsSeparatedByString:@","];
            
            for (int i = 0; i < arr.count; i ++) {
                
                NSString *locationString = [arr[i] objectForKey:@"location"];
                
                NSMutableDictionary *locationDic = [[NSMutableDictionary alloc] init];
                
                [locationDic setValue:locationString forKey:@"kylocation"];
                
                [locationDic setValue:completArr[i] forKey:@"isAnswer"];
                
                [_questionsMutArray addObject:locationDic];
            }
        }
        else
        {
            NSMutableDictionary *locationDic = [[NSMutableDictionary alloc] init];
            [locationDic setObject:test.location forKey:@"kylocation"];
            [locationDic setValue:test.iscompleted forKey:@"isAnswer"];
            
            
            [_questionsMutArray addObject:locationDic];
        }
    }
    
    
    //构筑未答题_weidatiMutArr数组的数据源
    if (_weidatiMutArr.count > 0) {
        [_weidatiMutArr removeAllObjects];
    }
    
    for (int y = 0; y < _questionsMutArray.count; y ++) {
        NSDictionary *InsideDic = _questionsMutArray[y];
        NSString *answerOrnotStr = [InsideDic objectForKey:@"isAnswer"];
        NSString *notAnswerNumber = [InsideDic objectForKey:@"kylocation"];
        
        if ([answerOrnotStr isEqualToString:@"0"]) {
            NSMutableDictionary *notAnswerDic = [[NSMutableDictionary alloc] init];
            
            [notAnswerDic setValue:notAnswerNumber forKey:@"kylocation"];
            
            NSString *notAnswerNumber = [NSString stringWithFormat:@"%d",y+1];
            
            [notAnswerDic setValue:notAnswerNumber forKey:@"notAnswerNumber"];
            
            [_weidatiMutArr addObject:notAnswerDic];
            
        }
    }
    
}

#pragma mark 选项有图片时调用的方法，目前支持单选，多选
- (void)configCell:(TKDetailBaseCell *)cell indexpath:(NSIndexPath *)indexPath
{
    if ([_subjectType isEqualToString:@"Judge"]){//判断题
        cell.checkLabel.text = [NSString stringWithFormat:@"%@",_subjectArray[indexPath.row]];
        cell.selectImageView1.image = nil;
        cell.selectImageView1.hidden = YES;
        cell.selectImageView2.hidden = YES;
        cell.selectImageView3.hidden = YES;
        cell.selectImageViewHeight.constant = 0.0;
    } else
    {
        NSArray *longAnswerArray = [[NSString stringWithFormat:@"%@%@",self.aaArray[indexPath.row],_subjectArray[indexPath.row]] componentsSeparatedByString:@"##"];
        
        cell.checkLabel.text = longAnswerArray[0];
        
        if (longAnswerArray.count > 1) {
            
            //        for (int p = 0; p < longAnswerArray.count - 1; p++) {
            //获取沙盒路径
            NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,longAnswerArray[1]]];
            
            //获取路径对应的图片文件
            UIImage *image = [UIImage imageWithContentsOfFile:path];
            
            //给imageView添加视图文件
            cell.selectImageView1.image = image;
            
            //获取沙盒路径
            NSString *path1 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,longAnswerArray[2]]];
            
            //获取路径对应的图片文件
            UIImage *image1 = [UIImage imageWithContentsOfFile:path1];
            
            //给imageView添加视图文件
            cell.selectImageView2.image = image1;
            
            //获取沙盒路径
            NSString *path2 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,longAnswerArray[3]]];
            
            //获取路径对应的图片文件
            UIImage *image2 = [UIImage imageWithContentsOfFile:path2];
            
            //给imageView添加视图文件
            cell.selectImageView3.image = image2;
            //        }
            
            cell.selectImageViewHeight.constant = 80.0;
            
            cell.selectImageView1.hidden = NO;
            cell.selectImageView2.hidden = NO;
            cell.selectImageView3.hidden = NO;
            
            
        }else{
            
            cell.selectImageView1.image = nil;
            cell.selectImageView1.hidden = YES;
            cell.selectImageView2.hidden = YES;
            cell.selectImageView3.hidden = YES;
            cell.selectImageViewHeight.constant = 0.0;
        }
        
    }
    
    
}

#pragma mark tabelViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([_subjectType isEqualToString:@"Choice"]) {//单选题
        return _subjectArray.count;
    }
    else if ([_subjectType isEqualToString:@"MultiChoice"])//多选题
    {
        return _subjectArray.count;
    }
    else if ([_subjectType isEqualToString:@"Group1"])//公共题型 公用题干
    {
        return _subjectArray.count;
    }
    else if ([_subjectType isEqualToString:@"Group2"])//公共题型 公用选项
    {
        return _subjectArray.count;
    }
    else if ([_subjectType isEqualToString:@"Fill"])//填空题
    {
        return _tiankonggeshu;
    }
    else if ([_subjectType isEqualToString:@"Judge"])//判断题
    {
        return 2;
    }
    else if ([_subjectType isEqualToString:@"Essay"])//简答题
    {
        return 1;
        
    }else
    {
        return 1;
    }
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([_subjectType isEqualToString:@"Choice"]) {//单选题
#pragma mark 选择题
        static NSString *iIdentifier = @"newDetailCell";
        TKDetailBaseCell *cell = [tableView dequeueReusableCellWithIdentifier:iIdentifier];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"TKDetailBaseCell" owner:self options:nil] lastObject];
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [cell.checkButton setBackgroundImage:[UIImage imageNamed:@"TKdetail_unselect"] forState:UIControlStateNormal];
        
        [cell.checkButton setBackgroundImage:[UIImage imageNamed:@"TKdetail_select"] forState:UIControlStateSelected ];
        
        [cell.checkButton addTarget:self action:@selector(touchSelectButton:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.checkButton.tag = indexPath.row;
        
        [self configCell:cell indexpath:indexPath];
        
        if (indexPath.row != _rowNUmber) {
            cell.checkButton.selected = NO;
        }else
        {
            cell.checkButton.selected = YES;
        }
        
        return cell;
        
    }else if ([_subjectType isEqualToString:@"MultiChoice"])//多选题
    {
#pragma mark 多项选择题
        TKDetailBaseCell *cell = [tableView dequeueReusableCellWithIdentifier:@"duoxuan"];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"TKDetailBaseCell" owner:self options:nil] lastObject];
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [self configCell:cell indexpath:indexPath];
        
        [cell.checkButton setBackgroundImage:[UIImage imageNamed:@"TKtiankong_unselect"] forState:UIControlStateNormal];
        
        [cell.checkButton setBackgroundImage:[UIImage imageNamed:@"TKtiankong_select"] forState:UIControlStateSelected ];
        
        [cell.checkButton addTarget:self action:@selector(touchSelectMultiChoiceButton:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.checkButton.tag = indexPath.row;
        
        if (_duoxuanArray.count > 0) {
            for (NSNumber *selectNumber in _duoxuanArray) {
                if (selectNumber.integerValue == indexPath.row) {
                    cell.checkButton.selected = YES;
                }
            }
        }
        
        return cell;
    }else if ([_subjectType isEqualToString:@"Group1"])//公共题型 公用题干
    {
        TKGroup1TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"group1cell"];
        
        if (cell == nil) {
            cell = [[TKGroup1TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"group1cell"];
        }
        
        //        cell.backgroundColor = [UIColor redColor];
        
        cell.cellInfoArray = [_subjectArray[indexPath.row] objectForKey:@"choiceList"];//将公用题干的每一个小题的选项数组传递到cell中进行数据的赋值
        
        cell.imagefileName = _imagefileName;
        
        cell.cellInfoDiction = _subjectArray[indexPath.row];//将公用题干的每一个小题的数组传递到cell中进行数据的赋值
        cell.cellInfoNumber = [[self.dataArray[_nowNumber - 1] valueForKey:@"questionNum"] intValue];;//传递当前大题数到cell中展示
        cell.littleCellNumber = (int)indexPath.row;//传递到cell中展示出当前小题数
        
        cell.fatherSubjectID = _subjectTitleID;
        
        cell.childSubjectID = [_subjectArray[indexPath.row] objectForKey:@"id"];
        
        //判断取出的答案是否为空，空的话选项全部为未选中，否则传递到cell的rowNumber进行返现。
        
        if (_group1MutArray.count > 0) {
//            NSDictionary *ooDic = _group1MutArray[indexPath.row];
            
            NSArray *answerListKA = [_group1MutArray[indexPath.row] objectForKey:@"answerList"];
            
            NSString *answerStringkk = answerListKA[0];
            
            if ([answerStringkk isEqualToString:@" "]) {
                cell.rowNUmber = -1;
            }else
            {
                NSArray *littleAnswerArr = [[NSArray alloc] init];
                littleAnswerArr = [_group1MutArray[indexPath.row] objectForKey:@"answerList"];
                NSString *sttting = littleAnswerArr[0];
                cell.rowNUmber = sttting.integerValue - 1;
            }
            
        }else
        {
            cell.rowNUmber = -1;
        }
        
        
        
        //将当前cell的高度传递到cell中
        //计算出小题中的选项的数量从而确定cell的高度
        NSArray *zhongjianArray =  [_subjectArray[indexPath.row] objectForKey:@"choiceList"];
        
        //计算这种组合题中每一小题中的选项是否折行 然后计算出该小题中的选项对应的高度。
        CGFloat xuanxiangTotalHeight = 0.0;
        
        for (int x= 0; x < zhongjianArray.count; x++) {
            CGSize size = [[NSString stringWithFormat:@"A.%@",zhongjianArray[x]] boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 40, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;
            NSArray *chioceArrayIsImage = [zhongjianArray[x] componentsSeparatedByString:@"##"];
            
            //判断选项中是否含有图片，含有图片加上80的高度
            if (chioceArrayIsImage.count > 1) {
                xuanxiangTotalHeight =  size.height + xuanxiangTotalHeight +70;
            }else
            {
                xuanxiangTotalHeight =  size.height + xuanxiangTotalHeight + 10;
            }
        }
        //最后xuanxiangTotalHeight就是得到的小题中所有选项对赢得高度
//        NSLog(@"%f",xuanxiangTotalHeight);
        
        //小题的题目字符串
        NSArray *titleArray = [[NSString stringWithFormat:@"8-1.%@",[_subjectArray[indexPath.row] objectForKey:@"name"]] componentsSeparatedByString:@"##"];
        
        //计算试题题目的标题所占的高度
        CGSize size = [titleArray[0] boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 30, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;
        
        if (titleArray.count > 1) {
            cell.heightCellNumber =  xuanxiangTotalHeight + size.height + 95 + 15;
        }else
        {
            cell.heightCellNumber = xuanxiangTotalHeight + size.height +15;
        }
        
        cell.fileNameCell = _imagefileName;
        
        cell.delegate = self;
        
        return cell;
    }else if ([_subjectType isEqualToString:@"Group2"])//公共题型 公用选项
    {
        TKGroup2TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"grop2"];
        if (cell == nil) {
            cell = [[TKGroup2TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"grop2"];
        }
        //根据tableview的状态数组判断cell中的tableview是否展开
        //        if (self.stateArray.count > 0) {
        //            cell.openTableView.hidden = ![self.stateArray[indexPath.row] boolValue];
        //        }else
        //        {
        //            cell.openTableView.hidden = YES;
        //        }
        
        //计算题目标题的高度传递到cell中进行题目的自适应展示，同时根据标题的高度改变对应控件的高度
        CGSize size = [[NSString stringWithFormat:@"%ld-%ld.%@",(long)_nowNumber,(long)indexPath.row + 1,[_subjectArray[indexPath.row] objectForKey:@"name"]] boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 30, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;
        
        cell.labelHeight = size.height;
        
        cell.iNameString = [NSString stringWithFormat:@"%@.%@",[_subjectArray[indexPath.row] objectForKey:@"questionNum"],[_subjectArray[indexPath.row] objectForKey:@"name"]];
        
        cell.childSubjectID = [_subjectArray[indexPath.row] objectForKey:@"id"];
        
        //将有多少个选项传递到cell中
        cell.tableNumber = (int)_group2xuanxiangArray.count;
        
        cell.nowCellRow =  (int)indexPath.row;
        
        cell.imagefileName = _imagefileName;
        
        //判断取出的答案是否为空，空的话选项全部为未选中，否则传递到cell的rowNumber进行返现。
        
        if (_group2MutArray.count > 0) {
//            NSDictionary *ooDic = _group2MutArray[indexPath.row];
            
            NSArray *answerListKA = [_group2MutArray[indexPath.row] objectForKey:@"answerList"];
            
            NSString *answerStringkk = answerListKA[0];
            
            if ([answerStringkk isEqualToString:@" "]) {
                cell.rowNUmberAnswer = -1;
            }else
            {
                NSArray *littleAnswerArr = [[NSArray alloc] init];
                littleAnswerArr = [_group2MutArray[indexPath.row] objectForKey:@"answerList"];
                //                int numberToA = [littleAnswerArr[0] intValue] + 64;
                //                cell.rowNUmberAnswer = [NSString stringWithFormat:@"%c",numberToA];
                NSString *sttting = littleAnswerArr[0];
                cell.rowNUmberAnswer = sttting.integerValue - 1;
            }
        }else
        {
            cell.rowNUmberAnswer = -1;
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        cell.delegate = self;
        
        return cell;
        
    }else if ([_subjectType isEqualToString:@"Fill"])//填空题
    {
        TKTiankongTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"tiankongCell"];
        if (cell == nil) {
            cell = [[TKTiankongTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"tiankongCell"];
        }
        
        cell.numberLabel.text = [NSString stringWithFormat:@"%ld.",indexPath.row + 1];
        
        cell.tiankongTF.tag = 888+indexPath.row;
        
        cell.tiankongTF.delegate = self;
        
        if ([_tiankongMutArray[indexPath.row] isEqualToString:@" "]) {
            
            cell.tiankongTF.placeholder = @"输入对应顺序答案";
            
            cell.tiankongTF.text = nil;
        }else
        {
            cell.tiankongTF.text = _tiankongMutArray[indexPath.row];
        }
        
        return cell;
        
    }else if ([_subjectType isEqualToString:@"Essay"])//简答题
    {
        TKWendaTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"wendacell"];
        if (cell == nil) {
            cell = [[TKWendaTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"wendacell"];
        }
        
        cell.contentTextView.delegate = self;
        
        cell.topTextView.delegate = self;
        
        if (_wendaString != nil) {
            cell.topTextView.hidden = YES;
            cell.contentTextView.text = _wendaString;
            cell.contentTextView.backgroundColor = [UIColor whiteColor];
            
        }else
        {
            cell.topTextView.hidden = NO;
            cell.contentTextView.text = nil;
            cell.contentTextView.backgroundColor = [UIColor clearColor];
        }
        cell.delegate = self;
        
        return cell;
        
    }else if ([_subjectType isEqualToString:@"Judge"])//判断题
    {
        TKDetailBaseCell *cell = [tableView dequeueReusableCellWithIdentifier:@"panduancell"];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"TKDetailBaseCell" owner:self options:nil] lastObject];
        }
        [self configCell:cell indexpath:indexPath];
        
        [cell.checkButton setBackgroundImage:[UIImage imageNamed:@"TKdetail_unselect"] forState:UIControlStateNormal];
        
        [cell.checkButton setBackgroundImage:[UIImage imageNamed:@"TKdetail_select"] forState:UIControlStateSelected ];
        
        [cell.checkButton addTarget:self action:@selector(touchSelectJudgeButton:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.checkButton.tag = indexPath.row;
        
        if (indexPath.row != _rowNUmber) {
            cell.checkButton.selected = NO;
        }else
        {
            cell.checkButton.selected = YES;
        }
        
        return cell;
    }else
    {
        TKDetailBaseCell *cell = [tableView dequeueReusableCellWithIdentifier:@"other"];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"TKDetailBaseCell" owner:self options:nil] lastObject];
        }
        
        cell.checkLabel.text = [NSString stringWithFormat:@"%@%@",self.aaArray[indexPath.row],_subjectArray[indexPath.row]];
        
        return cell;
    }
    
    
    
}




-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([_subjectType isEqualToString:@"Essay"])//简答题
    {
        return 200;
    }
    else if ([_subjectType isEqualToString:@"Group1"])//group1 公共题型公用题干
    {
        //计算出小题中的选项的数量从而确定cell的高度
        NSArray *zhongjianArray =  [_subjectArray[indexPath.row] objectForKey:@"choiceList"];
        
        //计算这种组合题中每一小题中的选项是否折行 然后计算出该小题中的选项对应的高度。
        CGFloat xuanxiangTotalHeight = 0.0;
        
        for (int x= 0; x < zhongjianArray.count; x++) {
            CGSize size = [[NSString stringWithFormat:@"A.%@",zhongjianArray[x]] boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 40, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;
            NSArray *chioceArrayIsImage = [zhongjianArray[x] componentsSeparatedByString:@"##"];
            
            //判断选项中是否含有图片，含有图片加上80的高度
            if (chioceArrayIsImage.count > 1) {
                xuanxiangTotalHeight =  size.height + xuanxiangTotalHeight + 70;
            }else
            {
                xuanxiangTotalHeight =  size.height + xuanxiangTotalHeight + 10;
            }
            
        }
        //最后xuanxiangTotalHeight就是得到的小题中所有选项对赢得高度
//        NSLog(@"%f",xuanxiangTotalHeight);
        
        //小题的题目字符串
        NSArray *titleArray = [[NSString stringWithFormat:@"8-1.%@",[_subjectArray[indexPath.row] objectForKey:@"name"]] componentsSeparatedByString:@"##"];
        
        //计算试题题目的标题所占的高度
        CGSize size = [titleArray[0] boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 30, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;
        
        if (titleArray.count > 1) {
            return xuanxiangTotalHeight + size.height + 95 +15;
        }
        return xuanxiangTotalHeight + size.height + 15;
        
        
    }else if ([_subjectType isEqualToString:@"Group2"])//group2 公共题型公用选项
    {
        NSArray *titleArray = [[NSString stringWithFormat:@"%ld-%ld.%@",_nowNumber+1,(long)indexPath.row,[_subjectArray[indexPath.row] objectForKey:@"name"]] componentsSeparatedByString:@"##"];
        
        //计算试题题目的标题所占的高度
        CGSize size = [titleArray[0] boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 30, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;
        
        if (titleArray.count > 1) {
            
            return size.height + _group2xuanxiangArray.count%2*40+40 + 110;
            
        }else
        {
            return size.height + _group2xuanxiangArray.count%2*40+40 + 30;
            
        }
        
        
    }else if ([_subjectType isEqualToString:@"Fill"])//填空题
    {
        return 44.0;
        
    }else
    {
        return [tableView fd_heightForCellWithIdentifier:@"newDetailCell" cacheByIndexPath:indexPath configuration:^(TKDetailBaseCell *cell) {
            if (_subjectArray.count > 0) {
                [self configCell:cell indexpath:indexPath];
            }
        }];
        
    }
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_subjectType isEqualToString:@"Essay"])//简答题
    {
        
    }else if ([_subjectType isEqualToString:@"Group1"])//group1 公共题型公用题干
    {
        
        
    }else if ([_subjectType isEqualToString:@"Group2"])//group2 公共题型公用选项
    {
        //选中之后将cell的状态值置为1，表示cell中的tableview进行展开
        //        if ([self.stateArray[indexPath.row] isEqualToString:@"0"]) {
        //            [self.stateArray replaceObjectAtIndex:indexPath.row withObject:@"1"];
        //        }else
        //        {
        //            [self.stateArray replaceObjectAtIndex:indexPath.row withObject:@"0"];
        //        }
        
        [self.detailTabelView reloadData];
    }else if ([_subjectType isEqualToString:@"MultiChoice"])//多选题
    {
        TKDetailBaseCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        
        if (cell.checkButton.selected) {
            cell.checkButton.selected = NO;
            [_duoxuanArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                
                if ([[NSString stringWithFormat:@"%@",obj] isEqualToString:[NSString stringWithFormat:@"%ld",(long)indexPath.row]]) {
                    
                    [_duoxuanArray removeObject:obj];
                }
            }];
        }else
        {
            cell.checkButton.selected = YES;
            [_duoxuanArray addObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
        }
        
        NSArray *newArray = [_duoxuanArray sortedArrayUsingSelector:@selector(compare:)];
        
        
        NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
        NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
        
        request.predicate = [NSPredicate predicateWithFormat:searchId];
        NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
        for (TestMain *title in array)
        {
            if ([title.title_id isEqualToString:_subjectTitleID])
            {
                
                NSArray *chioceArray = [NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11", nil];
                
                NSString *totalString;
                
                for (NSString *numberSTR in newArray) {
                    NSInteger number = numberSTR.integerValue;
                    
                    if (totalString == nil) {
                        totalString = chioceArray[number];
                    }else
                    {
                        totalString = [NSString stringWithFormat:@"%@%@",totalString,chioceArray[number]];
                    }
                }
                
                NSMutableDictionary *huaDic = [[NSMutableDictionary alloc] init];
                
                [huaDic setValue:_subjectTitleID forKey:@"questionId"];
                
                NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
                
//                NSLog(@"%@",totalString);
                
                //加入多选之后答案选项是否为空，解决totalString为空还添加数组导致崩溃的情况
                if (totalString == nil) {
                    
                }else
                {
                    [yyyArray addObject:totalString];
                    
                }
                
                [huaDic setValue:yyyArray forKey:@"answerList"];
                
                NSMutableArray *huaArray = [[NSMutableArray alloc] init];
                
                [huaArray addObject:huaDic];
                
                if (huaArray.count > 0) {
                    NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:huaArray];
                    title.answer = childOptions;
                    title.iscompleted = @"1";
                }
                //                 Save the context.
                NSError *error = nil;
                
                if (![self.managedObjectContext save:&error])
                {
                    NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                    abort();
                }
            }
        }
    }else if ([_subjectType isEqualToString:@"Choice"])//单选题
    {
        _rowNUmber = indexPath.row;
        
        [_detailTabelView reloadData];
        
        NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
        NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
        
        request.predicate = [NSPredicate predicateWithFormat:searchId];
        NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
        for (TestMain *title in array)
        {
            if ([title.title_id isEqualToString:_subjectTitleID])
            {
                //将用户选择的答案与题目id对应产生dictionary，然后将dictionary存入数组，再将数组存入数据库中answer字段中
                NSArray *chioceArray = [NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11", nil];
                
                NSMutableDictionary *huaDic = [[NSMutableDictionary alloc] init];
                
                [huaDic setValue:_subjectTitleID forKey:@"questionId"];
                
                
                NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
                
                [yyyArray addObject:chioceArray[indexPath.row]];
                
                [huaDic setValue:yyyArray forKey:@"answerList"];
                
                NSMutableArray *huaArray = [[NSMutableArray alloc] init];
                
                [huaArray addObject:huaDic];
                
                if (huaArray.count > 0) {
                    NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:huaArray];
                    title.answer = childOptions;
                    title.iscompleted = @"1";
                    
                }
                
                // Save the context.
                NSError *error = nil;
                if (![self.managedObjectContext save:&error])
                {
                    NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                    abort();
                }
            }
        }
    }else if ([_subjectType isEqualToString:@"Judge"])//判断题
    {
        
        _rowNUmber = indexPath.row;
        
        [_detailTabelView reloadData];
        
        NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
        NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
        
        request.predicate = [NSPredicate predicateWithFormat:searchId];
        NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
        for (TestMain *title in array)
        {
            if ([title.title_id isEqualToString:_subjectTitleID])
            {
                //将用户选择的答案与题目id对应产生dictionary，然后将dictionary存入数组，再将数组存入数据库中answer字段中
                
                
                NSMutableDictionary *huaDic = [[NSMutableDictionary alloc] init];
                
                if (indexPath.row == 0) {//正确
                    
                    [huaDic setValue:_subjectTitleID forKey:@"questionId"];
                    
                    NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
                    
                    [yyyArray addObject:@"true"];
                    
                    [huaDic setValue:yyyArray forKey:@"answerList"];
                    
                }else//错误
                {
                    
                    [huaDic setValue:_subjectTitleID forKey:@"questionId"];
                    
                    NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
                    
                    [yyyArray addObject:@"false"];
                    
                    [huaDic setValue:yyyArray forKey:@"answerList"];
                    
                }
                
                NSMutableArray *huaArray = [[NSMutableArray alloc] init];
                
                [huaArray addObject:huaDic];
                
                if (huaArray.count > 0) {
                    NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:huaArray];
                    title.answer = childOptions;
                    title.iscompleted = @"1";
                    
                }
                
                // Save the context.
                NSError *error = nil;
                if (![self.managedObjectContext save:&error])
                {
                    NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                    abort();
                }
            }
        }
    }
    else
    {
        
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark 点击返回
-(void)backToLastButton:(UIButton *)leftBackButton
{
    if (_backNumber == 0) {
        _whiteView.hidden = YES;
        _detailTabelView.hidden = YES;
        self.weidatiView.hidden = YES;
        _detailTabelView.hidden = NO;
        self.collectBackgroundView.hidden = YES;
        _backNumber = 1;
    }else
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}


#pragma mark 点击保存
-(void)touchBaocun:(UIButton *)button
{
    //    [self submitALLAnswers];
    _baocunView.hidden = NO;
}



-(void)submitALLAnswers
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
    NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
    
    request.predicate = [NSPredicate predicateWithFormat:searchId];
    NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
    
    NSMutableArray *woshiArray = [[NSMutableArray alloc] init];
    
    for (TestMain *title in array)
    {
        NSArray *answerArray = [[NSArray alloc] init];
        answerArray = [NSKeyedUnarchiver unarchiveObjectWithData:title.answer];
        //        NSLog(@"%@",answerArray);
        
        for (NSDictionary *itemDiction in answerArray) {
            [woshiArray addObject:itemDiction];
        }
    }
    
    NSDictionary *dic = [[NSDictionary alloc] init];
    dic = @{@"studentId":_userId,
            @"examId":self.detailID,
            @"stuAnswers":woshiArray};
    
    //    NSLog(@"%@DSFVADFVADFVADV",dic);
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    
    NSString *jsonStr=[[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    NSDictionary *oooDic = @{@"result":jsonStr};
    
    //    NSLog(@"%@",oooDic);
    
    [MBProgressHUD showLoadToView:self.view];
    [[TKAFNetWorkingClient sharedClient] Post:ExaminationSaveAllAnswre
                                   Parameters:oooDic
                                      Success:^(id responseObject)
     {
         [MBProgressHUD hideHUDForView:self.view];
         //请求成功：
         if ([[responseObject objectForKey:@"result"] integerValue] == 1)
         {
             [MBProgressHUD showAutoMessage:@"提交成功"];
             dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                 
                 [[NSUserDefaults standardUserDefaults] removeObjectForKey:self.detailID];
                 self.CommitHomeworkResponseBlock(YES);
                 [self.navigationController popViewControllerAnimated:YES];
             });
         }else
         {
             self.CommitHomeworkResponseBlock(NO);
             [MBProgressHUD showMessage:[responseObject objectForKey:@"msg"] ToView:self.view RemainTime:1.5];
         }
     } Failure:^(NSError *error) {
         self.CommitHomeworkResponseBlock(NO);
         [MBProgressHUD hideHUDForView:self.view];
         //请求失败
         [MBProgressHUD showError:@"网络错误" ToView:self.view];
     }];
}


#pragma mark 点击提交
-(void)touchTijiao:(UIButton *)button
{
    [self isAnwseredState];
    _otherLabel.text = [NSString stringWithFormat:@"您尚有%lu道未答题,是否继续交卷?",(unsigned long)_weidatiMutArr.count];
    _whiteView.hidden = NO;
}


#pragma mark 上/下一题切换
-(void)changeSubjectsDatas
{
    
    //当前的题目类型
    _subjectType = [self.dataArray[_nowNumber - 1] valueForKey:@"type"];
    
//    NSLog(@"%@",_subjectType);
    //当前需要显示的题目类型
    self.detailType.text = [self.dataArray[_nowNumber - 1] valueForKey:@"questionModelName"];
    
    if (_isCollectionViewCome == 0) {
        //当前题数/所有题数
        self.detailNumberLabel.text = [NSString stringWithFormat:@"%@/%ld",[self.dataArray[_nowNumber - 1] valueForKey:@"questionNum"],_homeworkTotalNumber];
    }else
    {
        //当前题数/所有题数
        self.detailNumberLabel.text = [NSString stringWithFormat:@"%ld/%ld",_isCollectionViewCome,_homeworkTotalNumber];
    }
    
    
    NSArray *titleArray = [[NSString stringWithFormat:@"%@. %@",[self.dataArray[_nowNumber - 1] valueForKey:@"questionNum"],[self.dataArray[_nowNumber - 1] valueForKey:@"title"]] componentsSeparatedByString:@"##"];
    
    _subjectTitleID = [self.dataArray[_nowNumber - 1] valueForKey:@"title_id"];
    
    //计算试题题目的标题所占的高度
    CGSize size = [titleArray[0] boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 30, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;
    
    _headMineView.frame = CGRectMake(0, 0, SCREEN_WIDTH, size.height +20 +20);
    
    if (titleArray.count > 1) {
        
        _headMineView.frame = CGRectMake(0, 0, SCREEN_WIDTH, size.height +110 + 20);
    }
    
    _questionLabel.frame = CGRectMake(15, 20, SCREEN_WIDTH - 30, 100);
    
    //    _questionLabel.text = titleArray[0];
    
    NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:titleArray[0] attributes:_paraStyleDic];
    
    _questionLabel.attributedText = rightStr;
    
    //让内容置顶
    [_questionLabel sizeToFit];
    
    if (titleArray.count > 1) {
        
        for (UIImageView *titleImage in [_headMineView subviews]) {
            if (titleImage.tag >= 2000) {
                [titleImage removeFromSuperview];
            }
        }
        
        for (int k = 0; k< titleArray.count-1; k++) {
            //创建屏幕大小的imageView
            UIImageView *kkkkView = [[UIImageView alloc] initWithFrame:CGRectMake(60+ k*90, CGRectGetMaxY(_questionLabel.frame)+10, 80, 80)];
            //
            kkkkView.tag = 2000+k;
            
            //获取沙盒路径
            NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,titleArray[k+1]]];
            
            //打印沙盒路径
            //                NSLog(@"%@ %@", NSHomeDirectory(),titleArray[k+1]);
            
            //获取路径对应的图片文件
            UIImage *image = [UIImage imageWithContentsOfFile:path];
            
            //给imageView添加视图文件
            kkkkView.image = image;
            
            //将imageView添加到屏幕
            [_headMineView addSubview:kkkkView];
            
            kkkkView.userInteractionEnabled = YES;
            
            //为UIImageView1添加点击事件
            UITapGestureRecognizer *tapGestureRecognizer1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scanBigImageClick1:)];
            [kkkkView addGestureRecognizer:tapGestureRecognizer1];
            
        }
        
    }else
    {
        for (UIImageView *titleImage in [_headMineView subviews]) {
            if (titleImage.tag >= 2000) {
                [titleImage removeFromSuperview];
            }
        }
    }
    
    
    
    
    _detailTabelView.tableHeaderView = _headMineView;
    
    
    if ([_subjectType isEqualToString:@"Choice"]) {//单选题
        
        //移除group2时在tableviewHead上添加的选项label
        for (UILabel *label in [_headMineView subviews]) {
            if (label.tag >= 10000) {
                [label removeFromSuperview];
            }
        }
        
        TestMain *test = self.dataArray[_nowNumber - 1];
        
        _subjectArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.options];
        
        
        
        //判断数据库中是否有答案 有的话 取出来 展示在选项上
        if (test.answer != nil) {
            NSArray *answerArray = [[NSArray alloc] init];
            answerArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.answer];
            NSDictionary *answerDic = answerArray[0];
            NSString *sttting = [answerDic objectForKey:@"answerList"][0];
            _rowNUmber = sttting.integerValue - 1;
        }else
        {
            _rowNUmber = -1;
        }
        
        
    }else if ([_subjectType isEqualToString:@"MultiChoice"])//多选题
    {
        for (UILabel *label in [_headMineView subviews]) {
            if (label.tag >= 10000) {
                [label removeFromSuperview];
            }
        }
        
        TestMain *test = self.dataArray[_nowNumber - 1];
        
        _subjectArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.options];
        
        
        
        if (_duoxuanArray.count > 0) {
            [_duoxuanArray removeAllObjects];
        }
        //判断数据库中是否有答案 有的话 取出来 展示在选项上
        if (test.answer != nil) {
            NSArray *answerArray = [[NSArray alloc] init];
            
            answerArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.answer];
            NSArray *answerArr = [[NSArray alloc] init];
            answerArr = [answerArray[0] objectForKey:@"answerList"];
            
            NSString *str = answerArr[0];
            NSUInteger len = [str length];
            for(NSUInteger i=0; i<len; i++)
            {
                [_duoxuanArray addObject:[NSNumber numberWithChar:[str characterAtIndex:i] - 49]];
                
            }
            
//            NSLog(@"%@",_duoxuanArray); 
        }else
        {
            _rowNUmber = -1;
        }
        
    }else if ([_subjectType isEqualToString:@"Group1"])//公共题型 公用题干
    {
        _rowNUmber = -1;
        
        for (UILabel *label in [_headMineView subviews]) {
            if (label.tag >= 10000) {
                [label removeFromSuperview];
            }
        }
        
        NSArray *titleArray = [[NSString stringWithFormat:@"%@",[self.dataArray[_nowNumber - 1] valueForKey:@"title"]] componentsSeparatedByString:@"##"];
        
        //        _questionLabel.text = titleArray[0];
        
        NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:titleArray[0] attributes:_paraStyleDic];
        
        _questionLabel.attributedText = rightStr;
        
        TestMain *test = self.dataArray[_nowNumber - 1];
        
        _subjectArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.child_options];
        
        if (_group1MutArray.count > 0) {
            [_group1MutArray removeAllObjects];
        }
        
        //判断数据库中是否有答案 有的话 取出来 展示在选项上
        if (test.answer != nil) {
            NSArray *answerArray = [[NSArray alloc] init];
            
            answerArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.answer];
            _group1MutArray = [NSMutableArray arrayWithArray:answerArray];
            
        }else
        {
            _rowNUmber = -1;
            
            for (int i = 0; i < _subjectArray.count; i ++){
                
                NSMutableDictionary *answerAndIdDic = [[NSMutableDictionary alloc] init];
                
                [answerAndIdDic setValue:[_subjectArray[i] objectForKey:@"id"] forKey:@"questionId"];
                
                NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
                
                [yyyArray addObject:@" "];
                
                [answerAndIdDic setValue:yyyArray forKey:@"answerList"];
                
                [_group1MutArray addObject:answerAndIdDic];
                
            }
        }
    }else if ([_subjectType isEqualToString:@"Group2"])//公共题型 公用选项
    {
        _rowNUmber = -1;
        
        for (UILabel *label in [_headMineView subviews]) {
            if (label.tag >= 10000) {
                [label removeFromSuperview];
            }
        }
        
        TestMain *test = self.dataArray[_nowNumber - 1];
        //公用选项的大题的所有选项对应的数组
        _group2xuanxiangArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.options];
        //该大题下对应多少个小题所表示的数组
        _subjectArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.child_options];
        
        if (_group2MutArray.count > 0) {
            [_group2MutArray removeAllObjects];
        }
        
        //判断数据库中是否有答案 有的话 取出来 展示在选项上
        if (test.answer != nil) {
            NSArray *answerArray = [[NSArray alloc] init];
            
            answerArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.answer];
            _group2MutArray = [NSMutableArray arrayWithArray:answerArray];
            
        }else
        {
            _rowNUmber = -1;
            
            for (int i = 0; i < _subjectArray.count; i ++){
                
                NSMutableDictionary *answerAndIdDic = [[NSMutableDictionary alloc] init];
                
                [answerAndIdDic setValue:[_subjectArray[i] objectForKey:@"id"] forKey:@"questionId"];
                NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
                
                [yyyArray addObject:@" "];
                
                [answerAndIdDic setValue:yyyArray forKey:@"answerList"];
                
                [_group2MutArray addObject:answerAndIdDic];
                
            }
        }
        
        
        
        //        //清除cell中tableview展开与否的状态数组
        //        if (self.stateArray.count >0) {
        //            [self.stateArray removeAllObjects];
        //        }
        //
        //        //初始时 所有选项的展开默认为0，即不展开
        //        for (int i =0; i<_subjectArray.count; i++) {
        //            [self.stateArray addObject:@"0"];
        //        }
        
        CGSize size = [[NSString stringWithFormat:@"%ld. %@",_nowNumber,[self.dataArray[_nowNumber - 1] valueForKey:@"title"]] boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 30, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;
        
        _headMineView.frame = CGRectMake(0, 0, SCREEN_WIDTH, size.height + 40+25*_group2xuanxiangArray.count);
        
        //判断公用选项中是否含有图片
        NSArray *titleArray = [[NSString stringWithFormat:@"%@%@",self.aaArray[0],_group2xuanxiangArray[0]] componentsSeparatedByString:@"##"];
        
        
        if (titleArray.count > 1) {
            _headMineView.frame = CGRectMake(0, 0, SCREEN_WIDTH, size.height +40+115*_group2xuanxiangArray.count);
            //循环创建该题的通用选项，将其添加到tableview的headView上
            for (int i = 0; i < _group2xuanxiangArray.count; i++) {
                UILabel *xuanxiangLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(_questionLabel.frame) + (i*110), SCREEN_WIDTH - 30, 20)];
                
                xuanxiangLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
                
                xuanxiangLabel.backgroundColor = [UIColor whiteColor];
                
                NSArray *titleArray = [[NSString stringWithFormat:@"%@%@",self.aaArray[i],_group2xuanxiangArray[i]] componentsSeparatedByString:@"##"];
                
                //                xuanxiangLabel.text = titleArray[0];
                
                NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:titleArray[0][0] attributes:_paraStyleDic];
                
                xuanxiangLabel.attributedText = rightStr;
                
                xuanxiangLabel.tag = 10000+i;
                
                
                [_headMineView addSubview:xuanxiangLabel];
                
                
                for (int k = 0; k< titleArray.count-1; k++) {
                    //创建屏幕大小的imageView
                    UIImageView *kkkkView = [[UIImageView alloc] initWithFrame:CGRectMake(15+ k*110, CGRectGetMaxY(xuanxiangLabel.frame)+10, 100, 100)];
                    //
                    kkkkView.tag = 2000+k;
                    
                    //获取沙盒路径
                    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,titleArray[k+1]]];
                    
                    //打印沙盒路径
                    //                NSLog(@"%@ %@", NSHomeDirectory(),titleArray[k+1]);
                    
                    //获取路径对应的图片文件
                    UIImage *image = [UIImage imageWithContentsOfFile:path];
                    
                    //给imageView添加视图文件
                    kkkkView.image = image;
                    
                    //将imageView添加到屏幕
                    [_headMineView addSubview:kkkkView];
                }
            }
            
        }else
        {
            //循环创建该题的通用选项，将其添加到tableview的headView上
            for (int i = 0; i < _group2xuanxiangArray.count; i++) {
                UILabel *xuanxiangLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(_questionLabel.frame) + (i*25), SCREEN_WIDTH - 30, 20)];
                
                xuanxiangLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
                
                xuanxiangLabel.backgroundColor = [UIColor whiteColor];
                
                //                xuanxiangLabel.text =  [NSString stringWithFormat:@"%@%@",self.aaArray[i],_group2xuanxiangArray[i]];
                
                NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@%@",self.aaArray[i],_group2xuanxiangArray[i]] attributes:_paraStyleDic];
                
                xuanxiangLabel.attributedText = rightStr;
                
                xuanxiangLabel.tag = 10000+i;
                
                [_headMineView addSubview:xuanxiangLabel];
                
            }
        }
        
        _headMineView.backgroundColor = [UIColor whiteColor];
        
        _questionLabel.frame = CGRectMake(15, 20, SCREEN_WIDTH - 30, 100);
        
        //        _questionLabel.text = [NSString stringWithFormat:@"%@",[self.dataArray[_nowNumber - 1] valueForKey:@"title"]];
        
        NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@",[self.dataArray[_nowNumber - 1] valueForKey:@"title"]] attributes:_paraStyleDic];
        
        _questionLabel.attributedText = rightStr;
        
        _questionLabel.backgroundColor = [UIColor whiteColor];
        
        [_questionLabel sizeToFit];
        
        _detailTabelView.tableHeaderView = _headMineView;
        
    }else if ([_subjectType isEqualToString:@"Fill"])//填空题
    {
        _rowNUmber = -1;
        
        for (UILabel *label in [_headMineView subviews]) {
            if (label.tag >= 10000) {
                [label removeFromSuperview];
            }
        }
        
        _tiankonggeshu = 0;
        //循环整个填空题的题目查找出其中包含的“[]”，从而确定填空题的填空个数
        NSString * string1 = [NSString stringWithFormat:@"%@. %@",[self.dataArray[_nowNumber - 1] valueForKey:@"questionNum"],[self.dataArray[_nowNumber - 1] valueForKey:@"title"]];;
        NSString * string2 = @"[]";
        
        NSString * replaceString =string1;
        replaceString=[replaceString stringByReplacingOccurrencesOfString:@"[]"withString:@"___"];
        
        //        _questionLabel.text = replaceString;
        
        NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:replaceString attributes:_paraStyleDic];
        
        _questionLabel.attributedText = rightStr;
        
        for (int i = 0; i < string1.length - string2.length + 1; i++) {
            
            if ([[string1 substringWithRange:NSMakeRange(i, string2.length)] isEqualToString:string2]) {
                
                _tiankonggeshu++;
            }
        }
        
//        NSLog(@"%lu",(unsigned long)_tiankonggeshu);
        
        
        TestMain *test = self.dataArray[_nowNumber - 1];
        
        
        
        if (self.tiankongMutArray.count > 0) {
            [self.tiankongMutArray removeAllObjects];
        }
        for (int i =0; i<_tiankonggeshu; i++) {
            [self.tiankongMutArray addObject:@" "];
        }
        
        //判断数据库中是否有答案 有的话 取出来 展示在选项上
        if (test.answer != nil) {
            NSArray *answerArray = [[NSArray alloc] init];
            
            answerArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.answer];
            self.tiankongMutArray = [answerArray[0] objectForKey:@"answerList"];
//            NSLog(@"%@",_tiankongMutArray);
        }
        
    }else if ([_subjectType isEqualToString:@"Essay"])//简答题
    {
        _rowNUmber = -1;
        
        for (UILabel *label in [_headMineView subviews]) {
            if (label.tag >= 10000) {
                [label removeFromSuperview];
            }
        }
        
        TestMain *test = self.dataArray[_nowNumber - 1];
        
        _subjectArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.options];
        
        
        
        //判断数据库中是否有答案 有的话 取出来 展示在选项上
        if (test.answer != nil) {
            NSArray *answerArray = [[NSArray alloc] init];
            
            answerArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.answer];
            NSDictionary *answerDic = answerArray[0];
            _wendaString = [answerDic objectForKey:@"answerList"][0];
        }else
        {
            _wendaString = nil;
        }
        
    }else if ([_subjectType isEqualToString:@"Judge"])//判断题
    {
        _rowNUmber = -1;
        
        for (UILabel *label in [_headMineView subviews]) {
            if (label.tag >= 10000) {
                [label removeFromSuperview];
            }
        }
        _subjectArray = [NSArray arrayWithObjects:@"正确",@"错误", nil];
        
        TestMain *test = self.dataArray[_nowNumber - 1];
        
        
        
        //判断数据库中是否有答案 有的话 取出来 展示在选项上
        if (test.answer != nil) {
            NSArray *answerArray = [[NSArray alloc] init];
            
            answerArray = [NSKeyedUnarchiver unarchiveObjectWithData:test.answer];
            NSDictionary *answerDic = answerArray[0];
            NSString *sttting = [answerDic objectForKey:@"answerList"][0];
            
            if ([sttting isEqualToString:@"true"]) {
                _rowNUmber = 0;
            }else
            {
                _rowNUmber = 1;
            }
        }else
        {
            _rowNUmber = -1;
        }
        
    }else
    {
        for (UILabel *label in [_headMineView subviews]) {
            if (label.tag >= 10000) {
                [label removeFromSuperview];
            }
        }
        
    }
    
    [self.detailTabelView setContentOffset:CGPointMake(0,0) animated:NO];
    
    [_detailTabelView reloadData];
    
}


#pragma mark 点击上一题
-(void)touchShangyiti:(UIButton *)button
{
    _isCollectionViewCome = 0;
    if (_nowNumber == 1) {
        [MBProgressHUD showAutoMessage:@"当前是第一题"];
    }else
    {
        //当前的题数
        _nowNumber = _nowNumber - 1;
        
        [self changeSubjectsDatas];
        
    }
    
}

#pragma mark 点击下一题
-(void)touchXiayiti
{
    
    _isCollectionViewCome = 0;
    if (_nowNumber == _dataArray.count) {
        [MBProgressHUD showAutoMessage:@"当前最后一题"];
    }else
    {
        //当前的题数
        _nowNumber = _nowNumber + 1;
        
        [self changeSubjectsDatas];
    }
}

#pragma mark 右滑手势触发事件
-(void)rightSwipe:(UISwipeGestureRecognizer *)sender
{
    _isCollectionViewCome = 0;
    if (_nowNumber == 1) {
        [MBProgressHUD showAutoMessage:@"当前是第一题"];
    }else
    {
        //当前的题数
        _nowNumber = _nowNumber - 1;
        [self changeSubjectsDatas];
    }
    
}

#pragma mark 左滑手势触发事件
-(void)leftSwipe:(UISwipeGestureRecognizer *)sender
{
    _isCollectionViewCome = 0;
    if (_nowNumber == _dataArray.count) {
        [MBProgressHUD showAutoMessage:@"当前最后一题"];
    }else
    {
        //当前的题数
        _nowNumber = _nowNumber + 1;
        [self changeSubjectsDatas];
    }
}



//#pragma mark collectionView

//返回每个分区的item个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    if (collectionView == self.subjectLists) {
        return  _homeworkTotalNumber;
    }else if (collectionView == self.weidatiCollection){
        
        return _weidatiMutArr.count;
    }else
    {
        return 10;
    }
}
//返回每个item
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if (collectionView == self.subjectLists) {
        UICollectionViewCell * cell  = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellid" forIndexPath:indexPath];
        UILabel *flagLabel = [[UILabel alloc] initWithFrame:CGRectMake(7, 7, SCREEN_WIDTH/6 -14 , SCREEN_WIDTH/6 -14)];
        //是否答题，答题为蓝色，未答为灰色
        
        if ([[_questionsMutArray[indexPath.row] objectForKey:@"isAnswer"] isEqualToString:@"1"]) {
            
            flagLabel.backgroundColor = [UIColor colorWithRed:0.34 green:0.65 blue:0.87 alpha:1];
            
        }else
        {
            flagLabel.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
        }
        
        flagLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row + 1];
        flagLabel.textAlignment = NSTextAlignmentCenter;
        flagLabel.textColor = [UIColor whiteColor];
        flagLabel.layer.cornerRadius = 5.0;
        flagLabel.layer.masksToBounds = YES;
        [cell addSubview:flagLabel];
        cell.backgroundColor = [UIColor whiteColor];
        return cell;
        
    }else if (collectionView == self.weidatiCollection){
        UICollectionViewCell * cell  = [collectionView dequeueReusableCellWithReuseIdentifier:@"weidaticellid" forIndexPath:indexPath];
        cell.backgroundColor = [UIColor whiteColor];
        UILabel *flagLabel = [[UILabel alloc] initWithFrame:CGRectMake(7, 7, SCREEN_WIDTH/6 -14 , SCREEN_WIDTH/6 -14)];
        flagLabel.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
        flagLabel.text = [_weidatiMutArr[indexPath.row] objectForKey:@"notAnswerNumber"];
        flagLabel.textAlignment = NSTextAlignmentCenter;
        flagLabel.textColor = [UIColor whiteColor];
        flagLabel.layer.cornerRadius = 5.0;
        flagLabel.layer.masksToBounds = YES;
        [cell addSubview:flagLabel];
        return cell;
    }else
    {
        return nil;
    }
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
//    NSLog(@"%ld",(long)indexPath.row);
    
    if (collectionView == self.subjectLists) {
        [self.detailTabelView setContentOffset:CGPointMake(0,0) animated:NO];
        _nowNumber = [[_questionsMutArray[indexPath.item] objectForKey:@"kylocation"] integerValue]-1;
        
        _detailTabelView.hidden = NO;
        self.collectBackgroundView.hidden = YES;
        
        _isCollectionViewCome = indexPath.row + 1;
        //当前的题数
        _nowNumber = _nowNumber + 1;
        [self changeSubjectsDatas];
        
        if ([_subjectType isEqualToString:@"Group1"] || [_subjectType isEqualToString:@"Group2"])
        {
            NSInteger presentTitleNumber = [[self.dataArray[_nowNumber - 1] valueForKey:@"questionNum"] integerValue];
            
            NSInteger rollNumber = indexPath.row + 1 - presentTitleNumber;
            //            NSLog(@"%d位置哈哈哈%dpppppp%d",_nowNumber,indexPath.row,rollNumber);
            NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:rollNumber inSection:0];
            
            [self.detailTabelView scrollToRowAtIndexPath:scrollIndexPath
                                        atScrollPosition:UITableViewScrollPositionTop animated:NO];
        }else
        {
            [self.detailTabelView setContentOffset:CGPointMake(0,0) animated:NO];
        }
        
    }else if (collectionView == self.weidatiCollection){
        [self.detailTabelView setContentOffset:CGPointMake(0,0) animated:NO];
        _nowNumber =  [[_weidatiMutArr[indexPath.row] objectForKey:@"kylocation"] intValue] - 1;
        _detailTabelView.hidden = NO;
        self.weidatiView.hidden = YES;
        
        _isCollectionViewCome = indexPath.row + 1;
        //当前的题数
        _nowNumber = _nowNumber + 1;
        [self changeSubjectsDatas];
        
        if ([_subjectType isEqualToString:@"Group1"] || [_subjectType isEqualToString:@"Group2"])
        {
            NSInteger presentTitleNumber = [[self.dataArray[_nowNumber - 1] valueForKey:@"questionNum"] integerValue];
            
            NSInteger rollNumber = indexPath.row + 1 - presentTitleNumber;
            //            NSLog(@"%d位置哈哈哈%dpppppp%d",_nowNumber,indexPath.row,rollNumber);
            NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:rollNumber inSection:0];
            
            [self.detailTabelView scrollToRowAtIndexPath:scrollIndexPath
                                        atScrollPosition:UITableViewScrollPositionTop animated:NO];
        }else
        {
            [self.detailTabelView setContentOffset:CGPointMake(0,0) animated:NO];
        }
    }else
    {
        return;
    }
    
    
    
    
}



#pragma mark 点击右边导航按钮
-(void)touchRightButton:(UIButton *)rightButton
{
    //    rightButton.selected =! rightButton.selected;
    //
    //    if (rightButton.selected) {
    _detailTabelView.hidden = YES;
    self.collectBackgroundView.hidden = NO;
    
    //    }else
    //    {
    //        _detailTabelView.hidden = NO;
    //        self.collectBackgroundView.hidden = YES;
    //    }
    
    [self isAnwseredState];
    
    [self.subjectLists reloadData];
    
    _backNumber = 0;
    
    
}

#pragma mark 点击未答题
-(void)touchWeidati:(UIButton *)button
{
    _whiteView.hidden = YES;
    _detailTabelView.hidden = YES;
    self.weidatiView.hidden = NO;
    [self isAnwseredState];
    [self.weidatiCollection reloadData];
}

#pragma mark 点击未答题页面上的保存按钮
-(void)touchSaveButton
{
    _detailTabelView.hidden = NO;
    self.weidatiView.hidden = YES;
    //    [self submitALLAnswers];
}

#pragma mark 点击未答题页面上的提交作业按钮
-(void)touchSubmitSubjectButton
{
    _detailTabelView.hidden = NO;
    self.weidatiView.hidden = YES;
    [self submitALLAnswers];
}




//点击图片后的方法(即图片的放大全屏效果)
- (void) tapAction{
    //创建一个黑色背景
    //初始化一个用来当做背景的View。我这里为了省时间计算，宽高直接用的5s的尺寸
    UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    background = bgView;
    [bgView setBackgroundColor:[UIColor blackColor]];
    [self.view addSubview:bgView];
    
    //创建显示图像的视图
    //初始化要显示的图片内容的imageView（这里位置继续偷懒...没有计算）
    
    
    //创建屏幕大小的imageView
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 80, SCREEN_WIDTH, SCREEN_HEIGHT - 100 -80)];
    
    
    //获取沙盒路径
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,_allTitleArray[1]]];
    
    //获取路径对应的图片文件
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    
    //给imageView添加视图文件
    imageView.image = image;
    
    //将imageView添加到屏幕
    [bgView addSubview:imageView];
    
    
    
    //    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 100, SCREEN_WIDTH, SCREEN_HEIGHT)];
    //    //要显示的图片，即要放大的图片
    //    [imgView setImage:[UIImage imageNamed:@"dog"]];
    //    [bgView addSubview:imgView];
    
    imageView.userInteractionEnabled = YES;
    //添加点击手势（即点击图片后退出全屏）
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(closeView)];
    [imageView addGestureRecognizer:tapGesture];
    
    [self shakeToShow:bgView];//放大过程中的动画
}
-(void)closeView{
    [background removeFromSuperview];
}
//放大过程中出现的缓慢动画
- (void) shakeToShow:(UIView*)aView{
    CAKeyframeAnimation* animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    animation.duration = 0.5;
    NSMutableArray *values = [NSMutableArray array];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    animation.values = values;
    [aView.layer addAnimation:animation forKey:nil];
}

//textField代理  填空题填写答案后回调
-(void)textFieldDidEndEditing:(UITextField *)textField
{
//    NSLog(@"%@%ld",textField.text,(long)textField.tag);
    
    [self.tiankongMutArray replaceObjectAtIndex:textField.tag-888 withObject:textField.text];
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
    NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
    
    request.predicate = [NSPredicate predicateWithFormat:searchId];
    NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
    for (TestMain *title in array)
    {
        if ([title.title_id isEqualToString:_subjectTitleID])
        {
            //将用户选择的答案与题目id对应产生dictionary，然后将dictionary存入数组，再将数组存入数据库中answer字段中
            NSMutableDictionary *huaDic = [[NSMutableDictionary alloc] init];
            
            [huaDic setValue:_subjectTitleID forKey:@"questionId"];
            
            [huaDic setValue:_tiankongMutArray forKey:@"answerList"];
            
            NSMutableArray *huaArray = [[NSMutableArray alloc] init];
            
            [huaArray addObject:huaDic];
            
            if (huaArray.count > 0) {
                NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:huaArray];
                title.answer = childOptions;
                title.iscompleted = @"1";
                
            }
            
            NSError *error = nil;
            if (![self.managedObjectContext save:&error])
            {
                NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                abort();
            }
        }
    }
    
}

#pragma mark 问答题从cell中回传所答答案
//存储问答题的答案
-(void)getWendaAnswer:(NSString *)kAddressString
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
    NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
    
    request.predicate = [NSPredicate predicateWithFormat:searchId];
    NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
    for (TestMain *title in array)
    {
        if ([title.title_id isEqualToString:_subjectTitleID])
        {
            NSMutableDictionary *ffDic =[[NSMutableDictionary alloc] init];
            
            [ffDic setValue:_subjectTitleID forKey:@"questionId"];
            
            NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
            
            [yyyArray addObject:kAddressString];
            
            [ffDic setValue:yyyArray forKey:@"answerList"];
            
            NSMutableArray *huaArray = [[NSMutableArray alloc] init];
            
            [huaArray addObject:ffDic];
            
            if (huaArray.count > 0) {
                NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:huaArray];
                title.answer = childOptions;
                title.iscompleted = @"1";
            }
            
            NSError *error = nil;
            
            if (![self.managedObjectContext save:&error])
            {
                NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                abort();
            }
        }
    }
}


#pragma mark group1代理返回选中选项
-(void)getGroup1Answer:(int)kChoiceCell andchoice:(NSInteger)kChoiceRow andChildSubjectID:(NSString *)childSubjectID
{
    int i = (int)kChoiceRow + 1;
    
    for (int y = 0; y < _group1MutArray.count; y++) {
        NSString *questionID = [_group1MutArray[y] objectForKey:@"questionId"];
        if ([questionID isEqualToString:childSubjectID]) {
            
            NSMutableArray *answerListMut = [_group1MutArray[y] objectForKey:@"answerList"];
            
            [answerListMut replaceObjectAtIndex:0 withObject:[NSString stringWithFormat:@"%d",i]];
            
            [_group1MutArray[y] setObject:answerListMut forKey:@"answerList"];
            
            break;
        }
    }
    
    NSString *completeString;
    for (int x = 0; x < _group1MutArray.count; x++) {
        
//        NSDictionary *answeridquestionid = _group1MutArray[x];
        
        NSArray *answerListArr = [_group1MutArray[x] objectForKey:@"answerList"];
        
        NSString *answerK = answerListArr[0];
        
        //        NSLog(@"%@",answerK);
        
        if (![answerK isEqualToString:@" "]) {
            //            NSLog(@"当前答案有答案");
            if (x == 0) {
                completeString = @"1";
            }else
            {
                completeString = [NSString stringWithFormat:@"%@,1",completeString];
            }
            
        }else
        {
            if (x == 0) {
                completeString = @"0";
            }else
            {
                completeString = [NSString stringWithFormat:@"%@,0",completeString];
            }
        }
    }
    
//    NSLog(@"%@",completeString);
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
    
    NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
    
    request.predicate = [NSPredicate predicateWithFormat:searchId];
    NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
    for (TestMain *title in array)
    {
        if ([title.title_id isEqualToString:_subjectTitleID])
        {
            //group1存储答案 只需要小题id+答案的对应关系，不需要大题的id。
            
            if (_group1MutArray.count > 0) {
                NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:_group1MutArray];
                title.answer = childOptions;
                title.iscompleted = completeString;
            }
            
            
            
            NSError *error = nil;
            if (![self.managedObjectContext save:&error])
            {
                NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                abort();
            }
        }
    }
}


#pragma mark group2选中答案后回传到
-(void)getGroup2Answer:(int)kChoiceCell andchoice:(NSInteger)kChoiceRow andchildSubjectID:(NSString *)childSubjectID
{
    int i = (int)kChoiceRow + 1;
    
    //    [self.stateArray replaceObjectAtIndex:kChoiceCell withObject:@"0"];
    
    [self.detailTabelView reloadData];
    
    //把_group2MutArray的数据格式进行更改之后，这里需要进行变动，替换指定小题id的答案，需要根据小题的id进行替换。
    for (int y = 0; y < _group2MutArray.count; y++) {
        NSString *questionID = [_group2MutArray[y] objectForKey:@"questionId"];
        if ([questionID isEqualToString:childSubjectID]) {
            
            NSMutableArray *answerListMut = [_group2MutArray[y] objectForKey:@"answerList"];
            
            [answerListMut replaceObjectAtIndex:0 withObject:[NSString stringWithFormat:@"%d",i]];
            
            [_group2MutArray[y] setObject:answerListMut forKey:@"answerList"];
            
//            NSLog(@"%@",_group2MutArray);
            
            break;
        }
    }
    
    //    NSInteger isCompleteNumber = 0;
    //    for (int x = 0; x < _group2MutArray.count; x++) {
    //
    //        NSDictionary *answeridquestionid = _group2MutArray[x];
    //
    //        NSArray *answerListArr = [_group2MutArray[x] objectForKey:@"answerList"];
    //
    //        NSString *answerK = answerListArr[0];
    //
    //        //        NSLog(@"%@",answerK);
    //
    //        if (![answerK isEqualToString:@" "]) {
    //            //            NSLog(@"当前答案有答案");
    //            isCompleteNumber++;
    //        }
    //    }
    
    
    NSString *completeString;
    for (int x = 0; x < _group2MutArray.count; x++) {
        
//        NSDictionary *answeridquestionid = _group2MutArray[x];
        
        NSArray *answerListArr = [_group2MutArray[x] objectForKey:@"answerList"];
        
        NSString *answerK = answerListArr[0];
        
        if (![answerK isEqualToString:@" "]) {
            //            NSLog(@"当前答案有答案");
            if (x == 0) {
                completeString = @"1";
            }else
            {
                completeString = [NSString stringWithFormat:@"%@,1",completeString];
            }
            
        }else
        {
            if (x == 0) {
                completeString = @"0";
            }else
            {
                completeString = [NSString stringWithFormat:@"%@,0",completeString];
            }
        }
    }
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
    NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
    
    request.predicate = [NSPredicate predicateWithFormat:searchId];
    NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
    for (TestMain *title in array)
    {
        if ([title.title_id isEqualToString:_subjectTitleID])
        {
            //group2存储答案 只需要小题id+答案的对应关系，不需要大题的id。
            if (_group2MutArray.count > 0) {
                NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:_group2MutArray];
                title.answer = childOptions;
                title.iscompleted = completeString;
            }
            
            NSError *error = nil;
            if (![self.managedObjectContext save:&error])
            {
                NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                abort();
            }
        }
    }
}


-(void)refreshUIDay:(NSInteger)day hour:(NSInteger)hour minute:(NSInteger)minute second:(NSInteger)second{
    
    _countdownHour = hour;
    _countdownMintue = minute;
    _countdownSencond = second;
    
    
    //倒计时间一到自动交卷
    if (day == 0 && hour == 0 && minute == 0 && second == 0) {
        if (_isDelaySubmit == 0) {
            [self submitALLAnswers];
        }
    }
    
    if (day==0) {
        //        self.dayLabel.text = @"0天";
    }else{
        //        self.dayLabel.text = [NSString stringWithFormat:@"%ld天",(long)day];
    }
    if (hour<10) {
        self.detailTimeLabel.text = [NSString stringWithFormat:@"0%ld:",(long)hour];
    }else{
        self.detailTimeLabel.text = [NSString stringWithFormat:@"%ld:",(long)hour];
    }
    if (minute<10) {
        self.detailMinuteLabel.text = [NSString stringWithFormat:@"0%ld:",(long)minute];
    }else{
        self.detailMinuteLabel.text = [NSString stringWithFormat:@"%ld:",(long)minute];
    }
    if (second<10) {
        self.detailSecondLabel.text = [NSString stringWithFormat:@"0%ld",(long)second];
    }else{
        self.detailSecondLabel.text = [NSString stringWithFormat:@"%ld",(long)second];
    }
}

-(void)dealloc{
}

#pragma mark - 浏览大图点击事件
-(void)scanBigImageClick1:(UITapGestureRecognizer *)tap{
//    NSLog(@"点击图片");
    UIImageView *clickedImageView = (UIImageView *)tap.view;
    [XWScanImage scanBigImageWithImageView:clickedImageView];
}

#pragma mark 单选点击选项上的按钮
-(void)touchSelectButton:(UIButton *)button
{
    _rowNUmber = button.tag;
    
    [_detailTabelView reloadData];
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
    NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
    
    request.predicate = [NSPredicate predicateWithFormat:searchId];
    NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
    for (TestMain *title in array)
    {
        if ([title.title_id isEqualToString:_subjectTitleID])
        {
            //将用户选择的答案与题目id对应产生dictionary，然后将dictionary存入数组，再将数组存入数据库中answer字段中
            NSArray *chioceArray = [NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11", nil];
            
            NSMutableDictionary *huaDic = [[NSMutableDictionary alloc] init];
            
            [huaDic setValue:_subjectTitleID forKey:@"questionId"];
            
            
            NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
            
            [yyyArray addObject:chioceArray[button.tag]];
            
            [huaDic setValue:yyyArray forKey:@"answerList"];
            
            NSMutableArray *huaArray = [[NSMutableArray alloc] init];
            
            [huaArray addObject:huaDic];
            
            if (huaArray.count > 0) {
                NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:huaArray];
                title.answer = childOptions;
                title.iscompleted = @"1";
                
            }
            
            // Save the context.
            NSError *error = nil;
            if (![self.managedObjectContext save:&error])
            {
                NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                abort();
            }
        }
    }
}


#pragma mark 多选点击选项上的按钮
-(void)touchSelectMultiChoiceButton:(UIButton *)button
{
    if (button.selected) {
        button.selected = NO;
        [_duoxuanArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            
            if ([[NSString stringWithFormat:@"%@",obj] isEqualToString:[NSString stringWithFormat:@"%ld",(long)button.tag]]) {
                
                [_duoxuanArray removeObject:obj];
            }
        }];
    }else
    {
        button.selected = YES;
        [_duoxuanArray addObject:[NSString stringWithFormat:@"%ld",(long)button.tag]];
    }
    
    NSArray *newArray = [_duoxuanArray sortedArrayUsingSelector:@selector(compare:)];
    
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
    NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
    
    request.predicate = [NSPredicate predicateWithFormat:searchId];
    NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
    for (TestMain *title in array)
    {
        if ([title.title_id isEqualToString:_subjectTitleID])
        {
            
            NSArray *chioceArray = [NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11", nil];
            
            NSString *totalString;
            
            for (NSString *numberSTR in newArray) {
                NSInteger number = numberSTR.integerValue;
                
                if (totalString == nil) {
                    totalString = chioceArray[number];
                }else
                {
                    totalString = [NSString stringWithFormat:@"%@%@",totalString,chioceArray[number]];
                }
            }
            
            NSMutableDictionary *huaDic = [[NSMutableDictionary alloc] init];
            
            [huaDic setValue:_subjectTitleID forKey:@"questionId"];
            
            NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
            
//            NSLog(@"%@",totalString);
            
            //加入多选之后答案选项是否为空，解决totalString为空还添加数组导致崩溃的情况
            if (totalString == nil) {
                
            }else
            {
                [yyyArray addObject:totalString];
                
            }
            
            [huaDic setValue:yyyArray forKey:@"answerList"];
            
            NSMutableArray *huaArray = [[NSMutableArray alloc] init];
            
            [huaArray addObject:huaDic];
            
            if (huaArray.count > 0) {
                NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:huaArray];
                title.answer = childOptions;
                title.iscompleted = @"1";
            }
            //                 Save the context.
            NSError *error = nil;
            
            if (![self.managedObjectContext save:&error])
            {
                NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                abort();
            }
        }
    }
    
}

#pragma mark 判断点击选项上的按钮
-(void)touchSelectJudgeButton:(UIButton *)button
{
    _rowNUmber = button.tag;
    
    [_detailTabelView reloadData];
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
    NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",_userId,self.detailID];
    
    request.predicate = [NSPredicate predicateWithFormat:searchId];
    NSArray *array = [self.managedObjectContext executeFetchRequest:request error:nil];
    for (TestMain *title in array)
    {
        if ([title.title_id isEqualToString:_subjectTitleID])
        {
            //将用户选择的答案与题目id对应产生dictionary，然后将dictionary存入数组，再将数组存入数据库中answer字段中
            
            
            NSMutableDictionary *huaDic = [[NSMutableDictionary alloc] init];
            
            if (button.tag == 0) {//正确
                
                [huaDic setValue:_subjectTitleID forKey:@"questionId"];
                
                NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
                
                [yyyArray addObject:@"true"];
                
                [huaDic setValue:yyyArray forKey:@"answerList"];
                
            }else//错误
            {
                
                [huaDic setValue:_subjectTitleID forKey:@"questionId"];
                
                NSMutableArray *yyyArray = [[NSMutableArray alloc] init];
                
                [yyyArray addObject:@"false"];
                
                [huaDic setValue:yyyArray forKey:@"answerList"];
                
            }
            
            NSMutableArray *huaArray = [[NSMutableArray alloc] init];
            
            [huaArray addObject:huaDic];
            
            if (huaArray.count > 0) {
                NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:huaArray];
                title.answer = childOptions;
                title.iscompleted = @"1";
                
            }
            
            // Save the context.
            NSError *error = nil;
            if (![self.managedObjectContext save:&error])
            {
                NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                abort();
            }
        }
    }
    
}

-(BOOL)unZipStatus
{
    //coreData查询语句，查询出当前试题id对应的所有数据
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TestMain"];
    NSString *searchId = [NSString stringWithFormat:@"userid='%@'AND test_id='%@'",self.userId,self.detailID];
    request.predicate = [NSPredicate predicateWithFormat:searchId];
    
    //获取当前数据库所在目录文件路径
    //    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    //    NSString *savePath = [paths objectAtIndex:0];
    
    self.dataArray = [self.managedObjectContext executeFetchRequest:request error:nil];
    
    if (self.dataArray.count > 0)
    {
//        NSLog(@"数据库里已有数据不处理");
        return YES;
    }
    else
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *savePath = [paths objectAtIndex:0];
        
        NSString *fullPath = [NSString stringWithFormat:@"%@",self.pathOfZipFile];
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        BOOL isExist = [fileManager fileExistsAtPath:fullPath];
        __block BOOL _isSuccess;
        if (isExist == YES)
        {
            [MBProgressHUD showLoadToView:self.view];
            [SSZipArchive unzipFileAtPath:fullPath toDestination:savePath progressHandler:^(NSString * _Nonnull entry, unz_file_info zipInfo, long entryNumber, long total)
            {
                if ([entry rangeOfString:@".json"].location != NSNotFound)
                {
                    NSArray *array = [entry componentsSeparatedByString:@"/"];
                    self.unZipFileName = array[0];
                    self.paperName = array[1];
                }
            } completionHandler:^(NSString * _Nonnull path, BOOL succeeded, NSError * _Nonnull error) {
                if (succeeded == YES)
                {
                    //删除
                    //[fileManager removeItemAtPath:fullPath error:&error];
                    //移动
                    //[fileManager moveItemAtPath:fullPath toPath:savePath error:&error];
                    NSString *jsonFilePath = [NSString stringWithFormat:@"%@/%@/%@",savePath,self.unZipFileName,self.paperName];
                    //判断json文件是否存在
                    BOOL isJsonExist = [fileManager fileExistsAtPath:jsonFilePath];
                    if (isJsonExist == YES)
                    {
                        //根据文件路径读取数据
                        NSData *jdata = [[NSData alloc] initWithContentsOfFile:jsonFilePath];
                        //格式化成json数据
                        id jsonObject = [NSJSONSerialization JSONObjectWithData:jdata options:kNilOptions error:&error];
                        //NSLog(@"%@",jsonObject);
                        NSArray *dataArray = [jsonObject valueForKey:@"data"];
                        if (dataArray.count == 0) {
                            _isSuccess = NO;
                            [MBProgressHUD hideHUDForView:self.view animated:YES];
                            [MBProgressHUD showMessage:@"暂无试题" ToView:self.view RemainTime:1.5];
                        }
                        else
                        {
                            //"txsm": "A1:选择题,A2:选择题,A3:组合题(公用题干),A4:组合题(公用题干),X:多选题,K:选择题,B:组合题(公用选项)",
                            for (int i = 0; i < dataArray.count; i++)
                            {
                                TestMain *fatherTable = [NSEntityDescription insertNewObjectForEntityForName:@"TestMain" inManagedObjectContext:self.managedObjectContext];
                                
                                fatherTable.title_id = [dataArray[i] valueForKey:@"id"];
                                fatherTable.title = [dataArray[i] valueForKey:@"name"];
                                fatherTable.test_id = _detailID;
                                fatherTable.test_name = _unZipFileName;
                                fatherTable.type = [dataArray[i] valueForKey:@"type"];
                                fatherTable.questionModelName = [dataArray[i] valueForKey:@"questionModelName"];
                                fatherTable.fileName = self.unZipFileName;
                                fatherTable.questionNum = [[dataArray[i] valueForKey:@"questionNum"] stringValue];
                                fatherTable.location = [[dataArray[i] valueForKey:@"location"] stringValue];
                                fatherTable.userid = self.userId;
                                
                                if ([fatherTable.questionModelName isEqualToString:@"A3"] ||
                                    [fatherTable.questionModelName isEqualToString:@"A4"])
                                {
                                    NSArray *childDataArr = [dataArray[i] valueForKey:@"questionList"];
                                    if (childDataArr.count > 0) {
                                        NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:childDataArr];
                                        fatherTable.child_options = childOptions;
                                        
                                        NSString *group1String;
                                        for (int f = 0; f < childDataArr.count; f++) {
                                            if (f==0) {
                                                group1String = @"0";
                                            }else
                                            {
                                                group1String = [NSString stringWithFormat:@"%@,0",group1String];
                                            }
                                        }
                                        fatherTable.iscompleted = group1String;
                                    }
                                }
                                else if ([fatherTable.questionModelName isEqualToString:@"B"])
                                {
                                    NSArray *childDataArr = [dataArray[i] valueForKey:@"questionList"];
                                    if (childDataArr.count > 0) {
                                        NSData *childOptions = [NSKeyedArchiver archivedDataWithRootObject:childDataArr];
                                        fatherTable.child_options = childOptions;
                                    }
                                    NSArray *optionsArr = [dataArray[i] valueForKey:@"choiceList"];
                                    if (optionsArr.count > 0) {
                                        NSData *fatherOptions = [NSKeyedArchiver archivedDataWithRootObject:optionsArr];
                                        fatherTable.options = fatherOptions;
                                    }
                                    
                                    NSString *group1String = [[NSString alloc] init];
                                    for (int f = 0; f < childDataArr.count; f++) {
                                        if (f==0) {
                                            group1String = @"0";
                                        }else
                                        {
                                            group1String = [NSString stringWithFormat:@"%@,0",group1String];
                                        }
                                    }
                                    
                                    fatherTable.iscompleted = group1String;
                                    
                                }
                                else
                                {
                                    //用这个值标示本题是否存在答案，特别是组合题，只有组合题的所有小题都答完之后才将父题的这个值变为1
                                    fatherTable.iscompleted = @"0";
                                    NSArray *optionsArr = [dataArray[i] valueForKey:@"choiceList"];
                                    if (optionsArr.count > 0) {
                                        NSData *fatherOptions = [NSKeyedArchiver archivedDataWithRootObject:optionsArr];
                                        fatherTable.options = fatherOptions;
                                    }
                                }
                                // Save the context.
                                NSError *error = nil;
                                if (![self.managedObjectContext save:&error])
                                {
                                    // Replace this implementation with code to handle the error appropriately.
                                    // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                                    NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                                    abort();
                                }
                            }
                            _isSuccess = YES;
                            [MBProgressHUD hideHUDForView:self.view];
                        }
                    }
                    else
                    {
                        _isSuccess = NO;
                        [MBProgressHUD hideHUDForView:self.view];
                        [MBProgressHUD showMessage:@"找不到文件" ToView:self.view RemainTime:1.0];
                    }
                }
            }];
            return _isSuccess;
        }
        else
        {
            [MBProgressHUD hideHUDForView:self.view];
            [MBProgressHUD showMessage:@"解压失败" ToView:self.view RemainTime:1.0];
            return NO;
        }
    }
}


@end
