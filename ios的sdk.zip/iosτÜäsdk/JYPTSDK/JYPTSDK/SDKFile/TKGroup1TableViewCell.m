//
//  TKGroup1TableViewCell.m
//  TikuApp
//
//  Created by huangkeyuan on 16/8/16.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKGroup1TableViewCell.h"
#import "TKDetailBaseCell.h"
#import "UITableView+FDTemplateLayoutCell.h"
#import "TestMain.h"
#import "XWScanImage.h"

@implementation TKGroup1TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _rowNUmber = -1;
        _cellInfoTableView = [[UITableView alloc] initWithFrame:CGRectZero];
        _cellInfoTableView.backgroundColor  =[UIColor whiteColor];
        _cellInfoTableView.tag = 431;
        _cellInfoTableView.delegate = self;
        _cellInfoTableView.dataSource = self;
        [self addSubview:_cellInfoTableView];
        [_cellInfoTableView registerNib:[UINib nibWithNibName:@"TKDetailBaseCell" bundle:nil] forCellReuseIdentifier:@"newDetailCell"];
        
        _cellInfoTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return self;
}


-(void)layoutSubviews
{
    [super layoutSubviews];
    NSLog(@"%@",_cellInfoArray);
    
    _cellInfoTableView = (UITableView *)[self viewWithTag:431];
    
    _cellInfoTableView.frame = CGRectMake(0, 0, SCREEN_WIDTH, _heightCellNumber);
    self.aaArray = [NSArray arrayWithObjects:@"A.",@"B.",@"C.",@"D.",@"E.",@"F.",@"G.",@"H.",@"I.",@"J.",@"K.", nil];
    
    
    NSArray *titleArray = [[NSString stringWithFormat:@"%d. %@",_cellInfoNumber+_littleCellNumber,[_cellInfoDiction valueForKey:@"name"]] componentsSeparatedByString:@"##"];
    
    //计算试题题目的标题所占的高度
    CGSize size = [titleArray[0] boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 30, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} context:nil].size;
    
    NSLog(@"size.height%f",size.height);
    
    UIView  *headMineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, size.height)];
    
    if (titleArray.count > 1) {
        headMineView.frame = CGRectMake(0, 0, SCREEN_WIDTH, size.height +110);
    }
    
    headMineView.backgroundColor = [UIColor whiteColor];
    _cellInfoTableView.tableHeaderView = headMineView;
    
#pragma mark 字符间距
    //设置文本格式
    NSMutableParagraphStyle *paraStyle = [[NSMutableParagraphStyle alloc] init];
    paraStyle.lineBreakMode = NSLineBreakByCharWrapping;
    paraStyle.alignment = NSTextAlignmentLeft;
    paraStyle.lineSpacing = 10; //设置行间距
    paraStyle.hyphenationFactor = 0.0;//连字属性 在iOS，唯一支持的值分别为0和1
    paraStyle.firstLineHeadIndent = 0.0;//首行缩进
    paraStyle.paragraphSpacingBefore = 0.0;//段首行空白空间
    paraStyle.headIndent = 0;//整体缩进(首行除外)
    paraStyle.tailIndent = 0;
    //可以增加设置字间距 NSKernAttributeName:@1.5f
    _paraStyleDic = @{NSFontAttributeName:[UIFont systemFontOfSize:15], NSParagraphStyleAttributeName:paraStyle
                      };
    
    UILabel *questionLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, SCREEN_WIDTH - 30, 100)];
    questionLabel.backgroundColor = [UIColor whiteColor];
    questionLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
    questionLabel.numberOfLines = 0;
//    questionLabel.text = titleArray[0];
    NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:titleArray[0] attributes:_paraStyleDic];
    questionLabel.attributedText = rightStr;
    //让内容置顶
    [questionLabel sizeToFit];
    
    [headMineView addSubview:questionLabel];
    
    if (titleArray.count > 1) {
        
        for (UIImageView *titleImage in [headMineView subviews]) {
            if (titleImage.tag >= 2000) {
                [titleImage removeFromSuperview];
            }
        }
        
        for (int k = 0; k< titleArray.count-1; k++) {
            //创建屏幕大小的imageView
            UIImageView *kkkkView = [[UIImageView alloc] initWithFrame:CGRectMake(60+ k*90, CGRectGetMaxY(questionLabel.frame)+10, 80, 80)];
            
            kkkkView.tag = 2000+k;
            
            //获取沙盒路径
            NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",self.fileNameCell,titleArray[k+1]]];
            
            //打印沙盒路径
            //                NSLog(@"%@ %@", NSHomeDirectory(),titleArray[k+1]);
            
            //获取路径对应的图片文件
            UIImage *image = [UIImage imageWithContentsOfFile:path];
            
            //给imageView添加视图文件
            kkkkView.image = image;
            
            //将imageView添加到屏幕
            [headMineView addSubview:kkkkView];
            
            kkkkView.userInteractionEnabled = YES;
            
            //为UIImageView1添加点击事件
            UITapGestureRecognizer *tapGestureRecognizer3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scanBigImageClick1:)];
            [kkkkView addGestureRecognizer:tapGestureRecognizer3];
        }
        
    }else
    {
        for (UIImageView *titleImage in [headMineView subviews]) {
            if (titleImage.tag >= 2000) {
                [titleImage removeFromSuperview];
            }
        }
    }
    _cellInfoTableView.scrollEnabled = NO;
    
    [_cellInfoTableView reloadData];
    
}


#pragma mark 选项有图片时调用的方法，目前支持单选，多选
- (void)configCell:(TKDetailBaseCell *)cell indexpath:(NSIndexPath *)indexPath
{
    NSArray *longAnswerArray = [[NSString stringWithFormat:@"%@%@",self.aaArray[indexPath.row],_cellInfoArray[indexPath.row]] componentsSeparatedByString:@"##"];
    
    cell.checkLabel.text = longAnswerArray[0];
    
    if (longAnswerArray.count > 1) {
        
        //        for (int p = 0; p < longAnswerArray.count - 1; p++) {
        //获取沙盒路径
        NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,longAnswerArray[1]]];
        
        //获取路径对应的图片文件
        UIImage *image = [UIImage imageWithContentsOfFile:path];
        
        //给imageView添加视图文件
        cell.selectImageView1.image = image;
        
        cell.selectImageView1.userInteractionEnabled = YES;
        
        //为UIImageView1添加点击事件
        UITapGestureRecognizer *tapGestureRecognizer3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scanBigImageClick1:)];
        [cell.selectImageView1 addGestureRecognizer:tapGestureRecognizer3];
        
        //获取沙盒路径
        NSString *path1 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,longAnswerArray[2]]];
        
        //获取路径对应的图片文件
        UIImage *image1 = [UIImage imageWithContentsOfFile:path1];
        
        //给imageView添加视图文件
        cell.selectImageView2.image = image1;
        
        cell.selectImageView2.userInteractionEnabled = YES;
        
        //为UIImageView1添加点击事件
        UITapGestureRecognizer *tapGestureRecognizer4 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scanBigImageClick1:)];
        [cell.selectImageView2 addGestureRecognizer:tapGestureRecognizer4];
        
        //获取沙盒路径
        NSString *path2 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@/%@",_imagefileName,longAnswerArray[3]]];
        
        //获取路径对应的图片文件
        UIImage *image2 = [UIImage imageWithContentsOfFile:path2];
        
        //给imageView添加视图文件
        cell.selectImageView3.image = image2;
        //        }
        
        cell.selectImageView3.userInteractionEnabled = YES;
        
        //为UIImageView1添加点击事件
        UITapGestureRecognizer *tapGestureRecognizer5 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scanBigImageClick1:)];
        [cell.selectImageView3 addGestureRecognizer:tapGestureRecognizer5];
        
        cell.selectImageViewHeight.constant = 80.0;
        
        cell.selectImageView1.hidden = NO;
        cell.selectImageView2.hidden = NO;
        cell.selectImageView3.hidden = NO;
        
        
    }else{
        
        cell.selectImageView1.image = nil;
        cell.selectImageView1.hidden = YES;
        cell.selectImageView2.hidden = YES;
        cell.selectImageView3.hidden = YES;
        cell.selectImageViewHeight.constant = 0.0;
    }
}

#pragma mark tabelViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _cellInfoArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *iIdentifier = @"newDetailCell";
    TKDetailBaseCell *cell = [tableView dequeueReusableCellWithIdentifier:iIdentifier];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"TKDetailBaseCell" owner:self options:nil] lastObject];
    }
    
    [self configCell:cell indexpath:indexPath];
    
    [cell.checkButton setBackgroundImage:[UIImage imageNamed:@"TKdetail_unselect"] forState:UIControlStateNormal];
    
    [cell.checkButton setBackgroundImage:[UIImage imageNamed:@"TKdetail_select"] forState:UIControlStateSelected ];
    
    [cell.checkButton addTarget:self action:@selector(touchSelectButton:) forControlEvents:UIControlEventTouchUpInside];
    
    cell.checkButton.tag = indexPath.row;
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (indexPath.row != self.rowNUmber) {
        cell.checkButton.selected = NO;
    }else
    {
        cell.checkButton.selected = YES;
    }
    
    return cell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [tableView fd_heightForCellWithIdentifier:@"newDetailCell" cacheByIndexPath:indexPath configuration:^(TKDetailBaseCell *cell) {
        if (_cellInfoArray.count > 0) {
            [self configCell:cell indexpath:indexPath];
        }
    }];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _rowNUmber = indexPath.row;
    
    [_cellInfoTableView reloadData];
    
    if ([self.delegate respondsToSelector:@selector(getGroup1Answer:andchoice:andChildSubjectID:)]) {
        [self.delegate getGroup1Answer:_littleCellNumber andchoice:indexPath.row andChildSubjectID:self.childSubjectID];
    }
    
}

#pragma mark 组题1选中选项按钮触发事件
-(void)touchSelectButton:(UIButton *)button
{
    _rowNUmber = button.tag;
    
    [_cellInfoTableView reloadData];
    
    if ([self.delegate respondsToSelector:@selector(getGroup1Answer:andchoice:andChildSubjectID:)]) {
        [self.delegate getGroup1Answer:_littleCellNumber andchoice:button.tag andChildSubjectID:self.childSubjectID];
    }
}



#pragma mark - 浏览大图点击事件
-(void)scanBigImageClick1:(UITapGestureRecognizer *)tap{
    NSLog(@"点击图片");
    UIImageView *clickedImageView = (UIImageView *)tap.view;
    [XWScanImage scanBigImageWithImageView:clickedImageView];
}


@end
