//
//  TKWendaTableViewCell.m
//  TikuApp
//
//  Created by huangkeyuan on 16/8/15.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKWendaTableViewCell.h"

@implementation TKWendaTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code

}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
#pragma mark 名词解释&问答题
        
        _topTextView = [[UITextView alloc] init];
        _topTextView.frame = CGRectMake(10, 5, SCREEN_WIDTH - 30, 200);
        _topTextView.font = [UIFont boldSystemFontOfSize:16];
        _topTextView.delegate = self;
        _topTextView.text = @"请在此输入答案";
        _topTextView.textColor = [UIColor lightGrayColor];
        [self addSubview:_topTextView];
        
        _contentTextView = [[UITextView alloc] init];
        _contentTextView.frame = CGRectMake(10, 5, SCREEN_WIDTH - 30, 200);
        _contentTextView.font = [UIFont boldSystemFontOfSize:16];
        _contentTextView.delegate = self;
        _contentTextView.hidden = NO;
        _contentTextView.backgroundColor = [UIColor clearColor];
        [self addSubview:_contentTextView];

    }
    return self;

}


-(void)layoutSubviews
{
    _contentTextView.delegate = self;
    _topTextView.delegate = self;

}




- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text

{    if (![text isEqualToString:@""]){
    
    self.topTextView.hidden = YES;
    self.contentTextView.backgroundColor = [UIColor whiteColor];
    
    }
    
    if ([text isEqualToString:@""] && range.location == 0 && range.length == 1)
        
    {
        self.topTextView.hidden = NO;
        self.contentTextView.backgroundColor = [UIColor clearColor];
    }
    
    return YES;
    
}

-(void)textViewDidEndEditing:(UITextView *)textView
{
//    NSLog(@"%@",textView.text);
    if ([self.delegate respondsToSelector:@selector(getWendaAnswer:)]) {
        [self.delegate getWendaAnswer:textView.text];
    }
    
    
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
