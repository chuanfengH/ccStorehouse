//
//  TKGroup1TableViewCell.h
//  TikuApp
//
//  Created by huangkeyuan on 16/8/16.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol TKGroup1Chice <NSObject>
- (void)getGroup1Answer:(int)kChoiceCell andchoice:(NSInteger)kChoiceRow andChildSubjectID:(NSString *)childSubjectID;
@end
@interface TKGroup1TableViewCell : UITableViewCell<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong)UITableView *cellInfoTableView;
@property (nonatomic,strong)NSDictionary *cellInfoDiction;
@property (nonatomic,strong)NSArray *cellInfoArray;
@property (nonatomic) int cellInfoNumber;
@property (nonatomic) int littleCellNumber;
@property (nonatomic,strong)NSArray *aaArray;
@property (nonatomic) CGFloat heightCellNumber;
@property (nonatomic,copy) NSString *fileNameCell;
@property (nonatomic,copy) NSString *examID;//当前考题所在试卷的id
@property (nonatomic,copy) NSString *fatherSubjectID;//父级标题的id
@property (nonatomic,copy) NSString *childSubjectID;//小标题的id
@property (nonatomic)NSInteger rowNUmber;//当前选中行数
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (weak, nonatomic) id<TKGroup1Chice> delegate;
@property (nonatomic,copy) NSString *imagefileName;//图片所在文件名称
@property (nonatomic, strong) NSDictionary *paraStyleDic;//字体间距设置

@end
