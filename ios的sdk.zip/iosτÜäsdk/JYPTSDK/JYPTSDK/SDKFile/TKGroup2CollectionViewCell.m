//
//  TKGroup2CollectionViewCell.m
//  TiKuAppSDK
//
//  Created by huangkeyuan on 2016/11/29.
//  Copyright © 2016年 HuangChuanfeng. All rights reserved.
//

#import "TKGroup2CollectionViewCell.h"
@implementation TKGroup2CollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
