//
//  TKTableViewCell.m
//  TikuApp
//
//  Created by huangkeyuan on 16/8/1.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKTableViewCell.h"

@implementation TKTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code

}



- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
#pragma mark 选择题
        _checkImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 12, 15, 15)];
        _checkImageView.image = [UIImage imageNamed:@"detail_unselect"];
        [self addSubview:_checkImageView];

        _checkLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_checkImageView.frame) + 10, 5, SCREEN_WIDTH - 45, 30)];
        _checkLabel.text = @"A.外科热";
        _checkLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
            [self addSubview:_checkLabel];
        // 间距约束（添加到self.view身上）
        _checkLabel.backgroundColor = [UIColor redColor];
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
