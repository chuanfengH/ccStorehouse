//
//  TKDetailBaseCell.h
//  TikuApp
//
//  Created by huangkeyuan on 16/8/23.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKDetailBaseCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *checkButton;
@property (weak, nonatomic) IBOutlet UILabel *checkLabel;
@property (weak, nonatomic) IBOutlet UIImageView *selectImageView1;
@property (weak, nonatomic) IBOutlet UIImageView *selectImageView2;
@property (weak, nonatomic) IBOutlet UIImageView *selectImageView3;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *selectImageViewHeight;

@end
