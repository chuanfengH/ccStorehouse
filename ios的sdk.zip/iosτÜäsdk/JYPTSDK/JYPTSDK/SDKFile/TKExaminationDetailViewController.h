//
//  TKExaminationDetailViewController.h
//  TikuApp
//
//  Created by huangkeyuan on 16/7/27.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKDetailPubilcViewController.h"

@interface TKExaminationDetailViewController : TKDetailPubilcViewController
@property (nonatomic,copy) NSString *detailID;
@property (nonatomic,copy) NSString *detailName;
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (nonatomic) long long startLongLong;
@property (nonatomic) long long finishLongLong;
@property (nonatomic) int isDelaySubmit;
@property (nonatomic) NSInteger homeworkTotalNumber;

//新增
@property (nonatomic,copy) NSString *userId;
@property (copy,nonatomic) NSString *pathOfZipFile;
@property (copy,nonatomic) NSString *unZipFileName;
@property (copy,nonatomic) NSString *paperName;
@property (copy,nonatomic) NSString *zipName;

@property (nonatomic, copy) void (^CommitHomeworkResponseBlock)(BOOL response);

@end
