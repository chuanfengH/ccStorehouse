//
//  TKExamHadFinishedCell_Group1.m
//  TikuApp
//
//  Created by HuangChuanfeng on 16/9/29.
//  Copyright © 2016年 leimingtech. All rights reserved.
//

#import "TKExamHadFinishedCell_Group1.h"
#import "TKExamHadFinishedCell.h"
#import "XWScanImage.h"

//统一图片宽高
#define unifyImageWidth 80
#define unifyImageHeight 80
//统一字体大小
#define unifyTextFont 15
//组头图片左间距
#define headerImageLeftMargin 30
//cell图片左间距
#define cellImageLeftMargin 60
//组头文字内容行间距
#define headerLineSpacing 10

@implementation TKExamHadFinishedCell_Group1
{
    CGFloat _tableViewHeight;
    CGFloat _headerHeight;
    CGFloat _footerHeight;
    NSMutableArray *_mutArrMyChoice;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        _contentGroup1TableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 0) style:UITableViewStylePlain];
        _contentGroup1TableView.backgroundColor = [UIColor whiteColor];
        _contentGroup1TableView.showsVerticalScrollIndicator = NO;
        _contentGroup1TableView.showsHorizontalScrollIndicator = NO;
        _contentGroup1TableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _contentGroup1TableView.delegate = self;
        _contentGroup1TableView.dataSource = self;
        _contentGroup1TableView.scrollEnabled = NO;
        [self.contentView addSubview:_contentGroup1TableView];
        _tableViewHeight = 0;
        
        _mutArrMyChoice = [[NSMutableArray alloc] init];
    }
    return  self;
}

#pragma mark - Table view data source
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[_dataDic valueForKey:@"choiceList"] count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *choiceArr = [_dataDic valueForKey:@"choiceList"];
    if (choiceArr.count > 0) {
        NSString *cellText = [NSString stringWithFormat:@"A. %@",choiceArr[indexPath.row]];
        CGFloat cellHeight = 0;
        NSArray *cellTextArr;
        if ([cellText rangeOfString:@"##"].location != NSNotFound)
        {
            cellTextArr = [cellText componentsSeparatedByString:@"##"];
            cellHeight = [self calculateTextHeight:cellTextArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)]+unifyImageHeight+10;
        }
        else
        {
            cellHeight = [self calculateTextHeight:cellText withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)];
        }
        return cellHeight+20;
    }
    else
    {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //    TKExamHadFinishedCell *cell = [tableView dequeueReusableCellWithIdentifier:@"examFinishDetailCell"];
    //    if (!cell) {
    TKExamHadFinishedCell *cell = [[TKExamHadFinishedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    //    }
    char c = (char)65+indexPath.row;
    NSString *cellText = [NSString stringWithFormat:@"%c. %@",c,[_dataDic valueForKey:@"choiceList"][indexPath.row]];
    NSArray  *cellTextArr;
    CGFloat  labelHeight = 0;
    if ([cellText rangeOfString:@"##"].location != NSNotFound)
    {
        cellTextArr = [cellText componentsSeparatedByString:@"##"];
        labelHeight = [self calculateTextHeight:cellTextArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)];
        cell.btnChoice.frame = CGRectMake(15, 8, 25, 25);
        cell.labelChoice.frame = CGRectMake(CGRectGetMaxX(cell.btnChoice.frame)+6, 10, SCREEN_WIDTH-(CGRectGetMaxX(cell.btnChoice.frame)+10+15+10+10), labelHeight);
        cell.imgViewRight.frame = CGRectMake(CGRectGetMaxX(cell.labelChoice.frame)+10, 10, 20, 20);
        if (labelHeight < 18) {
            cell.labelChoice.text = cellTextArr[0];
        }else{
            NSAttributedString *attributeStr = [[NSAttributedString alloc] initWithString:cellTextArr[0] attributes:_paraStyleDic];
            cell.labelChoice.attributedText = attributeStr;
        }
        for (int i =1; i<cellTextArr.count; i++) {
            UIImageView *imageView = [cell viewWithTag:300+i];
            imageView.frame = CGRectMake(cellImageLeftMargin+(unifyImageWidth+10)*(i-1), CGRectGetMaxY(cell.labelChoice.frame)+10, unifyImageWidth, unifyImageHeight);
            NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,cellTextArr[i]];
            NSURL *url = [NSURL URLWithString:urlStr];
            [imageView sd_setImageWithURL:url placeholderImage:nil];
            imageView.userInteractionEnabled = YES;
            imageView.tag = 20+100*(indexPath.row)+i;//用于跳转图片浏览器传参
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapFooterAction:)];
            [imageView addGestureRecognizer:tap];
        }
    }
    else
    {
        labelHeight = [self calculateTextHeight:cellText withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)];
        cell.btnChoice.frame = CGRectMake(15, 8, 25, 25);
        cell.labelChoice.frame = CGRectMake(CGRectGetMaxX(cell.btnChoice.frame)+6, 10, SCREEN_WIDTH-(CGRectGetMaxX(cell.btnChoice.frame)+10+15+10+10), labelHeight);
        cell.imgViewRight.frame = CGRectMake(CGRectGetMaxX(cell.labelChoice.frame)+10, 10, 20, 20);
        cell.labelChoice.text = cellText;
        if (labelHeight < 18) {
            cell.labelChoice.text = cellText;
        }else{
            NSAttributedString *attributeStr = [[NSAttributedString alloc] initWithString:cellText attributes:_paraStyleDic];
            cell.labelChoice.attributedText = attributeStr;
        }
        for (int i =1; i<4; i++) {
            UIImageView *imageView = [cell viewWithTag:300+i];
            imageView.frame = CGRectZero;
        }
    }
    [_mutArrMyChoice removeAllObjects];
    NSArray *arr = [_dataDic valueForKey:@"choiceList"];
    NSString *myAns =[_dataDic valueForKey:@"myAnswer"][0];
    for (int i=0; i<arr.count; i++)
    {
        NSString *str = [NSString stringWithFormat:@"%c",(char)65+i];
        if ([myAns rangeOfString:str].location != NSNotFound) {
            [_mutArrMyChoice addObject:@"1"];
        }else{
            [_mutArrMyChoice addObject:@"0"];
        }
    }
    if (_mutArrMyChoice.count > 0) {
        if ([_mutArrMyChoice[indexPath.row] isEqualToString:@"0"]) {
            [cell.btnChoice setBackgroundImage:[UIImage imageNamed:@"TKdetail_unselect"] forState:UIControlStateNormal];
            [cell.imgViewRight setImage:nil];
        }else{
            if ([[_dataDic valueForKey:@"isRight"] integerValue] == 0) {
                [cell.imgViewRight setImage:[UIImage imageNamed:@"TKicon_error"]];
                [cell.btnChoice setBackgroundImage:[UIImage imageNamed:@"TKdetail_selectError"] forState:UIControlStateNormal];
            }else{
                [cell.imgViewRight setImage:[UIImage imageNamed:@"TKicon_right"]];
                [cell.btnChoice setBackgroundImage:[UIImage imageNamed:@"TKdetail_select"] forState:UIControlStateNormal];
            }
        }
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    CGFloat titleHeight;
    if ([_childName rangeOfString:@"##"].location != NSNotFound)
    {
        NSArray *nameArr = [_childName componentsSeparatedByString:@"##"];
        titleHeight = [self calculateTextHeight:nameArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+unifyImageHeight+10;
    }else{
        titleHeight = [self calculateTextHeight:_childName withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
    }
    _headerHeight = titleHeight+30;
    return _headerHeight;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, _headerHeight)];
    UILabel *labelTitle = [[UILabel alloc] init];
    labelTitle.font = [UIFont systemFontOfSize:unifyTextFont];
    labelTitle.numberOfLines = 0;
    
    CGFloat titleHeight;
    if ([_childName rangeOfString:@"##"].location != NSNotFound)
    {
        NSArray *nameArr = [_childName componentsSeparatedByString:@"##"];
        titleHeight = [self calculateTextHeight:nameArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        labelTitle.frame = CGRectMake(15, 20, SCREEN_WIDTH-30, titleHeight);
        if (titleHeight < 18) {
            labelTitle.text = nameArr[0];
        }else{
            NSAttributedString *attributeStr = [[NSAttributedString alloc] initWithString:nameArr[0] attributes:_paraStyleDic];
            labelTitle.attributedText = attributeStr;
        }
        [headerView addSubview:labelTitle];
        for (int i = 1; i<nameArr.count; i++)
        {
            NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
            NSURL *url = [NSURL URLWithString:urlStr];
            UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(cellImageLeftMargin+(unifyImageWidth+10)*(i-1), CGRectGetMaxY(labelTitle.frame)+10, unifyImageWidth, unifyImageHeight)];
            [imgView sd_setImageWithURL:url placeholderImage:nil];
            imgView.userInteractionEnabled = YES;
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
            [imgView addGestureRecognizer:tap];
            imgView.tag = 10+i;
            [headerView addSubview:imgView];
        }
    }else{
        titleHeight = [self calculateTextHeight:_childName withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
        labelTitle.frame = CGRectMake(15, 20, SCREEN_WIDTH-30, titleHeight);
        if (titleHeight < 18) {
            labelTitle.text = _childName;
        }else{
            NSAttributedString *attributeStr = [[NSAttributedString alloc] initWithString:_childName attributes:_paraStyleDic];
            labelTitle.attributedText = attributeStr;
        }
        [headerView addSubview:labelTitle];
    }
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    CGFloat footerHeight = 0;
    //正确答案的高度
    NSArray *tureAnswer = [_dataDic valueForKey:@"answer"];
    NSString *rightAnswerText;
    for (int i = 0; i < tureAnswer.count; i++) {
        if (i == 0) {
            rightAnswerText = [NSString stringWithFormat:@"正确答案: %@",tureAnswer[0]];
        }else{
            rightAnswerText = [NSString stringWithFormat:@"%@,%@",rightAnswerText,tureAnswer[i]];
        }
    }
    CGFloat rightAnsHei = [self calculateTextHeight:rightAnswerText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
    //我的答案的高度
    NSArray *myAnswer = [_dataDic valueForKey:@"myAnswer"];
    NSString *myAnswerText;
    
    for (int i = 0; i < myAnswer.count; i++) {
        if (i == 0) {
            myAnswerText = [NSString stringWithFormat:@"我的答案: %@",myAnswer[0]];
        }else{
            myAnswerText = [NSString stringWithFormat:@"%@,%@",myAnswerText,myAnswer[i]];
        }
    }
    CGFloat myAnsHei = [self calculateTextHeight:myAnswerText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
    //答案分析的高度
    NSString *answerAnalyText = [NSString stringWithFormat:@"答案解析: %@",[_dataDic valueForKey:@"answerResolve"]];
    NSArray  *answerAnalyArr;
    CGFloat ansAnalyHei;
    if ([answerAnalyText rangeOfString:@"##"].location != NSNotFound)
    {
        answerAnalyArr = [answerAnalyText componentsSeparatedByString:@"##"];
        ansAnalyHei = [self calculateTextHeight:answerAnalyArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+90;
    }
    else
    {
        ansAnalyHei = [self calculateTextHeight:answerAnalyText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
    }
    //得分高度
    CGFloat ansGetGradeHei = [self calculateTextHeight:@"得分:" withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
    
    footerHeight = 10+rightAnsHei+10+ansAnalyHei+10+ansGetGradeHei+10+myAnsHei+10+40+20;
    
    NSArray *choiceArr = [_dataDic valueForKey:@"choiceList"];
    CGFloat cellHeight = 0;
    for (int i=0; i<choiceArr.count; i++) {
        NSString *cellText = [NSString stringWithFormat:@"A. %@",choiceArr[i]];
        NSArray *cellTextArr;
        if ([cellText rangeOfString:@"##"].location != NSNotFound)
        {
            cellTextArr = [cellText componentsSeparatedByString:@"##"];
            cellHeight = cellHeight+[self calculateTextHeight:cellTextArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)]+unifyImageHeight+10+20;
        }
        else
        {
            cellHeight = cellHeight+[self calculateTextHeight:cellText withLimitSize:CGSizeMake(SCREEN_WIDTH-80, MAXFLOAT)]+20;
        }
    }
    _tableViewHeight = _headerHeight+cellHeight+footerHeight;
    _contentGroup1TableView.frame = CGRectMake(0, 0, SCREEN_WIDTH, _tableViewHeight);
    return footerHeight;
}

- (UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    CGFloat footerHeight = 0;
    //正确答案的高度
    NSArray *tureAnswer = [_dataDic valueForKey:@"answer"];
    NSString *rightAnswerText;
    for (int i = 0; i < tureAnswer.count; i++) {
        if (i == 0) {
            if ([tureAnswer[i] isEqualToString:@"false"]) {
                rightAnswerText = @"正确答案: 错误";
            }else if ([tureAnswer[i] isEqualToString:@"true"]){
                rightAnswerText = @"正确答案: 正确";
            }
            else{
                rightAnswerText = [NSString stringWithFormat:@"正确答案: %@",tureAnswer[i]];
            }
        }else{
            rightAnswerText = [NSString stringWithFormat:@"%@,%@",rightAnswerText,tureAnswer[i]];
        }
    }
    CGFloat rightAnsHei = [self calculateTextHeight:rightAnswerText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
    //我的答案的高度
    NSArray *myAnswer = [_dataDic valueForKey:@"myAnswer"];
    NSString *myAnswerText;
    
    for (int i = 0; i < myAnswer.count; i++) {
        if (i == 0) {
            if ([myAnswer[i] isEqualToString:@"false"]) {
                myAnswerText = @"正确答案: 错误";
            }else if ([myAnswer[i] isEqualToString:@"ture"]){
                myAnswerText = @"正确答案: 正确";
            }else{
                myAnswerText = [NSString stringWithFormat:@"我的答案: %@",myAnswer[i]];
            }
        }else{
            myAnswerText = [NSString stringWithFormat:@"%@,%@",myAnswerText,myAnswer[i]];
        }
    }
    CGFloat myAnsHei = [self calculateTextHeight:myAnswerText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
    //答案分析的高度
    NSString *answerAnalyText = [NSString stringWithFormat:@"答案解析: %@",[_dataDic valueForKey:@"answerResolve"]];
    NSArray  *answerAnalyArr;
    CGFloat ansAnalyHei;
    if ([answerAnalyText rangeOfString:@"##"].location != NSNotFound)
    {
        answerAnalyArr = [answerAnalyText componentsSeparatedByString:@"##"];
        ansAnalyHei = [self calculateTextHeight:answerAnalyArr[0] withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)]+90;
    }
    else
    {
        ansAnalyHei = [self calculateTextHeight:answerAnalyText withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
    }
    //得分高度
    CGFloat ansGetGradeHei = [self calculateTextHeight:@"得分:" withLimitSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
    
    footerHeight = 10+rightAnsHei+10+ansAnalyHei+10+ansGetGradeHei;
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, footerHeight)];
    //    footerView.backgroundColor = [UIColor blueColor];
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(15, 10, SCREEN_WIDTH-30, 0.5)];
    line.backgroundColor = [UIColor colorWithRed:0.94f green:0.94f blue:0.94f alpha:1.00f];
    [footerView addSubview:line];
    //正确答案label
    UILabel *labelRightAnswer = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(line.frame)+10, SCREEN_WIDTH-30, rightAnsHei)];
    labelRightAnswer.numberOfLines = 0;
    labelRightAnswer.textColor = [UIColor colorWithRed:0.15f green:0.56f blue:0.10f alpha:1.00f];
    labelRightAnswer.font = [UIFont systemFontOfSize:unifyTextFont];
    if (rightAnsHei < 18) {
        labelRightAnswer.text = rightAnswerText;
    }else{
        NSAttributedString *rightStr = [[NSAttributedString alloc] initWithString:rightAnswerText attributes:_paraStyleDic];
        labelRightAnswer.attributedText = rightStr;
    }
    [footerView addSubview:labelRightAnswer];
    //我的答案label
    UILabel *labelMyAnswer = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(labelRightAnswer.frame)+10, SCREEN_WIDTH-30, myAnsHei)];
    labelMyAnswer.numberOfLines = 0;
    labelMyAnswer.textColor = [UIColor colorWithRed:1.00f green:0.00f blue:0.00f alpha:1.00f];
    labelMyAnswer.font = [UIFont systemFontOfSize:unifyTextFont];
    if (myAnswerText.length > 0) {
        if (myAnsHei < 18) {
            labelMyAnswer.text = myAnswerText;
        }else{
            NSAttributedString *myStr = [[NSAttributedString alloc] initWithString:myAnswerText attributes:_paraStyleDic];
            labelMyAnswer.attributedText = myStr;
        }
    }
    [footerView addSubview:labelMyAnswer];
    //得分label
    UILabel *labelAnswerGetGrade = [[UILabel alloc] init];
    //答案解析label
    if ([answerAnalyText rangeOfString:@"##"].location != NSNotFound)
    {
        UILabel *labelAnswerAnalysis = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(labelMyAnswer.frame)+10, SCREEN_WIDTH-30, ansAnalyHei)];
        labelAnswerAnalysis.numberOfLines = 0;
        labelAnswerAnalysis.textColor = [UIColor blackColor];
        labelAnswerAnalysis.font = [UIFont systemFontOfSize:unifyTextFont];
        if (ansAnalyHei < 18) {
            labelAnswerAnalysis.text = answerAnalyArr[0];
        }else{
            NSAttributedString *analyStr = [[NSAttributedString alloc] initWithString:answerAnalyArr[0] attributes:_paraStyleDic];
            labelAnswerAnalysis.attributedText = analyStr;
        }
        [footerView addSubview:labelAnswerAnalysis];
        
        for (int i = 1; i<answerAnalyArr.count; i++)
        {
            NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,answerAnalyArr[i]];
            NSURL *url = [NSURL URLWithString:urlStr];
            UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(cellImageLeftMargin+(unifyImageWidth+10)*(i-1), CGRectGetMaxY(labelAnswerAnalysis.frame), unifyImageWidth, unifyImageHeight)];
            [imgView sd_setImageWithURL:url placeholderImage:nil];
            imgView.userInteractionEnabled = YES;
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapFooterAction:)];
            [imgView addGestureRecognizer:tap];
            imgView.tag = 10+i;
            [footerView addSubview:imgView];
        }
        labelAnswerGetGrade.frame = CGRectMake(15, CGRectGetMaxY(labelAnswerAnalysis.frame)+90, (SCREEN_WIDTH-30)/2, ansGetGradeHei);
    }
    else
    {
        //答案解析
        UILabel *labelAnswerAnalysis = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(labelMyAnswer.frame)+10, SCREEN_WIDTH-30, ansAnalyHei)];
        
        labelAnswerAnalysis.numberOfLines = 0;
        labelAnswerAnalysis.textColor = [UIColor blackColor];
        labelAnswerAnalysis.font = [UIFont systemFontOfSize:unifyTextFont];
        if (ansAnalyHei < 18) {
            labelAnswerAnalysis.text = answerAnalyText;
        }else{
            NSAttributedString *analyStr = [[NSAttributedString alloc] initWithString:answerAnalyText attributes:_paraStyleDic];
            labelAnswerAnalysis.attributedText = analyStr;
        }
        [footerView addSubview:labelAnswerAnalysis];
        labelAnswerGetGrade.frame = CGRectMake(15, CGRectGetMaxY(labelAnswerAnalysis.frame)+10, (SCREEN_WIDTH-30)/2, ansGetGradeHei);
    }
    //得分
    labelAnswerGetGrade.numberOfLines = 0;
    labelAnswerGetGrade.textColor = [UIColor blackColor];
    labelAnswerGetGrade.font = [UIFont systemFontOfSize:unifyTextFont];
    labelAnswerGetGrade.text = [NSString stringWithFormat:@"得分: %@",[_dataDic valueForKey:@"actualScore"]];
    [footerView addSubview:labelAnswerGetGrade];
    
    //收藏按钮
    UIButton *btnCollect = [UIButton buttonWithType:UIButtonTypeCustom];
    btnCollect.titleLabel.font = [UIFont systemFontOfSize:unifyTextFont];
    btnCollect.backgroundColor = [UIColor colorWithRed:0.19f green:0.60f blue:0.92f alpha:1.00f];
    [btnCollect setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btnCollect.clipsToBounds = YES;
    btnCollect.layer.cornerRadius = 3.0;
    [btnCollect addTarget:self action:@selector(btnCollectAction:) forControlEvents:UIControlEventTouchUpInside];
    btnCollect.titleLabel.textAlignment = NSTextAlignmentLeft;
    if ([[_dataDic valueForKey:@"isCollect"] integerValue] == 0) {
        [btnCollect setImage:[UIImage imageNamed:@"TKcollect_star"] forState:UIControlStateNormal];
        [btnCollect setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 40)];
        [btnCollect setTitleEdgeInsets:UIEdgeInsetsMake(0, -25, 0, 0)];
        btnCollect.frame = CGRectMake(15, CGRectGetMaxY(labelAnswerGetGrade.frame)+10, 70, 30);
        [btnCollect setTitle:@"收藏" forState:UIControlStateNormal];
    }
    else
    {
        [btnCollect setImage:[UIImage imageNamed:@"TKcollected_star"] forState:UIControlStateNormal];
        [btnCollect setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 70)];
        [btnCollect setTitleEdgeInsets:UIEdgeInsetsMake(0, -25, 0, 0)];
        btnCollect.frame = CGRectMake(15, CGRectGetMaxY(labelAnswerGetGrade.frame)+10, 100, 30);
        [btnCollect setTitle:@"取消收藏" forState:UIControlStateNormal];
    }
    [footerView addSubview:btnCollect];
    
    return footerView;
}

- (void)btnCollectAction:(UIButton*)btn
{
    NSString *questionId = [_dataDic valueForKey:@"qid"];
    NSString *isCollect = [_dataDic valueForKey:@"isCollect"];
    
    NSDictionary *_dic = @{@"userId":TKUSERID,
                           @"questionId":questionId,
                           @"isCollect":isCollect
                           };
    [[TKAFNetWorkingClient sharedClient] Post:DoCollect
                                   Parameters:_dic
                                      Success:^(id responseObject)
     {
         //请求成功：
         if ([[responseObject objectForKey:@"result"] integerValue] == 1)
         {
             self.requestDataAgain([responseObject objectForKey:@"msg"]);
         }
         else
         {
             [MBProgressHUD showAutoMessage:[responseObject objectForKey:@"msg"]];
         }
     } Failure:^(NSError *error) {
         //请求失败
         [MBProgressHUD showError:@"网络错误" ToView:self];
     }];
}

/** 计算label内容有多行的高度(正常字体) */
- (CGFloat)calculateTextHeight:(NSString*)text withLimitSize:(CGSize)limitSize
{
    CGSize size = [text boundingRectWithSize:limitSize options:NSStringDrawingUsesLineFragmentOrigin attributes:_paraStyleDic context:nil].size;
    CGFloat oneRowHeight = [text sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:unifyTextFont]}].height;
    NSInteger rows = size.height / oneRowHeight;//rows 是label有几行
    if (rows == 1) {
        size = CGSizeMake(size.width, oneRowHeight);
    }
    return size.height;
}

#pragma mark - 浏览大图点击事件
- (void)tapAction:(UITapGestureRecognizer *)tap{
    UIImageView *imageView = (UIImageView*)tap.view;
    NSMutableArray *mutArr = [[NSMutableArray alloc] init];
    if (imageView.tag < 15) {
        NSArray *nameArr = [_childName componentsSeparatedByString:@"##"];
        for (int i = 1; i<nameArr.count; i++)
        {
            NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
            [urlStr stringByReplacingOccurrencesOfString:@"_small" withString:@""];
            NSURL *url = [NSURL URLWithString:urlStr];
            [mutArr addObject:url];
        }
        self.openImageViewer(mutArr,imageView.tag-10);
    }
}

- (void)tapFooterAction:(UITapGestureRecognizer *)tap{
    UIImageView *imageView = (UIImageView*)tap.view;
    NSMutableArray *mutArr = [[NSMutableArray alloc] init];
    if (imageView.tag < 15) {
        NSString *name = [_dataDic valueForKey:@"answerResolve"];
        NSArray *nameArr = [name componentsSeparatedByString:@"##"];
        for (int i = 1; i<nameArr.count; i++)
        {
            NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
            [urlStr stringByReplacingOccurrencesOfString:@"_small" withString:@""];
            NSURL *url = [NSURL URLWithString:urlStr];
            [mutArr addObject:url];
        }
        self.openImageViewer(mutArr,imageView.tag-10);
    }
    else
    {
        NSInteger index = imageView.tag/100;
        NSString *name = [_dataDic valueForKey:@"choiceList"][index];
        NSArray *nameArr = [name componentsSeparatedByString:@"##"];
        for (int i = 1; i<nameArr.count; i++)
        {
            NSString *urlStr = [NSString stringWithFormat:@"%@%@",RequestPictureUrl,nameArr[i]];
            [urlStr stringByReplacingOccurrencesOfString:@"_small" withString:@""];
            NSURL *url = [NSURL URLWithString:urlStr];
            [mutArr addObject:url];
        }
        self.openImageViewer(mutArr,imageView.tag-100*index-20);
    }
}

@end
